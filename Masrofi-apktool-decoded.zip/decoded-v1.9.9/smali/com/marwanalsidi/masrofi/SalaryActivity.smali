.class public Lcom/marwanalsidi/masrofi/SalaryActivity;
.super Landroid/app/Activity;
.source "SalaryActivity.java"


# instance fields
.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 13
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, -0x1

    .line 15
    iput v0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/SalaryActivity;)V
    .locals 0

    .line 13
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->fillLog()V

    return-void
.end method

.method private fillLog()V
    .locals 12

    const v0, 0x7f050002

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    invoke-virtual {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->salaryLog()Ljava/util/List;

    move-result-object v1

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencySymbol(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const v1, 0x7f0800b4

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    :goto_0
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [Ljava/lang/String;

    move-object v10, v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    aget-object v8, v5, v7

    invoke-static {v8}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v7

    invoke-static {v7, v8}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    aget-object v5, v5, v7

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    invoke-static {v8, v9}, Lcom/marwanalsidi/masrofi/Fmt;->full(J)Ljava/lang/String;

    move-result-object v5

    if-nez v4, :cond_1

    const v8, 0x7f0800ae

    invoke-virtual {p0, v8}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I)Ljava/lang/String;

    move-result-object v8

    goto :goto_1

    :cond_1
    const-string v8, ""

    :goto_1
    if-nez v4, :cond_2

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    const/4 v7, 0x0

    :goto_2
    invoke-static {p0, v6, v5, v8, v7}, Lcom/marwanalsidi/masrofi/Ui;->itemRow(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v9, Lcom/marwanalsidi/masrofi/SalaryActivity$3;

    invoke-direct {v9, p0, v10}, Lcom/marwanalsidi/masrofi/SalaryActivity$3;-><init>(Lcom/marwanalsidi/masrofi/SalaryActivity;[Ljava/lang/String;)V

    invoke-virtual {v5, v9}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 18
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 22
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->setTheme(I)V

    .line 23
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 24
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity;->tGen:I

    const p1, 0x7f060005

    .line 25
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 27
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/SalaryActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/SalaryActivity$1;-><init>(Lcom/marwanalsidi/masrofi/SalaryActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05001d

    .line 31
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    .line 32
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v0

    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->getSalary()D

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmpl-double v2, v0, v2

    if-lez v2, :cond_0

    .line 33
    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const v0, 0x7f05000e

    .line 35
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/marwanalsidi/masrofi/SalaryActivity$2;

    invoke-direct {v1, p0, p1}, Lcom/marwanalsidi/masrofi/SalaryActivity$2;-><init>(Lcom/marwanalsidi/masrofi/SalaryActivity;Landroid/widget/EditText;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 57
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->fillLog()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 80
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 81
    iget v0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->recreate()V

    :cond_0
    return-void
.end method
