.class Lcom/marwanalsidi/masrofi/DataActivity$12;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;

.field final synthetic val$row:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$12;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/DataActivity$12;->val$row:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$12;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    new-instance v1, Lcom/marwanalsidi/masrofi/DataActivity$7;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/DataActivity$12;->val$row:[Ljava/lang/String;

    invoke-direct {v1, v0, v2}, Lcom/marwanalsidi/masrofi/DataActivity$7;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Lcom/marwanalsidi/masrofi/DataActivity$7;->onLongClick(Landroid/view/View;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
