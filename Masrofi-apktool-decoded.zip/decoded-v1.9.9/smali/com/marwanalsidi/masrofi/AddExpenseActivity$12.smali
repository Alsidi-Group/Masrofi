.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$items:[Ljava/lang/String;

.field final synthetic val$w:I


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 237
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$items:[Ljava/lang/String;

    iput p3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$w:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    # v1.9.7 — الإصلاح الجذري المؤكد بتقرير الجهاز (IllegalAccessError):
    # حُذف نهائياً أي وصول مباشر للحقول الخاصة payDlg/payDlg2.
    # إغلاق القائمة مسؤولية $16 (dismiss عبر وسيط الحوار — مثبت العمل).
    # هذه الطريقة = منطق الاختيار فقط عبر الموصّلات الاصطناعية — لا وصول مباشر إطلاقاً.

    # ── 1) pay = items[w] + تحديث tvPay (محمي بالكامل) ──
    :try_start_pay
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$items:[Ljava/lang/String;

    iget v2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$w:I

    aget-object v1, v1, v2

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$802(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)Ljava/lang/String;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$900(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Landroid/widget/TextView;

    move-result-object v0

    if-eqz v0, :cond_pay_end

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$800(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const v2, 0x7f010008

    invoke-static {v1, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_pay_end
    :try_end_pay
    .catchall {:try_start_pay .. :try_end_pay} :catch_pay

    # ── 2) toast تأكيد الاختيار (محمي بالكامل) ──
    :try_start_toast
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u062a\u0645 \u0627\u062e\u062a\u064a\u0627\u0631 \u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$800(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v1, v0}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :try_end_toast
    .catchall {:try_start_toast .. :try_end_toast} :catch_toast

    return-void

    :catch_pay
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    goto :try_start_toast

    :catch_toast
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
