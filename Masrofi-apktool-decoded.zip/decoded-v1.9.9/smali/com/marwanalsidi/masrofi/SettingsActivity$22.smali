.class Lcom/marwanalsidi/masrofi/SettingsActivity$22;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$22;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$22;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    const v1, 0x7f08011e

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f08011f

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f080122

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$23;

    invoke-direct {v4}, Lcom/marwanalsidi/masrofi/SettingsActivity$23;-><init>()V

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v0 .. v6}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
