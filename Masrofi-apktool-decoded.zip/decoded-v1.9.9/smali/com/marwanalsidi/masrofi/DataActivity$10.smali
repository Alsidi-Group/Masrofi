.class Lcom/marwanalsidi/masrofi/DataActivity$10;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;

.field final synthetic val$ed:Landroid/widget/EditText;

.field final synthetic val$id:J


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;Landroid/widget/EditText;J)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->val$ed:Landroid/widget/EditText;

    iput-wide p3, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->val$id:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 5

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->val$ed:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    iget-wide v2, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->val$id:J

    invoke-virtual {v1, v2, v3, v0}, Lcom/marwanalsidi/masrofi/DBHelper;->updateExpenseNote(JLjava/lang/String;)V

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$10;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DataActivity;->access$000(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    const v1, 0x7f08010e

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
