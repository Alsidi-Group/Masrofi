.class Lcom/marwanalsidi/masrofi/SalaryActivity$6;
.super Ljava/lang/Object;
.source "SalaryActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

.field final synthetic val$id:J


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SalaryActivity;J)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$6;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    iput-wide p2, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$6;->val$id:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 6

    # إغلاق حوار التأكيد أولاً
    :try_start_0
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$6;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    iget-wide v2, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$6;->val$id:J

    invoke-virtual {v1, v2, v3}, Lcom/marwanalsidi/masrofi/DBHelper;->deleteSalary(J)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->access$000(Lcom/marwanalsidi/masrofi/SalaryActivity;)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    const v1, 0x7f08011b

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
