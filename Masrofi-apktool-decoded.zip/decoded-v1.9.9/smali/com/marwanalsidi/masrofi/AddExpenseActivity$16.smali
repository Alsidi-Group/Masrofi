.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$16;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$items:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$16;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$16;->val$items:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    # v1.9.6 — (1) إغلاق القائمة فور الضغط بمضمون مطلق: عبر وسيط الحوار نفسه
    # لا يعتمد على أي حقل — القائمة تُغلق دائماً عند اختيار خيار.
    :try_start_0
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    # (2) منطق الاختيار المحصّن ($12): يغلق أيضاً payDlg2/payDlg + يحدّث النموذج + توست تأكيد
    :try_start_1
    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$16;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$16;->val$items:[Ljava/lang/String;

    invoke-direct {v0, v1, v2, p2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;I)V

    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->run()V

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
