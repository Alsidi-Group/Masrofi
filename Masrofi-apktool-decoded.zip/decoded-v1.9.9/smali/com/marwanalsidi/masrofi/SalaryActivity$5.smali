.class Lcom/marwanalsidi/masrofi/SalaryActivity$5;
.super Ljava/lang/Object;
.source "SalaryActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

.field final synthetic val$ed:Landroid/widget/EditText;

.field final synthetic val$id:J


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SalaryActivity;Landroid/widget/EditText;J)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->val$ed:Landroid/widget/EditText;

    iput-wide p3, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->val$id:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 8

    # إغلاق الحوار أولاً
    :try_start_0
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->val$ed:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v1

    const-wide/16 v4, 0x0

    cmpg-double v0, v1, v4

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v3

    iget-wide v6, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$5;->val$id:J

    invoke-virtual {v3, v6, v7, v1, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->updateSalary(JD)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->access$000(Lcom/marwanalsidi/masrofi/SalaryActivity;)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    const v3, 0x7f08011a

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :cond_0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
