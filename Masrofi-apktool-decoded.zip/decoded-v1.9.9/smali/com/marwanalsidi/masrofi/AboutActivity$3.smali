.class Lcom/marwanalsidi/masrofi/AboutActivity$3;
.super Ljava/lang/Object;
.source "AboutActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AboutActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AboutActivity;


# static fields
.field private static final WA_URL:Ljava/lang/String; = "https://chat.whatsapp.com/Ct3DmPMzO9P0p734GNSron?s=cl&p=a&mlu=4&ilr=4"


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$3;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$3;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    sget-object v3, Lcom/marwanalsidi/masrofi/AboutActivity$3;->WA_URL:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/AboutActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
