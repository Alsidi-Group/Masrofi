.class public Lcom/marwanalsidi/masrofi/DataActivity;
.super Landroid/app/Activity;
.source "DataActivity.java"


# static fields
.field private static final COL_W:[I


# instance fields
.field private boxChips:Landroid/widget/LinearLayout;

.field private chipDaily:Landroid/widget/TextView;

.field private chipMonthly:Landroid/widget/TextView;

.field private daily:Z

.field private day:I

.field private month1:I

.field private tGen:I

.field private year:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x9

    new-array v0, v0, [I

    .line 34
    fill-array-data v0, :array_0

    sput-object v0, Lcom/marwanalsidi/masrofi/DataActivity;->COL_W:[I

    return-void

    :array_0
    .array-data 4
        0x7d
        0x64
        0x91
        0x7d
        0x3e
        0x78
        0x5f
        0x55
        0x41
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    .line 26
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x1

    .line 29
    iput-boolean v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    const/4 v0, -0x1

    .line 246
    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/DataActivity;)V
    .locals 0

    .line 26
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->exportCsv()V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/DataActivity;I)V
    .locals 0

    .line 26
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->shift(I)V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/DataActivity;Z)V
    .locals 0

    .line 26
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->setMode(Z)V

    return-void
.end method

.method private buildChips()V
    .locals 4

    const/high16 v0, 0x7f050000

    .line 70
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->boxChips:Landroid/widget/LinearLayout;

    .line 71
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    const v0, 0x7f080039

    .line 72
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    invoke-static {p0, v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->chip(Landroid/content/Context;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipDaily:Landroid/widget/TextView;

    const v0, 0x7f08003a

    .line 73
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    xor-int/lit8 v1, v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->chip(Landroid/content/Context;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipMonthly:Landroid/widget/TextView;

    .line 74
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipDaily:Landroid/widget/TextView;

    new-instance v1, Lcom/marwanalsidi/masrofi/DataActivity$5;

    invoke-direct {v1, p0}, Lcom/marwanalsidi/masrofi/DataActivity$5;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 77
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipMonthly:Landroid/widget/TextView;

    new-instance v1, Lcom/marwanalsidi/masrofi/DataActivity$6;

    invoke-direct {v1, p0}, Lcom/marwanalsidi/masrofi/DataActivity$6;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 80
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x40c00000    # 6.0f

    .line 82
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3, v1, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 83
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->boxChips:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipDaily:Landroid/widget/TextView;

    invoke-virtual {v1, v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 84
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->boxChips:Landroid/widget/LinearLayout;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->chipMonthly:Landroid/widget/TextView;

    invoke-virtual {v1, p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private csv(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    if-nez p1, :cond_0

    const-string p1, ""

    :cond_0
    const-string p0, ","

    .line 235
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    const-string v0, "\""

    if-nez p0, :cond_1

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_2

    :cond_1
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "\"\""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :cond_2
    return-object p1
.end method

.method private exportCsv()V
    .locals 18

    move-object/from16 v0, p0

    const-string v1, "\r\n"

    const-string v2, ","

    const-string v3, "masrofi_"

    const/4 v4, 0x0

    .line 193
    :try_start_0
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v5

    .line 194
    iget v6, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v7, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-virtual {v5, v6, v7}, Lcom/marwanalsidi/masrofi/DBHelper;->expensesForMonth(II)Ljava/util/List;

    move-result-object v5

    .line 195
    invoke-direct {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->remainingMap(Ljava/util/List;)Ljava/util/Map;

    move-result-object v6

    .line 196
    new-instance v7, Ljava/io/File;

    const/4 v8, 0x0

    invoke-virtual {v0, v8}, Lcom/marwanalsidi/masrofi/DataActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v8

    const-string v9, "exports"

    invoke-direct {v7, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 197
    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_0

    invoke-virtual {v7}, Ljava/io/File;->mkdirs()Z

    .line 198
    :cond_0
    iget-boolean v8, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v8, :cond_1

    .line 199
    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v12, "%04d%02d%02d"

    new-array v13, v9, [Ljava/lang/Object;

    iget v14, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v13, v4

    iget v14, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v13, v11

    iget v14, v0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v13, v10

    invoke-static {v8, v12, v13}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    goto :goto_0

    .line 200
    :cond_1
    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v12, "%04d%02d"

    new-array v13, v10, [Ljava/lang/Object;

    iget v14, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v13, v4

    iget v14, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v13, v11

    invoke-static {v8, v12, v13}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    .line 201
    :goto_0
    new-instance v12, Ljava/io/File;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v8, ".csv"

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v12, v7, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 202
    new-instance v3, Ljava/io/OutputStreamWriter;

    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v12}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v3, v7, v8}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    const v7, 0xfeff

    .line 204
    invoke-virtual {v3, v7}, Ljava/io/OutputStreamWriter;->write(I)V

    const/16 v7, 0x9

    new-array v8, v7, [Ljava/lang/String;

    const v13, 0x7f08003f

    .line 205
    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    aput-object v13, v8, v4

    const v13, 0x7f08003b

    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    aput-object v13, v8, v11

    const v13, 0x7f080043

    .line 206
    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    aput-object v13, v8, v10

    const v13, 0x7f080040

    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    aput-object v13, v8, v9

    const v13, 0x7f080041

    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x4

    aput-object v13, v8, v14

    const v13, 0x7f080042

    .line 207
    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v15, 0x5

    aput-object v13, v8, v15

    const v13, 0x7f08003c

    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v15, 0x6

    aput-object v13, v8, v15

    const v13, 0x7f08003d

    .line 208
    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/16 v16, 0x7

    aput-object v13, v8, v16

    const v13, 0x7f08003e

    invoke-virtual {v0, v13}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/16 v16, 0x8

    aput-object v13, v8, v16

    .line 209
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    move v15, v4

    :goto_1
    if-ge v15, v7, :cond_3

    if-lez v15, :cond_2

    const/16 v7, 0x2c

    .line 211
    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 212
    :cond_2
    aget-object v7, v8, v15

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v15, v15, 0x1

    const/16 v7, 0x9

    goto :goto_1

    .line 214
    :cond_3
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/io/OutputStreamWriter;->write(Ljava/lang/String;)V

    .line 215
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 217
    :try_start_1
    aget-object v8, v7, v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-object v15, v5

    :try_start_2
    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 218
    :try_start_3
    iget-boolean v8, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    if-eqz v8, :cond_4

    invoke-direct {v0, v4, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->sameDay(J)Z

    move-result v8

    if-nez v8, :cond_4

    move-object v5, v15

    const/4 v4, 0x0

    goto :goto_2

    .line 219
    :cond_4
    aget-object v8, v7, v14
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    const-string v17, ""

    if-nez v8, :cond_5

    move-object/from16 v8, v17

    .line 220
    :cond_5
    :try_start_4
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    invoke-interface {v6, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Double;

    .line 221
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-direct {v0, v8}, Lcom/marwanalsidi/masrofi/DataActivity;->csv(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v14, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    aget-object v14, v7, v11

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    aget-object v14, v7, v10

    invoke-direct {v0, v14}, Lcom/marwanalsidi/masrofi/DataActivity;->csv(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    aget-object v14, v7, v9

    invoke-direct {v0, v14}, Lcom/marwanalsidi/masrofi/DataActivity;->csv(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/4 v14, 0x6

    aget-object v7, v7, v14

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    if-nez v13, :cond_6

    goto :goto_3

    .line 222
    :cond_6
    invoke-virtual {v13}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v17

    :goto_3
    move-object/from16 v8, v17

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 223
    invoke-static {v4, v5}, Lcom/marwanalsidi/masrofi/Fmt;->day(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v0, v4, v5}, Lcom/marwanalsidi/masrofi/Fmt;->dayName(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v4, v5}, Lcom/marwanalsidi/masrofi/Fmt;->time(J)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 221
    invoke-virtual {v3, v4}, Ljava/io/OutputStreamWriter;->write(Ljava/lang/String;)V

    goto :goto_4

    :catch_0
    move-object v15, v5

    :catch_1
    const/4 v14, 0x6

    :goto_4
    move-object v5, v15

    const/4 v4, 0x0

    const/4 v14, 0x4

    goto/16 :goto_2

    .line 225
    :cond_7
    invoke-virtual {v3}, Ljava/io/OutputStreamWriter;->close()V

    new-array v1, v11, [Ljava/lang/Object;

    .line 226
    invoke-virtual {v12}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const v2, 0x7f080044

    invoke-virtual {v0, v2, v1}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    .line 227
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto :goto_5

    :catch_2
    const v1, 0x7f080045

    .line 229
    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_5
    return-void
.end method

.method private fill()V
    .locals 24

    move-object/from16 v0, p0

    .line 131
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    .line 132
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencySymbol(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f05002d

    .line 133
    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f050031

    .line 134
    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 136
    iget-boolean v5, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    if-eqz v5, :cond_0

    .line 137
    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    iget v6, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    .line 138
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget v7, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    iget v8, v0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    filled-new-array {v6, v7, v8}, [Ljava/lang/Object;

    move-result-object v6

    const-string v7, "%04d/%02d/%02d"

    invoke-static {v5, v7, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    const v6, 0x7f08004c

    .line 137
    invoke-virtual {v0, v6, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 140
    :cond_0
    iget v5, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v6, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-static {v0, v5, v6}, Lcom/marwanalsidi/masrofi/Fmt;->monthLabel(Landroid/content/Context;II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 142
    :goto_0
    invoke-virtual {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v5

    .line 143
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-boolean v7, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    const-string v8, " "

    if-eqz v7, :cond_1

    .line 144
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    iget v9, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v10, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    iget v11, v0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    invoke-virtual {v1, v9, v10, v11}, Lcom/marwanalsidi/masrofi/DBHelper;->sumDay(III)D

    move-result-wide v9

    invoke-static {v9, v10}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v7

    const v9, 0x7f080047

    invoke-virtual {v0, v9, v7}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    .line 145
    :cond_1
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    iget v9, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v10, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-virtual {v1, v9, v10}, Lcom/marwanalsidi/masrofi/DBHelper;->sumMonth(II)D

    move-result-wide v9

    invoke-static {v9, v10}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v7

    const v9, 0x7f08004d

    invoke-virtual {v0, v9, v7}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    :goto_1
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v7, " \u2022 "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 146
    invoke-static {v5, v6}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    const v6, 0x7f08004a

    invoke-virtual {v0, v6, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 143
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 148
    iget v3, v0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v4, v0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-virtual {v1, v3, v4}, Lcom/marwanalsidi/masrofi/DBHelper;->expensesForMonth(II)Ljava/util/List;

    move-result-object v1

    .line 149
    invoke-direct {v0, v1}, Lcom/marwanalsidi/masrofi/DataActivity;->remainingMap(Ljava/util/List;)Ljava/util/Map;

    move-result-object v3

    const v4, 0x7f050005

    .line 151
    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    .line 152
    invoke-virtual {v4}, Landroid/widget/LinearLayout;->removeAllViews()V

    const v5, 0x7f08003f

    .line 155
    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v9

    const v5, 0x7f08003b

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v10

    const v5, 0x7f080043

    .line 156
    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v11

    const v5, 0x7f080040

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v12

    const v5, 0x7f080041

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const v5, 0x7f080042

    .line 157
    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v14

    const v5, 0x7f08003c

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v15

    const v5, 0x7f08003d

    .line 158
    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v16

    const v5, 0x7f08003e

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v17

    filled-new-array/range {v9 .. v17}, [Ljava/lang/String;

    move-result-object v5

    .line 159
    sget-object v6, Lcom/marwanalsidi/masrofi/DataActivity;->COL_W:[I

    const/4 v7, 0x1

    const/4 v9, 0x0

    invoke-static {v0, v5, v6, v7, v9}, Lcom/marwanalsidi/masrofi/Ui;->tableRow(Landroid/content/Context;[Ljava/lang/String;[IZI)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 162
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v5, v9

    :catch_0
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/String;

    .line 164
    :try_start_0
    aget-object v10, v6, v9

    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v10
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 165
    iget-boolean v12, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    if-eqz v12, :cond_2

    invoke-direct {v0, v10, v11}, Lcom/marwanalsidi/masrofi/DataActivity;->sameDay(J)Z

    move-result v12

    if-nez v12, :cond_2

    goto :goto_2

    :cond_2
    const/4 v12, 0x4

    .line 166
    aget-object v13, v6, v12

    const-string v14, "\u2014"

    if-eqz v13, :cond_4

    invoke-virtual {v13}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-eqz v13, :cond_3

    goto :goto_3

    :cond_3
    aget-object v12, v6, v12

    move-object v15, v12

    goto :goto_4

    :cond_4
    :goto_3
    move-object v15, v14

    .line 167
    :goto_4
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    invoke-interface {v3, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Double;

    if-nez v12, :cond_5

    goto :goto_5

    .line 168
    :cond_5
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    :goto_5
    move-object/from16 v20, v14

    .line 169
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v13, v6, v7

    .line 171
    invoke-static {v13}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v13

    invoke-static {v13, v14}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x2

    aget-object v17, v6, v12

    const/4 v12, 0x3

    aget-object v18, v6, v12

    const/4 v12, 0x6

    aget-object v19, v6, v12

    new-instance v12, Lcom/marwanalsidi/masrofi/DataActivity$7;

    invoke-direct {v12, v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity$7;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V

    new-instance v13, Lcom/marwanalsidi/masrofi/DataActivity$12;

    invoke-direct {v13, v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity$12;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V

    .line 176
    invoke-static {v10, v11}, Lcom/marwanalsidi/masrofi/Fmt;->day(J)Ljava/lang/String;

    move-result-object v21

    .line 177
    invoke-static {v0, v10, v11}, Lcom/marwanalsidi/masrofi/Fmt;->dayName(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v22

    .line 178
    invoke-static {v10, v11}, Lcom/marwanalsidi/masrofi/Fmt;->time(J)Ljava/lang/String;

    move-result-object v23

    filled-new-array/range {v15 .. v23}, [Ljava/lang/String;

    move-result-object v6

    .line 180
    sget-object v10, Lcom/marwanalsidi/masrofi/DataActivity;->COL_W:[I

    add-int/lit8 v11, v5, 0x1

    invoke-static {v0, v6, v10, v9, v5}, Lcom/marwanalsidi/masrofi/Ui;->tableRow(Landroid/content/Context;[Ljava/lang/String;[IZI)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v5, v12}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    invoke-virtual {v5, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    move v5, v11

    goto/16 :goto_2

    :cond_6
    if-nez v5, :cond_8

    .line 183
    iget-boolean v1, v0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    if-eqz v1, :cond_7

    const v1, 0x7f080048

    goto :goto_6

    :cond_7
    const v1, 0x7f080049

    :goto_6
    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/high16 v2, 0x41a00000    # 20.0f

    .line 185
    invoke-static {v0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    const/high16 v5, 0x41800000    # 16.0f

    invoke-static {v0, v5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-static {v0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {v1, v3, v5, v0, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 186
    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_8
    return-void
.end method

.method private remainingMap(Ljava/util/List;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    .line 120
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v2

    invoke-virtual {v2}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v0

    iget v3, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v4, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    invoke-virtual {v2, v3, v4}, Lcom/marwanalsidi/masrofi/DBHelper;->sumMonth(II)D

    move-result-wide v3

    add-double/2addr v0, v3

    .line 121
    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    .line 122
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    :goto_0
    if-ltz v2, :cond_0

    .line 123
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Ljava/lang/String;

    .line 124
    aget-object v5, v4, v3

    invoke-static {v5}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v5

    sub-double/2addr v0, v5

    const/4 v5, 0x0

    .line 125
    :try_start_0
    aget-object v4, v4, v5

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    invoke-interface {p0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    :cond_0
    return-object p0
.end method

.method private sameDay(J)Z
    .locals 2

    .line 111
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 112
    invoke-virtual {v0, p1, p2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 p1, 0x1

    .line 113
    invoke-virtual {v0, p1}, Ljava/util/Calendar;->get(I)I

    move-result p2

    iget v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    if-ne p2, v1, :cond_0

    const/4 p2, 0x2

    .line 114
    invoke-virtual {v0, p2}, Ljava/util/Calendar;->get(I)I

    move-result p2

    add-int/2addr p2, p1

    iget v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    if-ne p2, v1, :cond_0

    const/4 p2, 0x5

    .line 115
    invoke-virtual {v0, p2}, Ljava/util/Calendar;->get(I)I

    move-result p2

    iget p0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    if-ne p2, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method private setMode(Z)V
    .locals 1

    .line 88
    iget-boolean v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    if-ne v0, p1, :cond_0

    return-void

    .line 89
    :cond_0
    iput-boolean p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    .line 90
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->buildChips()V

    .line 91
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->fill()V

    return-void
.end method

.method private shift(I)V
    .locals 9

    .line 95
    iget-boolean v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->daily:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 96
    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    add-int/2addr v0, p1

    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    .line 97
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p1

    .line 98
    iget v3, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    add-int/lit8 v4, v0, -0x1

    iget v5, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v2, p1

    invoke-virtual/range {v2 .. v8}, Ljava/util/Calendar;->set(IIIIII)V

    .line 99
    invoke-virtual {p1, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    const/4 v0, 0x2

    .line 100
    invoke-virtual {p1, v0}, Ljava/util/Calendar;->get(I)I

    move-result v0

    add-int/2addr v0, v1

    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    const/4 v0, 0x5

    .line 101
    invoke-virtual {p1, v0}, Ljava/util/Calendar;->get(I)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    goto :goto_0

    .line 103
    :cond_0
    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    add-int/2addr v0, p1

    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    const/16 p1, 0xc

    if-le v0, p1, :cond_1

    .line 104
    iput v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    add-int/2addr v0, v1

    iput v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    .line 105
    :cond_1
    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    if-ge v0, v1, :cond_2

    iput p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    iget p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    sub-int/2addr p1, v1

    iput p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    .line 107
    :cond_2
    :goto_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->fill()V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 37
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 41
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/DataActivity;->setTheme(I)V

    .line 42
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 43
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->tGen:I

    const p1, 0x7f060002

    .line 44
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 46
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/DataActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/DataActivity$1;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05000a

    .line 49
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/DataActivity$2;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/DataActivity$2;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05000d

    .line 52
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/DataActivity$3;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/DataActivity$3;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05000c

    .line 55
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/DataActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/DataActivity$4;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/DataActivity$4;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 59
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p1

    const/4 v0, 0x1

    .line 60
    invoke-virtual {p1, v0}, Ljava/util/Calendar;->get(I)I

    move-result v1

    iput v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->year:I

    const/4 v1, 0x2

    .line 61
    invoke-virtual {p1, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->month1:I

    const/4 v0, 0x5

    .line 62
    invoke-virtual {p1, v0}, Ljava/util/Calendar;->get(I)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/DataActivity;->day:I

    .line 64
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->buildChips()V

    .line 65
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->fill()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 241
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 242
    iget v0, p0, Lcom/marwanalsidi/masrofi/DataActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->recreate()V

    return-void

    .line 243
    :cond_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->fill()V

    return-void
.end method
