.class public Lcom/marwanalsidi/masrofi/AboutActivity;
.super Landroid/app/Activity;
.source "AboutActivity.java"


# instance fields
.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 10
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, -0x1

    .line 12
    iput v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity;->tGen:I

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 15
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 19
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AboutActivity;->setTheme(I)V

    .line 20
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 21
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity;->tGen:I

    const/high16 p1, 0x7f060000

    .line 22
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 24
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AboutActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AboutActivity$1;-><init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050033

    .line 28
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    .line 30
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->currentVersionName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->currentVersionCode(Landroid/content/Context;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    const v1, 0x7f08000a

    .line 29
    invoke-virtual {p0, v1, v0}, Lcom/marwanalsidi/masrofi/AboutActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f050009

    .line 32
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AboutActivity$2;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AboutActivity$2;-><init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050035

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AboutActivity$3;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AboutActivity$3;-><init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 55
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 56
    iget v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/AboutActivity;->recreate()V

    :cond_0
    return-void
.end method
