.class Lcom/marwanalsidi/masrofi/DataActivity$8;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;

.field final synthetic val$row:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$8;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/DataActivity$8;->val$row:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 12

    # 1) إغلاق قائمة الإجراءات فور الضغط — عبر وسيط الحوار (نمط v1.9.6 المثبت)
    :try_start_0
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    # 2) منطق الإجراء — معرف الصف من العمود الثامن (id) ثم توزيع على الحوارات
    :try_start_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$8;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/DataActivity$8;->val$row:[Ljava/lang/String;

    const/16 v2, 0x7

    aget-object v2, v1, v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v10

    if-eqz p2, :cond_0

    const/4 v2, 0x1

    if-eq p2, v2, :cond_1

    const/4 v2, 0x2

    if-eq p2, v2, :cond_2

    goto/16 :goto_0

    # ── الخيار 1: تعديل المبلغ ──
    :cond_0
    const v2, 0x7f080116

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x2002

    invoke-static {v0, v2, v3}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v2

    const/4 v3, 0x1

    aget-object v3, v1, v3

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    new-instance v4, Lcom/marwanalsidi/masrofi/DataActivity$9;

    invoke-direct {v4, v0, v2, v10, v11}, Lcom/marwanalsidi/masrofi/DataActivity$9;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;Landroid/widget/EditText;J)V

    const v3, 0x7f08010d

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v5, 0x7f080109

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const v6, 0x7f08002a

    invoke-virtual {v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static/range {v0 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    goto/16 :goto_0

    # ── الخيار 2: تعديل العنصر ──
    :cond_1
    const v2, 0x7f080117

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v0, v2, v3}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v2

    const/4 v3, 0x4

    aget-object v3, v1, v3

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    new-instance v4, Lcom/marwanalsidi/masrofi/DataActivity$10;

    invoke-direct {v4, v0, v2, v10, v11}, Lcom/marwanalsidi/masrofi/DataActivity$10;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;Landroid/widget/EditText;J)V

    const v3, 0x7f08010d

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v5, 0x7f08010a

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const v6, 0x7f08002a

    invoke-virtual {v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static/range {v0 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    goto/16 :goto_0

    # ── الخيار 3: حذف نهائي ──
    :cond_2
    new-instance v4, Lcom/marwanalsidi/masrofi/DataActivity$11;

    invoke-direct {v4, v0, v10, v11}, Lcom/marwanalsidi/masrofi/DataActivity$11;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;J)V

    const v3, 0x7f080111

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v5, 0x7f080112

    invoke-virtual {v0, v5}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const v6, 0x7f08010f

    invoke-virtual {v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v6, 0x7f08002a

    invoke-virtual {v0, v6}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static/range {v0 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    :goto_0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
