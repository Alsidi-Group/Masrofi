.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$15;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$15;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$15;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$1100(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
