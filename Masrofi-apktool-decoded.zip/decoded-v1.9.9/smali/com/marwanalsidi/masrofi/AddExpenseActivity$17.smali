.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$17;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPay()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$17;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    # v1.9.6 — (1) إغلاق قائمة الفئات فور الضغط بمضمون مطلق (وسيط الحوار نفسه)
    :try_start_0
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    # (2) فتح قائمة عناصر الفئة المختارة (pickPayGroup محصّنة بالكامل)
    :try_start_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$17;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    move v1, p2

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$700(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V

    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catch_1

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
