.class Lcom/marwanalsidi/masrofi/DataActivity$7;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;

.field final synthetic val$row:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$7;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/DataActivity$7;->val$row:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 6

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$7;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v2, 0x7f08010c

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const v4, 0x7f080109

    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    const v4, 0x7f08010a

    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x2

    const v4, 0x7f08010b

    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    new-instance v3, Lcom/marwanalsidi/masrofi/DataActivity$8;

    iget-object v4, p0, Lcom/marwanalsidi/masrofi/DataActivity$7;->val$row:[Ljava/lang/String;

    invoke-direct {v3, v0, v4}, Lcom/marwanalsidi/masrofi/DataActivity$8;-><init>(Lcom/marwanalsidi/masrofi/DataActivity;[Ljava/lang/String;)V

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    const/4 v0, 0x1

    return v0

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    const/4 v0, 0x1

    return v0
.end method
