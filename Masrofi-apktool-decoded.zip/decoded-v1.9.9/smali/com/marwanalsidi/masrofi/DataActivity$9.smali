.class Lcom/marwanalsidi/masrofi/DataActivity$9;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;

.field final synthetic val$ed:Landroid/widget/EditText;

.field final synthetic val$id:J


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;Landroid/widget/EditText;J)V
    .locals 0

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->val$ed:Landroid/widget/EditText;

    iput-wide p3, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->val$id:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 8

    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->val$ed:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v1

    const-wide/16 v4, 0x0

    cmpg-double v0, v1, v4

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v3

    iget-wide v6, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->val$id:J

    invoke-virtual {v3, v6, v7, v1, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->updateExpenseAmount(JD)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DataActivity;->access$000(Lcom/marwanalsidi/masrofi/DataActivity;)V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    const v3, 0x7f08010e

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/DataActivity$9;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    const v2, 0x7f080051

    invoke-virtual {v1, v2}, Lcom/marwanalsidi/masrofi/DataActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
