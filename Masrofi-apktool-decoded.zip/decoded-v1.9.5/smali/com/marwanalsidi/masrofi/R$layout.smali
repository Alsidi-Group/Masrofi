.class public final Lcom/marwanalsidi/masrofi/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final activity_about:I = 0x7f060000

.field public static final activity_add_expense:I = 0x7f060001

.field public static final activity_data:I = 0x7f060002

.field public static final activity_login:I = 0x7f060003

.field public static final activity_main:I = 0x7f060004

.field public static final activity_salary:I = 0x7f060005

.field public static final activity_settings:I = 0x7f060006

.field public static final activity_shops:I = 0x7f060007

.field public static final activity_splash:I = 0x7f060008


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 387
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
