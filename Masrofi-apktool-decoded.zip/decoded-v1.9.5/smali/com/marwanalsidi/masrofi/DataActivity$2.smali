.class Lcom/marwanalsidi/masrofi/DataActivity$2;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/DataActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;)V
    .locals 0

    .line 49
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$2;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 50
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/DataActivity$2;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->access$000(Lcom/marwanalsidi/masrofi/DataActivity;)V

    return-void
.end method
