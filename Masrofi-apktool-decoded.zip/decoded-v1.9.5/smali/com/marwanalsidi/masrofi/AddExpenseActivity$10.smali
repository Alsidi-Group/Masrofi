.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->addNewStore(Landroid/app/AlertDialog;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$edName:Landroid/widget/EditText;

.field final synthetic val$edSection:Landroid/widget/EditText;

.field final synthetic val$picker:Landroid/app/AlertDialog;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/app/AlertDialog;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 189
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$edName:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$edSection:Landroid/widget/EditText;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$picker:Landroid/app/AlertDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    .line 191
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$edName:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 192
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    .line 193
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const p1, 0x7f080055

    .line 194
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 193
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 194
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    .line 197
    :cond_0
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p2}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object p2

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$edSection:Landroid/widget/EditText;

    .line 198
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 197
    invoke-virtual {p2, p1, v1}, Lcom/marwanalsidi/masrofi/DBHelper;->addStore(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_1

    .line 199
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const v1, 0x7f0800e3

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v2

    .line 200
    invoke-virtual {p2, v1, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 199
    invoke-static {p2, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p2

    .line 200
    invoke-virtual {p2}, Landroid/widget/Toast;->show()V

    .line 201
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p2, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$600(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)V

    .line 202
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$picker:Landroid/app/AlertDialog;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/app/AlertDialog;->isShowing()Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->val$picker:Landroid/app/AlertDialog;

    invoke-virtual {p0}, Landroid/app/AlertDialog;->dismiss()V

    goto :goto_0

    .line 204
    :cond_1
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const p1, 0x7f080054

    .line 205
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 204
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 205
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_0
    return-void
.end method
