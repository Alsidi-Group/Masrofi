.class Lcom/marwanalsidi/masrofi/CalculatorActivity$3;
.super Ljava/lang/Object;
.source "CalculatorActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/CalculatorActivity;->key(Ljava/lang/String;)Landroid/widget/TextView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;

.field final synthetic val$label:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/CalculatorActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 148
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;->this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;->val$label:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 149
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;->this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;->val$label:Ljava/lang/String;

    invoke-static {p1, p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->access$100(Lcom/marwanalsidi/masrofi/CalculatorActivity;Ljava/lang/String;)V

    return-void
.end method
