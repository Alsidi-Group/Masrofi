.class Lcom/marwanalsidi/masrofi/SettingsActivity$8;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->collapsibleHead(Ljava/lang/String;Landroid/view/View;Ljava/lang/String;)Landroid/widget/LinearLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field isOpen:Z

.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$arrow:Landroid/widget/ImageView;

.field final synthetic val$content:Landroid/view/View;

.field final synthetic val$key:Ljava/lang/String;

.field final synthetic val$open:Z


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;ZLandroid/view/View;Landroid/widget/ImageView;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 264
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput-boolean p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$open:Z

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$content:Landroid/view/View;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$arrow:Landroid/widget/ImageView;

    iput-object p5, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$key:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 265
    iput-boolean p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->isOpen:Z

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 268
    iget-boolean p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->isOpen:Z

    xor-int/lit8 p1, p1, 0x1

    iput-boolean p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->isOpen:Z

    .line 269
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$content:Landroid/view/View;

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 270
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$arrow:Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/widget/ImageView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    iget-boolean v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->isOpen:Z

    if-eqz v0, :cond_1

    const/high16 v0, 0x42b40000    # 90.0f

    goto :goto_1

    :cond_1
    const/high16 v0, 0x43870000    # 270.0f

    :goto_1
    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->rotation(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0xb4

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 271
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->val$key:Ljava/lang/String;

    iget-boolean p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$8;->isOpen:Z

    invoke-static {p1, v0, p0}, Lcom/marwanalsidi/masrofi/Prefs;->setSectionOpen(Landroid/content/Context;Ljava/lang/String;Z)V

    return-void
.end method
