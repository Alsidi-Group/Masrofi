.class Lcom/marwanalsidi/masrofi/MainActivity$8;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/MainActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/MainActivity;)V
    .locals 0

    .line 56
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/MainActivity$8;->this$0:Lcom/marwanalsidi/masrofi/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 57
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/MainActivity$8;->this$0:Lcom/marwanalsidi/masrofi/MainActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->checkAndShow(Landroid/app/Activity;)V

    return-void
.end method
