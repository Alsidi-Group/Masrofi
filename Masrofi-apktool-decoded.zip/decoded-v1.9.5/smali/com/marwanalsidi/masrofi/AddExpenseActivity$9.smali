.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickShop()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$holder:[Landroid/app/AlertDialog;

.field final synthetic val$s:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;[Landroid/app/AlertDialog;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 155
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->val$s:[Ljava/lang/String;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->val$holder:[Landroid/app/AlertDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 157
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->val$s:[Ljava/lang/String;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    invoke-static {p1, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$600(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)V

    .line 158
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;->val$holder:[Landroid/app/AlertDialog;

    const/4 p1, 0x0

    aget-object p0, p0, p1

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/app/AlertDialog;->dismiss()V

    :cond_0
    return-void
.end method
