.class Lcom/marwanalsidi/masrofi/GoogleAuth$1;
.super Ljava/lang/Object;
.source "GoogleAuth.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/GoogleAuth;->attempt(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$accountName:Ljava/lang/String;

.field final synthetic val$act:Landroid/app/Activity;

.field final synthetic val$isRetry:Z


# direct methods
.method constructor <init>(Landroid/app/Activity;Ljava/lang/String;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 66
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$act:Landroid/app/Activity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$accountName:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$isRetry:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 13

    const-string v0, "intent"

    const-string v1, "com.google"

    const-string v2, "Bearer "

    const/high16 v3, 0x10000000

    const/4 v4, 0x0

    const/4 v5, 0x0

    .line 70
    :try_start_0
    iget-object v6, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$act:Landroid/app/Activity;

    invoke-virtual {v6}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;

    move-result-object v6

    .line 71
    new-instance v8, Landroid/accounts/Account;

    iget-object v7, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$accountName:Ljava/lang/String;

    invoke-direct {v8, v7, v1}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const-string v9, "oauth2:https://www.googleapis.com/auth/userinfo.email"

    const/4 v10, 0x0

    const/4 v11, 0x0

    .line 72
    new-instance v12, Landroid/os/Handler;

    .line 77
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v7

    invoke-direct {v12, v7}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    move-object v7, v6

    .line 72
    invoke-virtual/range {v7 .. v12}, Landroid/accounts/AccountManager;->getAuthToken(Landroid/accounts/Account;Ljava/lang/String;ZLandroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;

    move-result-object v7

    .line 78
    invoke-interface {v7}, Landroid/accounts/AccountManagerFuture;->getResult()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/os/Bundle;

    const-string v8, "authtoken"

    .line 79
    invoke-virtual {v7, v8}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const v9, 0x7f080026

    if-nez v8, :cond_1

    .line 82
    invoke-virtual {v7, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_1

    .line 83
    invoke-virtual {v7, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    if-eqz v0, :cond_0

    .line 84
    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$isRetry:Z

    if-nez v1, :cond_0

    .line 85
    invoke-virtual {v0, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 86
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;

    invoke-direct {v2, p0, v0}, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;-><init>(Lcom/marwanalsidi/masrofi/GoogleAuth$1;Landroid/content/Intent;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 101
    :cond_0
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object v0

    invoke-virtual {v0, v9}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v5, v4, v0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    return-void

    :cond_1
    if-eqz v8, :cond_6

    .line 105
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    goto/16 :goto_2

    .line 111
    :cond_2
    new-instance v0, Ljava/net/URL;

    const-string v7, "https://www.googleapis.com/oauth2/v3/userinfo"

    invoke-direct {v0, v7}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 112
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const/16 v7, 0x1f40

    .line 114
    :try_start_1
    invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 115
    invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const-string v7, "GET"

    .line 116
    invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const-string v7, "Authorization"

    .line 117
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v7, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "User-Agent"

    const-string v7, "Masrofi-App"

    .line 118
    invoke-virtual {v0, v2, v7}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 119
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    const/16 v7, 0xc8

    if-eq v2, v7, :cond_3

    .line 121
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object v1

    const/4 v6, 0x1

    new-array v6, v6, [Ljava/lang/Object;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v6, v4

    const v2, 0x7f080021

    invoke-virtual {v1, v2, v6}, Lcom/marwanalsidi/masrofi/App;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v5, v4, v1}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 138
    :try_start_2
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return-void

    .line 124
    :cond_3
    :try_start_3
    new-instance v2, Ljava/io/BufferedReader;

    new-instance v7, Ljava/io/InputStreamReader;

    .line 125
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v9

    const-string v10, "UTF-8"

    invoke-direct {v7, v9, v10}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v2, v7}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 126
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 128
    :goto_0
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_4

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 129
    :cond_4
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    .line 130
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v2, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v7, "email"

    .line 131
    iget-object v9, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$accountName:Ljava/lang/String;

    invoke-virtual {v2, v7, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v9, "email_verified"

    .line 132
    invoke-virtual {v2, v9, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const-string v10, "name"

    const-string v11, "@"

    .line 133
    invoke-virtual {v7, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    aget-object v11, v11, v4

    invoke-virtual {v2, v10, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 134
    :try_start_4
    invoke-virtual {v6, v1, v8}, Landroid/accounts/AccountManager;->invalidateAuthToken(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catch_0
    if-eqz v9, :cond_5

    move-object v1, v5

    goto :goto_1

    .line 136
    :cond_5
    :try_start_5
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object v1

    const v6, 0x7f080023

    invoke-virtual {v1, v6}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 135
    :goto_1
    invoke-static {v7, v2, v9, v1}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 138
    :try_start_6
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_3

    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 139
    throw v1

    .line 106
    :cond_6
    :goto_2
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object v0

    invoke-virtual {v0, v9}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v5, v4, v0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    return-void

    :catch_1
    move-exception v0

    .line 142
    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$isRetry:Z

    if-nez v1, :cond_7

    .line 143
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.accounts.UserRecoverableAuthException"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    .line 144
    invoke-static {v0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$100(Ljava/lang/Exception;)Landroid/content/Intent;

    move-result-object v1

    if-eqz v1, :cond_7

    .line 146
    invoke-virtual {v1, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 147
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/marwanalsidi/masrofi/GoogleAuth$1$2;

    invoke-direct {v2, p0, v1}, Lcom/marwanalsidi/masrofi/GoogleAuth$1$2;-><init>(Lcom/marwanalsidi/masrofi/GoogleAuth$1;Landroid/content/Intent;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 163
    :cond_7
    invoke-static {v0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$200(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, v5, v4, p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    :goto_3
    return-void
.end method
