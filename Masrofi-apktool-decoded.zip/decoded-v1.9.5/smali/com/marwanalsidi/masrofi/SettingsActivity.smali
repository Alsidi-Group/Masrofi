.class public Lcom/marwanalsidi/masrofi/SettingsActivity;
.super Landroid/app/Activity;
.source "SettingsActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/marwanalsidi/masrofi/SettingsActivity$TypedValueResolver;
    }
.end annotation


# instance fields
.field private boxSettings:Landroid/widget/LinearLayout;

.field private tDark:I

.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 28
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, -0x1

    .line 565
    iput v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tGen:I

    .line 566
    iput v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tDark:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/SettingsActivity;I)V
    .locals 0

    .line 28
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->applyTheme(I)V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 28
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->pickCurrency()V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/SettingsActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V
    .locals 0

    .line 28
    invoke-direct {p0, p1, p2, p3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->fillCurList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$300(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 28
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->buildAll()V

    return-void
.end method

.method static synthetic access$400(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 28
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->confirmWipe()V

    return-void
.end method

.method private accountSection()V
    .locals 16

    move-object/from16 v0, p0

    .line 66
    iget-object v1, v0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const v2, 0x7f0800ba

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->sectionHead(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 67
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v1

    .line 69
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->userName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    .line 70
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->userRow(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 72
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    .line 73
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x10

    .line 74
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 77
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->avatar(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    .line 78
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 79
    :try_start_0
    invoke-static {v6}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    :cond_0
    const/4 v6, 0x0

    :goto_0
    const/16 v7, 0x34

    .line 81
    invoke-static {v0, v6, v7}, Lcom/marwanalsidi/masrofi/Ui;->circleImage(Landroid/content/Context;Landroid/graphics/Bitmap;I)Landroid/widget/ImageView;

    move-result-object v6

    .line 82
    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$2;

    invoke-direct {v7, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity$2;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    invoke-virtual {v6, v7}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 85
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 87
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x1

    .line 88
    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 89
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v8, v5, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v9, 0x41400000    # 12.0f

    .line 91
    invoke-static {v0, v9}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    const/high16 v11, 0x41000000    # 8.0f

    invoke-static {v0, v11}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v8, v10, v5, v11, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    if-nez v3, :cond_1

    goto :goto_2

    .line 93
    :cond_1
    aget-object v2, v3, v7

    if-eqz v2, :cond_3

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    aget-object v2, v3, v7

    goto :goto_2

    :cond_3
    :goto_1
    aget-object v2, v3, v5

    .line 94
    :goto_2
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 95
    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41780000    # 15.5f

    .line 96
    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const v2, 0x7f010008

    .line 97
    invoke-static {v0, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v2, "sans-serif-medium"

    .line 98
    invoke-static {v2, v5}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 99
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyInfo(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object v2

    .line 100
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->countryCode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lcom/marwanalsidi/masrofi/Countries;->byCode(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    .line 101
    new-instance v12, Landroid/widget/TextView;

    invoke-direct {v12, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 102
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x2

    const-string v15, ""

    if-eqz v11, :cond_4

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v11, v7

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v9, " "

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    aget-object v9, v11, v14

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v9, " \u2022 "

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_3

    :cond_4
    move-object v5, v15

    :goto_3
    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const/4 v9, 0x0

    aget-object v11, v2, v9

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v9, " ("

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    aget-object v2, v2, v7

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, ")"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41400000    # 12.0f

    .line 104
    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const v2, 0x7f010009

    .line 105
    invoke-static {v0, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 106
    invoke-virtual {v6, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 107
    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 108
    invoke-virtual {v4, v6, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 110
    invoke-direct/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v2

    .line 111
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 112
    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 113
    new-instance v2, Lcom/marwanalsidi/masrofi/SettingsActivity$3;

    invoke-direct {v2, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity$3;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 118
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-eqz v3, :cond_9

    const/16 v2, 0x8

    .line 121
    invoke-direct {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v2, 0x4

    const-wide/16 v4, 0x0

    .line 123
    :try_start_1
    aget-object v2, v3, v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :catch_1
    move-wide v8, v4

    :goto_4
    const/4 v2, 0x5

    .line 124
    :try_start_2
    aget-object v2, v3, v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v10
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_5

    :catch_2
    move-wide v10, v4

    :goto_5
    const-string v2, "google"

    const/4 v6, 0x3

    .line 126
    aget-object v12, v3, v6

    invoke-virtual {v2, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    const v2, 0x7f0800d2

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_6

    :cond_5
    const-string v2, "google-local"

    .line 127
    aget-object v3, v3, v6

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    const v2, 0x7f0800d1

    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_6

    :cond_6
    const v2, 0x7f0800d3

    .line 128
    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 129
    :goto_6
    invoke-direct {v0, v14}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 130
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u2014 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-array v3, v7, [Ljava/lang/Object;

    cmp-long v6, v10, v4

    if-lez v6, :cond_7

    .line 132
    invoke-static {v10, v11}, Lcom/marwanalsidi/masrofi/Fmt;->full(J)Ljava/lang/String;

    move-result-object v6

    goto :goto_7

    :cond_7
    const-string v6, "\u2014"

    :goto_7
    const/4 v7, 0x0

    aput-object v6, v3, v7

    const v6, 0x7f0800d4

    .line 131
    invoke-virtual {v0, v6, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    cmp-long v3, v8, v4

    if-lez v3, :cond_8

    .line 133
    invoke-static {v8, v9}, Lcom/marwanalsidi/masrofi/Fmt;->full(J)Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const v4, 0x7f0800c1

    invoke-virtual {v0, v4, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v15

    :cond_8
    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 130
    invoke-static {v0, v2}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    .line 134
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_9
    const/16 v2, 0xa

    .line 137
    invoke-direct {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v2, 0x7f0800c5

    .line 138
    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f0800c6

    .line 139
    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/SettingsActivity$4;

    invoke-direct {v5, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity$4;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 138
    invoke-static {v0, v2, v3, v4, v5}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v2

    .line 144
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 145
    iget-object v0, v0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private applyTheme(I)V
    .locals 1

    .line 527
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeIndex(Landroid/content/Context;)I

    move-result v0

    if-ne v0, p1, :cond_0

    return-void

    .line 528
    :cond_0
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Prefs;->setTheme(Landroid/content/Context;I)V

    .line 529
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->bumpThemeGen(Landroid/content/Context;)V

    .line 530
    sget-object v0, Lcom/marwanalsidi/masrofi/Prefs;->THEME_NAME_RES:[I

    aget p1, v0, p1

    .line 531
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const v0, 0x7f0800e4

    .line 530
    invoke-virtual {p0, v0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 531
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 532
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->recreate()V

    return-void
.end method

.method private buildAll()V
    .locals 2

    .line 51
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 53
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->accountSection()V

    .line 54
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->uiSection()V

    .line 55
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->langSection()V

    .line 56
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->currencySection()V

    .line 57
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->notifSection()V

    .line 58
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permsSection()V

    .line 59
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->dataSection()V

    .line 61
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const/16 v1, 0x14

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private chevron()Landroid/widget/ImageView;
    .locals 1

    .line 449
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const p0, 0x7f040012

    .line 450
    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    return-object v0
.end method

.method private collapsibleHead(Ljava/lang/String;Landroid/view/View;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 8

    const/4 v0, 0x1

    .line 242
    invoke-static {p0, p3, v0}, Lcom/marwanalsidi/masrofi/Prefs;->sectionOpen(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v3

    .line 243
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    .line 244
    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 245
    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x40c00000    # 6.0f

    .line 246
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    const/high16 v5, 0x41900000    # 18.0f

    invoke-static {p0, v5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v7, v4, v6, v2, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 247
    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 249
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 250
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41580000    # 13.5f

    .line 251
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 p1, 0x7f010000

    .line 252
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v2, "sans-serif-medium"

    .line 253
    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 254
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v2, v1, v4, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 257
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v2, 0x7f040012

    .line 258
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 259
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setColorFilter(I)V

    if-eqz v3, :cond_0

    const/high16 p1, 0x42b40000    # 90.0f

    goto :goto_0

    :cond_0
    const/high16 p1, 0x43870000    # 270.0f

    .line 260
    :goto_0
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setRotation(F)V

    .line 261
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {p0, v5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, v5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-direct {p1, v2, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    const/16 v1, 0x8

    .line 263
    :goto_1
    invoke-virtual {p2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 264
    new-instance p1, Lcom/marwanalsidi/masrofi/SettingsActivity$8;

    move-object v1, p1

    move-object v2, p0

    move-object v4, p2

    move-object v5, v0

    move-object v6, p3

    invoke-direct/range {v1 .. v6}, Lcom/marwanalsidi/masrofi/SettingsActivity$8;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;ZLandroid/view/View;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v7, p1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v7
.end method

.method private confirmWipe()V
    .locals 8

    const v0, 0x7f080107

    .line 480
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f080106

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v0, 0x7f080108

    .line 481
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/SettingsActivity$21;

    invoke-direct {v5, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$21;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    const v0, 0x7f08002a

    .line 489
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 480
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private currencySection()V
    .locals 5

    .line 279
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const v1, 0x7f0800bb

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->sectionHead(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 280
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    const v1, 0x7f0800c2

    .line 281
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v1, 0x8

    .line 282
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 283
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyInfo(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    .line 284
    aget-object v2, v1, v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const v3, 0x7f0800c3

    invoke-virtual {p0, v3, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    aget-object v1, v1, v3

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const v3, 0x7f0800c4

    .line 285
    invoke-virtual {p0, v3, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$9;

    invoke-direct {v4, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$9;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 284
    invoke-static {p0, v2, v1, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v1

    .line 288
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 289
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private dataSection()V
    .locals 5

    .line 456
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const v1, 0x7f0800bc

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->sectionHead(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 457
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    const v1, 0x7f0800d5

    .line 458
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f0800d6

    .line 459
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$18;

    invoke-direct {v4, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$18;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 458
    invoke-static {p0, v1, v2, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f0800d9

    .line 464
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f0800da

    .line 465
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$19;

    invoke-direct {v4, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$19;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 464
    invoke-static {p0, v1, v2, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f0800ca

    .line 468
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f0800cb

    .line 469
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$20;

    invoke-direct {v4, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$20;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 468
    invoke-static {p0, v1, v2, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 476
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private dotOf(I)Landroid/view/View;
    .locals 14

    .line 506
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 507
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v2, 0x1

    .line 508
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 509
    new-instance v2, Lcom/marwanalsidi/masrofi/SettingsActivity$TypedValueResolver;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity$TypedValueResolver;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity$1;)V

    const-string v4, "em_accent"

    const-string v5, "bl_accent"

    const-string v6, "pu_accent"

    const-string v7, "dk_accent"

    const-string v8, "or_accent"

    const-string v9, "ro_accent"

    const-string v10, "cy_accent"

    const-string v11, "gd_accent"

    const-string v12, "co_accent"

    const-string v13, "sl_accent"

    .line 510
    filled-new-array/range {v4 .. v13}, [Ljava/lang/String;

    move-result-object v3

    aget-object p1, v3, p1

    invoke-virtual {v2, p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity$TypedValueResolver;->color(Landroid/content/Context;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 p1, 0x40000000    # 2.0f

    .line 513
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p1

    const v2, 0x7f010006

    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p0

    invoke-virtual {v1, p1, p0}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 514
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private fillCurList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 322
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 323
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p3, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    .line 324
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyCode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 325
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    .line 326
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_0

    aget-object v2, v1, v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 327
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    aget-object v2, v1, v3

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 328
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    .line 329
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v4, v1, v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "  ("

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/4 v4, 0x2

    aget-object v4, v1, v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ")"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aget-object v3, v1, v3

    .line 330
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$11;

    invoke-direct {v4, p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity$11;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;[Ljava/lang/String;)V

    .line 329
    invoke-static {p0, v2, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method private langSection()V
    .locals 13

    .line 205
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 206
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 208
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v2

    const v3, 0x7f0800c8

    .line 209
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v3, 0x8

    .line 210
    invoke-direct {p0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 211
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Lang;->cur(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 212
    sget-object v4, Lcom/marwanalsidi/masrofi/Lang;->LANGS:[[Ljava/lang/String;

    array-length v5, v4

    const/4 v6, 0x0

    move v7, v6

    :goto_0
    if-ge v7, v5, :cond_2

    aget-object v8, v4, v7

    const/4 v9, 0x2

    .line 213
    aget-object v9, v8, v9

    aget-object v10, v8, v6

    .line 214
    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_0

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->statusIcon(Z)Landroid/widget/ImageView;

    move-result-object v11

    goto :goto_1

    :cond_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v11

    :goto_1
    new-instance v12, Lcom/marwanalsidi/masrofi/SettingsActivity$7;

    invoke-direct {v12, p0, v8}, Lcom/marwanalsidi/masrofi/SettingsActivity$7;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;[Ljava/lang/String;)V

    .line 213
    invoke-static {p0, v9, v10, v11, v12}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v9

    .line 223
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 224
    aget-object v11, v8, v1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v11, 0x41980000    # 19.0f

    .line 225
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 226
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v11, v12, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v12, 0x41400000    # 12.0f

    .line 228
    invoke-static {p0, v12}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v12

    iput v12, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 229
    invoke-virtual {v9, v10, v6, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 230
    aget-object v8, v8, v6

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    const v8, 0x7f040003

    invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    .line 231
    :cond_1
    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 233
    :cond_2
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f0800bd

    .line 235
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "lang"

    invoke-direct {p0, v1, v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->collapsibleHead(Ljava/lang/String;Landroid/view/View;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    .line 236
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 237
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private notifSection()V
    .locals 7

    .line 342
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const v1, 0x7f0800be

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->sectionHead(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 343
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 344
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    .line 345
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v3, 0x10

    .line 346
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 347
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 348
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 349
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v4, v2, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 351
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const v4, 0x7f0800cf

    .line 352
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v4, 0x41700000    # 15.0f

    .line 353
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const v4, 0x7f010008

    .line 354
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const v4, 0x7f0800ce

    .line 355
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    .line 356
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 357
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 358
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 359
    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, p0}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    .line 360
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->notifications(Landroid/content/Context;)Z

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Switch;->setChecked(Z)V

    .line 361
    new-instance v3, Lcom/marwanalsidi/masrofi/SettingsActivity$12;

    invoke-direct {v3, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$12;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    invoke-virtual {v2, v3}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 376
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 377
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 378
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V
    .locals 1

    .line 436
    invoke-direct {p0, p4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->statusIcon(Z)Landroid/widget/ImageView;

    move-result-object p4

    invoke-static {p0, p2, p3, p4, p5}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object p2

    const/high16 p3, 0x40800000    # 4.0f

    .line 437
    invoke-static {p0, p3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p4

    const/high16 p5, 0x41000000    # 8.0f

    invoke-static {p0, p5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-static {p0, p3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p3

    invoke-static {p0, p5}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {p2, p4, v0, p3, p0}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 438
    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private permsSection()V
    .locals 8

    .line 383
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    const v1, 0x7f0800bf

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->sectionHead(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 384
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    const v1, 0x7f0800d0

    .line 385
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v1, 0x8

    .line 386
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f08009a

    .line 387
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const v1, 0x7f08009b

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 388
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->notificationsGranted(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$13;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$13;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    move-object v2, p0

    move-object v3, v0

    .line 387
    invoke-direct/range {v2 .. v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V

    const v1, 0x7f080095

    .line 396
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const v1, 0x7f080096

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 397
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->cameraGranted(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$14;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$14;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 396
    invoke-direct/range {v2 .. v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V

    const v1, 0x7f080098

    .line 405
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const v1, 0x7f080099

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 406
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->locationGranted(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$15;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$15;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 405
    invoke-direct/range {v2 .. v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V

    const v1, 0x7f080091

    .line 414
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const v1, 0x7f080092

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 415
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->exactAlarmsGranted(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$16;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$16;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 414
    invoke-direct/range {v2 .. v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V

    const v1, 0x7f080093

    .line 423
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const v1, 0x7f080094

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 424
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->batteryGranted(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lcom/marwanalsidi/masrofi/SettingsActivity$17;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$17;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    .line 423
    invoke-direct/range {v2 .. v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->permRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Runnable;)V

    .line 432
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private pickCurrency()V
    .locals 8

    .line 293
    invoke-static {}, Lcom/marwanalsidi/masrofi/Countries;->currencyList()Ljava/util/List;

    move-result-object v0

    .line 294
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 295
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 296
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 297
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x7f0800ac

    .line 299
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v4, 0x20001

    invoke-static {p0, v1, v4}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v1

    .line 300
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v4, 0x6

    .line 301
    invoke-direct {p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 302
    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 303
    invoke-virtual {v4, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 304
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x43be0000    # 380.0f

    .line 305
    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    const/4 v7, -0x1

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 304
    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 306
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v4, ""

    .line 308
    invoke-direct {p0, v2, v0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->fillCurList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V

    .line 309
    new-instance v4, Lcom/marwanalsidi/masrofi/SettingsActivity$10;

    invoke-direct {v4, p0, v2, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity$10;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;Landroid/widget/LinearLayout;Ljava/util/List;)V

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const v0, 0x7f08009d

    .line 317
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const v0, 0x7f08002a

    .line 318
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 317
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private sectionHead(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 4

    .line 537
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 538
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41500000    # 13.0f

    .line 539
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 p1, 0x7f010000

    .line 540
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const-string p1, "sans-serif-medium"

    const/4 v1, 0x0

    .line 541
    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 542
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 543
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {p1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x40c00000    # 6.0f

    .line 545
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x41900000    # 18.0f

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {p1, v2, p0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 546
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private spacer(I)Landroid/view/View;
    .locals 2

    .line 551
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 552
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p1, p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    const/4 p1, 0x1

    invoke-direct {v1, p1, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private statusIcon(Z)Landroid/widget/ImageView;
    .locals 2

    .line 442
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    if-eqz p1, :cond_0

    const v1, 0x7f040011

    goto :goto_0

    :cond_0
    const v1, 0x7f040013

    .line 443
    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz p1, :cond_1

    const p1, 0x7f010007

    goto :goto_1

    :cond_1
    const p1, 0x7f010005

    .line 444
    :goto_1
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setColorFilter(I)V

    return-object v0
.end method

.method private themeRow(I)Landroid/widget/LinearLayout;
    .locals 5

    .line 494
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeIndex(Landroid/content/Context;)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 495
    :goto_0
    sget-object v3, Lcom/marwanalsidi/masrofi/Prefs;->THEME_NAME_RES:[I

    aget v3, v3, p1

    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    if-eqz v0, :cond_1

    const v4, 0x7f0800e7

    goto :goto_1

    :cond_1
    const v4, 0x7f0800ed

    .line 496
    :goto_1
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    if-eqz v0, :cond_2

    .line 497
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->statusIcon(Z)Landroid/widget/ImageView;

    move-result-object v0

    goto :goto_2

    :cond_2
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->chevron()Landroid/widget/ImageView;

    move-result-object v0

    :goto_2
    const/4 v1, 0x0

    .line 495
    invoke-static {p0, v3, v4, v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 498
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->dotOf(I)Landroid/view/View;

    move-result-object p1

    .line 499
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x41f00000    # 30.0f

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-direct {v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x41200000    # 10.0f

    .line 500
    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    iput p0, v1, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 501
    invoke-virtual {v0, p1, v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private uiSection()V
    .locals 14

    .line 150
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 151
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 154
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v2

    const v3, 0x7f0800f1

    .line 155
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/high16 v4, 0x41600000    # 14.0f

    invoke-static {p0, v3, v4, v1}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v1, 0x8

    .line 156
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 157
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    .line 158
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 159
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->mode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "dark"

    const-string v7, "auto"

    const-string v8, "light"

    .line 160
    filled-new-array {v8, v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const v7, 0x7f080078

    .line 161
    invoke-virtual {p0, v7}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v7

    const v8, 0x7f080077

    invoke-virtual {p0, v8}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v8

    const v9, 0x7f080076

    .line 162
    invoke-virtual {p0, v9}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v9

    filled-new-array {v7, v8, v9}, [Ljava/lang/String;

    move-result-object v7

    move v8, v4

    :goto_0
    const/4 v9, 0x3

    if-ge v8, v9, :cond_0

    .line 164
    aget-object v9, v6, v8

    .line 165
    aget-object v10, v7, v8

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    invoke-static {p0, v10, v11}, Lcom/marwanalsidi/masrofi/Ui;->chip(Landroid/content/Context;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    .line 166
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v11, v4, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v12, 0x40800000    # 4.0f

    .line 168
    invoke-static {p0, v12}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v13

    invoke-static {p0, v12}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v11, v13, v4, v12, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    const/16 v12, 0x11

    .line 169
    invoke-virtual {v10, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 170
    new-instance v12, Lcom/marwanalsidi/masrofi/SettingsActivity$5;

    invoke-direct {v12, p0, v9}, Lcom/marwanalsidi/masrofi/SettingsActivity$5;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;Ljava/lang/String;)V

    invoke-virtual {v10, v12}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 176
    invoke-virtual {v3, v10, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 178
    :cond_0
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 179
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v2, 0xa

    .line 180
    invoke-direct {p0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 183
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v2

    const v3, 0x7f0800d8

    .line 184
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 185
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->spacer(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 186
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeIndex(Landroid/content/Context;)I

    move-result v1

    .line 187
    :goto_1
    sget-object v3, Lcom/marwanalsidi/masrofi/Prefs;->THEME_NAMES:[Ljava/lang/String;

    array-length v3, v3

    if-ge v4, v3, :cond_2

    .line 189
    invoke-direct {p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity;->themeRow(I)Landroid/widget/LinearLayout;

    move-result-object v3

    if-ne v4, v1, :cond_1

    const v5, 0x7f040003

    .line 190
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    .line 191
    :cond_1
    new-instance v5, Lcom/marwanalsidi/masrofi/SettingsActivity$6;

    invoke-direct {v5, p0, v4}, Lcom/marwanalsidi/masrofi/SettingsActivity$6;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;I)V

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 194
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 196
    :cond_2
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f0800c0

    .line 198
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "ui"

    invoke-direct {p0, v1, v0, v2}, Lcom/marwanalsidi/masrofi/SettingsActivity;->collapsibleHead(Ljava/lang/String;Landroid/view/View;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    .line 199
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 200
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 32
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 36
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->setTheme(I)V

    .line 37
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 38
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tGen:I

    .line 39
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->isDark(Landroid/content/Context;)Z

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tDark:I

    const p1, 0x7f060006

    .line 40
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 42
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/SettingsActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity$1;-><init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050004

    .line 46
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->boxSettings:Landroid/widget/LinearLayout;

    .line 47
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->buildAll()V

    return-void
.end method

.method protected onResume()V
    .locals 3

    .line 558
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 560
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->isDark(Landroid/content/Context;)Z

    move-result v0

    .line 561
    iget v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v2

    if-ne v1, v2, :cond_1

    iget v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity;->tDark:I

    if-eq v1, v0, :cond_0

    goto :goto_0

    .line 562
    :cond_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->buildAll()V

    return-void

    .line 561
    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->recreate()V

    return-void
.end method
