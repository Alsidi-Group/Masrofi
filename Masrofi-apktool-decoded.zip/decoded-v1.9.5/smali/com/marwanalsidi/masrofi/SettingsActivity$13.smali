.class Lcom/marwanalsidi/masrofi/SettingsActivity$13;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->permsSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 388
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$13;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 390
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$13;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/Perm;->notificationsGranted(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 391
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$13;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->requestNotifications(Landroid/app/Activity;)V

    goto :goto_0

    .line 392
    :cond_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$13;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    const v0, 0x7f080097

    .line 393
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 392
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 393
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method
