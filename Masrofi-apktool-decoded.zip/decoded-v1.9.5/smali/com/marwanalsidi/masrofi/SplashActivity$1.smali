.class Lcom/marwanalsidi/masrofi/SplashActivity$1;
.super Ljava/lang/Object;
.source "SplashActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SplashActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SplashActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SplashActivity;)V
    .locals 0

    .line 20
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SplashActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SplashActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 22
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SplashActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SplashActivity;

    .line 23
    invoke-static {v1}, Lcom/marwanalsidi/masrofi/Prefs;->loggedIn(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_0

    const-class v2, Lcom/marwanalsidi/masrofi/MainActivity;

    goto :goto_0

    :cond_0
    const-class v2, Lcom/marwanalsidi/masrofi/LoginActivity;

    :goto_0
    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 24
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SplashActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SplashActivity;

    invoke-virtual {v1, v0}, Lcom/marwanalsidi/masrofi/SplashActivity;->startActivity(Landroid/content/Intent;)V

    .line 25
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SplashActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SplashActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SplashActivity;->finish()V

    return-void
.end method
