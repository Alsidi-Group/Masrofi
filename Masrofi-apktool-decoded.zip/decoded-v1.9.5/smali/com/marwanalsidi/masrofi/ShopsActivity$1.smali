.class Lcom/marwanalsidi/masrofi/ShopsActivity$1;
.super Ljava/lang/Object;
.source "ShopsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ShopsActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ShopsActivity;)V
    .locals 0

    .line 35
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$1;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 36
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$1;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->finish()V

    return-void
.end method
