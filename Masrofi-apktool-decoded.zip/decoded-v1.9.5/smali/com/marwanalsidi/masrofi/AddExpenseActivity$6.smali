.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 83
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 85
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Perm;->locationGranted(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$300(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    goto :goto_0

    .line 86
    :cond_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const-string p1, "android.permission.ACCESS_FINE_LOCATION"

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    filled-new-array {p1, v0}, [Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x2a

    invoke-virtual {p0, p1, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->requestPermissions([Ljava/lang/String;I)V

    :goto_0
    return-void
.end method
