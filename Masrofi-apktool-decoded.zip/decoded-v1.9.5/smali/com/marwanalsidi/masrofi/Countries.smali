.class public final Lcom/marwanalsidi/masrofi/Countries;
.super Ljava/lang/Object;
.source "Countries.java"


# static fields
.field private static final POPULAR:[Ljava/lang/String;

.field private static final POPULAR_CUR:[Ljava/lang/String;

.field public static final ROWS:[[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 203

    const-string v0, "LY"

    const-string v1, "\ud83c\uddf1\ud83c\uddfe"

    const-string v2, "\u0644\u064a\u0628\u064a\u0627"

    const-string v3, "Libya"

    const-string v4, "LYD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0644\u064a\u0628\u064a"

    const-string v6, "\u062f.\u0644"

    .line 16
    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v7

    const-string v0, "SA"

    const-string v1, "\ud83c\uddf8\ud83c\udde6"

    const-string v2, "\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629"

    const-string v3, "Saudi Arabia"

    const-string v4, "SAR"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0633\u0639\u0648\u062f\u064a"

    const-string v6, "\u0631.\u0633"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v8

    const-string v0, "AE"

    const-string v1, "\ud83c\udde6\ud83c\uddea"

    const-string v2, "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a"

    const-string v3, "United Arab Emirates"

    const-string v4, "AED"

    const-string v5, "\u062f\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062a\u064a"

    const-string v6, "\u062f.\u0625"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v9

    const-string v0, "EG"

    const-string v1, "\ud83c\uddea\ud83c\uddec"

    const-string v2, "\u0645\u0635\u0631"

    const-string v3, "Egypt"

    const-string v4, "EGP"

    const-string v5, "\u062c\u0646\u064a\u0647 \u0645\u0635\u0631\u064a"

    const-string v6, "\u062c.\u0645"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v10

    const-string v0, "TN"

    const-string v1, "\ud83c\uddf9\ud83c\uddf3"

    const-string v2, "\u062a\u0648\u0646\u0633"

    const-string v3, "Tunisia"

    const-string v4, "TND"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u062a\u0648\u0646\u0633\u064a"

    const-string v6, "\u062f.\u062a"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v11

    const-string v0, "DZ"

    const-string v1, "\ud83c\udde9\ud83c\uddff"

    const-string v2, "\u0627\u0644\u062c\u0632\u0627\u0626\u0631"

    const-string v3, "Algeria"

    const-string v4, "DZD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u062c\u0632\u0627\u0626\u0631\u064a"

    const-string v6, "\u062f.\u062c"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v12

    const-string v0, "MA"

    const-string v1, "\ud83c\uddf2\ud83c\udde6"

    const-string v2, "\u0627\u0644\u0645\u063a\u0631\u0628"

    const-string v3, "Morocco"

    const-string v4, "MAD"

    const-string v5, "\u062f\u0631\u0647\u0645 \u0645\u063a\u0631\u0628\u064a"

    const-string v6, "\u062f.\u0645"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v13

    const-string v0, "SD"

    const-string v1, "\ud83c\uddf8\ud83c\udde9"

    const-string v2, "\u0627\u0644\u0633\u0648\u062f\u0627\u0646"

    const-string v3, "Sudan"

    const-string v4, "SDG"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0633\u0648\u062f\u0627\u0646\u064a"

    const-string v6, "\u062c.\u0633"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v14

    const-string v0, "SY"

    const-string v1, "\ud83c\uddf8\ud83c\uddfe"

    const-string v2, "\u0633\u0648\u0631\u064a\u0627"

    const-string v3, "Syria"

    const-string v4, "SYP"

    const-string v5, "\u0644\u064a\u0631\u0629 \u0633\u0648\u0631\u064a\u0629"

    const-string v6, "\u0644.\u0633"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v15

    const-string v0, "JO"

    const-string v1, "\ud83c\uddef\ud83c\uddf4"

    const-string v2, "\u0627\u0644\u0623\u0631\u062f\u0646"

    const-string v3, "Jordan"

    const-string v4, "JOD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0623\u0631\u062f\u0646\u064a"

    const-string v6, "\u062f.\u0623"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v16

    const-string v0, "IQ"

    const-string v1, "\ud83c\uddee\ud83c\uddf6"

    const-string v2, "\u0627\u0644\u0639\u0631\u0627\u0642"

    const-string v3, "Iraq"

    const-string v4, "IQD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0639\u0631\u0627\u0642\u064a"

    const-string v6, "\u062f.\u0639"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v17

    const-string v0, "KW"

    const-string v1, "\ud83c\uddf0\ud83c\uddfc"

    const-string v2, "\u0627\u0644\u0643\u0648\u064a\u062a"

    const-string v3, "Kuwait"

    const-string v4, "KWD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0643\u0648\u064a\u062a\u064a"

    const-string v6, "\u062f.\u0643"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v18

    const-string v0, "QA"

    const-string v1, "\ud83c\uddf6\ud83c\udde6"

    const-string v2, "\u0642\u0637\u0631"

    const-string v3, "Qatar"

    const-string v4, "QAR"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0642\u0637\u0631\u064a"

    const-string v6, "\u0631.\u0642"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v19

    const-string v0, "BH"

    const-string v1, "\ud83c\udde7\ud83c\udded"

    const-string v2, "\u0627\u0644\u0628\u062d\u0631\u064a\u0646"

    const-string v3, "Bahrain"

    const-string v4, "BHD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0628\u062d\u0631\u064a\u0646\u064a"

    const-string v6, "\u062f.\u0628"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v20

    const-string v0, "OM"

    const-string v1, "\ud83c\uddf4\ud83c\uddf2"

    const-string v2, "\u0639\u0645\u0627\u0646"

    const-string v3, "Oman"

    const-string v4, "OMR"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0639\u0645\u0627\u0646\u064a"

    const-string v6, "\u0631.\u0639"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v21

    const-string v0, "YE"

    const-string v1, "\ud83c\uddfe\ud83c\uddea"

    const-string v2, "\u0627\u0644\u064a\u0645\u0646"

    const-string v3, "Yemen"

    const-string v4, "YER"

    const-string v5, "\u0631\u064a\u0627\u0644 \u064a\u0645\u0646\u064a"

    const-string v6, "\u0631.\u064a"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v22

    const-string v0, "LB"

    const-string v1, "\ud83c\uddf1\ud83c\udde7"

    const-string v2, "\u0644\u0628\u0646\u0627\u0646"

    const-string v3, "Lebanon"

    const-string v4, "LBP"

    const-string v5, "\u0644\u064a\u0631\u0629 \u0644\u0628\u0646\u0627\u0646\u064a\u0629"

    const-string v6, "\u0644.\u0644"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v23

    const-string v0, "PS"

    const-string v1, "\ud83c\uddf5\ud83c\uddf8"

    const-string v2, "\u0641\u0644\u0633\u0637\u064a\u0646"

    const-string v3, "Palestine"

    const-string v4, "ILS"

    const-string v5, "\u0634\u064a\u0643\u0644"

    const-string v6, "\u20aa"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v24

    const-string v0, "MR"

    const-string v1, "\ud83c\uddf2\ud83c\uddf7"

    const-string v2, "\u0645\u0648\u0631\u064a\u062a\u0627\u0646\u064a\u0627"

    const-string v3, "Mauritania"

    const-string v4, "MRU"

    const-string v5, "\u0623\u0648\u0642\u064a\u0629 \u0645\u0648\u0631\u064a\u062a\u0627\u0646\u064a\u0629"

    const-string v6, "UM"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v25

    const-string v0, "SO"

    const-string v1, "\ud83c\uddf8\ud83c\uddf4"

    const-string v2, "\u0627\u0644\u0635\u0648\u0645\u0627\u0644"

    const-string v3, "Somalia"

    const-string v4, "SOS"

    const-string v5, "\u0634\u0644\u0646 \u0635\u0648\u0645\u0627\u0644\u064a"

    const-string v6, "Sh"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v26

    const-string v0, "DJ"

    const-string v1, "\ud83c\udde9\ud83c\uddef"

    const-string v2, "\u062c\u064a\u0628\u0648\u062a\u064a"

    const-string v3, "Djibouti"

    const-string v4, "DJF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u062c\u064a\u0628\u0648\u062a\u064a"

    const-string v6, "Fdj"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v27

    const-string v0, "KM"

    const-string v1, "\ud83c\uddf0\ud83c\uddf2"

    const-string v2, "\u062c\u0632\u0631 \u0627\u0644\u0642\u0645\u0631"

    const-string v3, "Comoros"

    const-string v4, "KMF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0642\u0645\u0631\u064a"

    const-string v6, "CF"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v28

    const-string v0, "AF"

    const-string v1, "\ud83c\udde6\ud83c\uddeb"

    const-string v2, "\u0623\u0641\u063a\u0627\u0646\u0633\u062a\u0627\u0646"

    const-string v3, "Afghanistan"

    const-string v4, "AFN"

    const-string v5, "\u0623\u0641\u063a\u0627\u0646\u064a"

    const-string v6, "\u060b"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v29

    const-string v0, "AL"

    const-string v1, "\ud83c\udde6\ud83c\uddf1"

    const-string v2, "\u0623\u0644\u0628\u0627\u0646\u064a\u0627"

    const-string v3, "Albania"

    const-string v4, "ALL"

    const-string v5, "\u0644\u064a\u0643 \u0623\u0644\u0628\u0627\u0646\u064a"

    const-string v6, "L"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v30

    const-string v0, "AM"

    const-string v1, "\ud83c\udde6\ud83c\uddf2"

    const-string v2, "\u0623\u0631\u0645\u064a\u0646\u064a\u0627"

    const-string v3, "Armenia"

    const-string v4, "AMD"

    const-string v5, "\u062f\u0631\u0627\u0645 \u0623\u0631\u0645\u064a\u0646\u064a"

    const-string v6, "\u058f"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v31

    const-string v0, "AO"

    const-string v1, "\ud83c\udde6\ud83c\uddf4"

    const-string v2, "\u0623\u0646\u063a\u0648\u0644\u0627"

    const-string v3, "Angola"

    const-string v4, "AOA"

    const-string v5, "\u0643\u0648\u0627\u0646\u0632\u0627 \u0623\u0646\u063a\u0648\u0644\u064a"

    const-string v6, "Kz"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v32

    const-string v0, "AR"

    const-string v1, "\ud83c\udde6\ud83c\uddf7"

    const-string v2, "\u0627\u0644\u0623\u0631\u062c\u0646\u062a\u064a\u0646"

    const-string v3, "Argentina"

    const-string v4, "ARS"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0623\u0631\u062c\u0646\u062a\u064a\u0646\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v33

    const-string v0, "AT"

    const-string v1, "\ud83c\udde6\ud83c\uddf9"

    const-string v2, "\u0627\u0644\u0646\u0645\u0633\u0627"

    const-string v3, "Austria"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v34

    const-string v0, "AU"

    const-string v1, "\ud83c\udde6\ud83c\uddfa"

    const-string v2, "\u0623\u0633\u062a\u0631\u0627\u0644\u064a\u0627"

    const-string v3, "Australia"

    const-string v4, "AUD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a"

    const-string v6, "A$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v35

    const-string v0, "AZ"

    const-string v1, "\ud83c\udde6\ud83c\uddff"

    const-string v2, "\u0623\u0630\u0631\u0628\u064a\u062c\u0627\u0646"

    const-string v3, "Azerbaijan"

    const-string v4, "AZN"

    const-string v5, "\u0645\u0627\u0646\u0627\u062a \u0623\u0630\u0631\u0628\u064a\u062c\u0627\u0646\u064a"

    const-string v6, "\u20bc"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v36

    const-string v0, "BS"

    const-string v1, "\ud83c\udde7\ud83c\uddf8"

    const-string v2, "\u0627\u0644\u0628\u0627\u0647\u0627\u0645\u0627"

    const-string v3, "Bahamas"

    const-string v4, "BSD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0628\u0647\u0627\u0645\u0627\u0633\u064a"

    const-string v6, "B$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v37

    const-string v0, "BD"

    const-string v1, "\ud83c\udde7\ud83c\udde9"

    const-string v2, "\u0628\u0646\u063a\u0644\u0627\u062f\u064a\u0634"

    const-string v3, "Bangladesh"

    const-string v4, "BDT"

    const-string v5, "\u062a\u0627\u0643\u0627 \u0628\u0646\u063a\u0644\u0627\u062f\u064a\u0634\u064a"

    const-string v6, "\u09f3"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v38

    const-string v0, "BB"

    const-string v1, "\ud83c\udde7\ud83c\udde7"

    const-string v2, "\u0628\u0631\u0628\u0627\u062f\u0648\u0633"

    const-string v3, "Barbados"

    const-string v4, "BBD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0628\u0631\u0628\u0627\u062f\u0648\u0633\u064a"

    const-string v6, "Bds$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v39

    const-string v0, "BY"

    const-string v1, "\ud83c\udde7\ud83c\uddfe"

    const-string v2, "\u0628\u064a\u0644\u0627\u0631\u0648\u0633\u064a\u0627"

    const-string v3, "Belarus"

    const-string v4, "BYN"

    const-string v5, "\u0631\u0648\u0628\u0644 \u0628\u064a\u0644\u0627\u0631\u0648\u0633\u064a"

    const-string v6, "Br"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v40

    const-string v0, "BE"

    const-string v1, "\ud83c\udde7\ud83c\uddea"

    const-string v2, "\u0628\u0644\u062c\u064a\u0643\u0627"

    const-string v3, "Belgium"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v41

    const-string v0, "BZ"

    const-string v1, "\ud83c\udde7\ud83c\uddff"

    const-string v2, "\u0628\u0644\u064a\u0632"

    const-string v3, "Belize"

    const-string v4, "BZD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0628\u0644\u064a\u0632\u064a"

    const-string v6, "BZ$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v42

    const-string v0, "BJ"

    const-string v1, "\ud83c\udde7\ud83c\uddef"

    const-string v2, "\u0628\u0646\u064a\u0646"

    const-string v3, "Benin"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v43

    const-string v0, "BT"

    const-string v1, "\ud83c\udde7\ud83c\uddf9"

    const-string v2, "\u0628\u0648\u062a\u0627\u0646"

    const-string v3, "Bhutan"

    const-string v4, "BTN"

    const-string v5, "\u0646\u063a\u0648\u0644\u062a\u0631\u0645 \u0628\u0648\u062a\u0627\u0646\u064a"

    const-string v6, "Nu."

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v44

    const-string v0, "BO"

    const-string v1, "\ud83c\udde7\ud83c\uddf4"

    const-string v2, "\u0628\u0648\u0644\u064a\u0641\u064a\u0627"

    const-string v3, "Bolivia"

    const-string v4, "BOB"

    const-string v5, "\u0628\u0648\u0644\u064a\u0641\u064a\u0627\u0646\u0648"

    const-string v6, "Bs."

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v45

    const-string v0, "BA"

    const-string v1, "\ud83c\udde7\ud83c\udde6"

    const-string v2, "\u0627\u0644\u0628\u0648\u0633\u0646\u0629 \u0648\u0627\u0644\u0647\u0631\u0633\u0643"

    const-string v3, "Bosnia and Herzegovina"

    const-string v4, "BAM"

    const-string v5, "\u0645\u0627\u0631\u0643 \u0642\u0627\u0628\u0644 \u0644\u0644\u062a\u062d\u0648\u064a\u0644"

    const-string v6, "KM"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v46

    const-string v0, "BW"

    const-string v1, "\ud83c\udde7\ud83c\uddfc"

    const-string v2, "\u0628\u0648\u062a\u0633\u0648\u0627\u0646\u0627"

    const-string v3, "Botswana"

    const-string v4, "BWP"

    const-string v5, "\u0628\u0648\u0644\u0627 \u0628\u0648\u062a\u0633\u0648\u0627\u0646\u064a"

    const-string v6, "P"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v47

    const-string v0, "BR"

    const-string v1, "\ud83c\udde7\ud83c\uddf7"

    const-string v2, "\u0627\u0644\u0628\u0631\u0627\u0632\u064a\u0644"

    const-string v3, "Brazil"

    const-string v4, "BRL"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0628\u0631\u0627\u0632\u064a\u0644\u064a"

    const-string v6, "R$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v48

    const-string v0, "BN"

    const-string v1, "\ud83c\udde7\ud83c\uddf3"

    const-string v2, "\u0628\u0631\u0648\u0646\u0627\u064a"

    const-string v3, "Brunei"

    const-string v4, "BND"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0628\u0631\u0648\u0646\u0627\u064a"

    const-string v6, "B$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v49

    const-string v0, "BG"

    const-string v1, "\ud83c\udde7\ud83c\uddec"

    const-string v2, "\u0628\u0644\u063a\u0627\u0631\u064a\u0627"

    const-string v3, "Bulgaria"

    const-string v4, "BGN"

    const-string v5, "\u0644\u064a\u0641 \u0628\u0644\u063a\u0627\u0631\u064a"

    const-string v6, "\u043b\u0432"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v50

    const-string v0, "BF"

    const-string v1, "\ud83c\udde7\ud83c\uddeb"

    const-string v2, "\u0628\u0648\u0631\u0643\u064a\u0646\u0627 \u0641\u0627\u0633\u0648"

    const-string v3, "Burkina Faso"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v51

    const-string v0, "BI"

    const-string v1, "\ud83c\udde7\ud83c\uddee"

    const-string v2, "\u0628\u0648\u0631\u0648\u0646\u062f\u064a"

    const-string v3, "Burundi"

    const-string v4, "BIF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0628\u0648\u0631\u0648\u0646\u062f\u064a"

    const-string v6, "FBu"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v52

    const-string v0, "KH"

    const-string v1, "\ud83c\uddf0\ud83c\udded"

    const-string v2, "\u0643\u0645\u0628\u0648\u062f\u064a\u0627"

    const-string v3, "Cambodia"

    const-string v4, "KHR"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0643\u0645\u0628\u0648\u062f\u064a"

    const-string v6, "\u17db"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v53

    const-string v0, "CM"

    const-string v1, "\ud83c\udde8\ud83c\uddf2"

    const-string v2, "\u0627\u0644\u0643\u0627\u0645\u064a\u0631\u0648\u0646"

    const-string v3, "Cameroon"

    const-string v4, "XAF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0648\u0633\u0637 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "FCFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v54

    const-string v0, "CA"

    const-string v1, "\ud83c\udde8\ud83c\udde6"

    const-string v2, "\u0643\u0646\u062f\u0627"

    const-string v3, "Canada"

    const-string v4, "CAD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0643\u0646\u062f\u064a"

    const-string v6, "C$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v55

    const-string v0, "CV"

    const-string v1, "\ud83c\udde8\ud83c\uddfb"

    const-string v2, "\u0627\u0644\u0631\u0623\u0633 \u0627\u0644\u0623\u062e\u0636\u0631"

    const-string v3, "Cape Verde"

    const-string v4, "CVE"

    const-string v5, "\u0625\u0633\u0643\u0648\u062f\u0648 \u0627\u0644\u0631\u0623\u0633 \u0627\u0644\u0623\u062e\u0636\u0631"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v56

    const-string v0, "CF"

    const-string v1, "\ud83c\udde8\ud83c\uddeb"

    const-string v2, "\u0623\u0641\u0631\u064a\u0642\u064a\u0627 \u0627\u0644\u0648\u0633\u0637\u0649"

    const-string v3, "Central African Republic"

    const-string v4, "XAF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0648\u0633\u0637 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "FCFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v57

    const-string v0, "TD"

    const-string v1, "\ud83c\uddf9\ud83c\udde9"

    const-string v2, "\u062a\u0634\u0627\u062f"

    const-string v3, "Chad"

    const-string v4, "XAF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0648\u0633\u0637 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "FCFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v58

    const-string v0, "CL"

    const-string v1, "\ud83c\udde8\ud83c\uddf1"

    const-string v2, "\u062a\u0634\u064a\u0644\u064a"

    const-string v3, "Chile"

    const-string v4, "CLP"

    const-string v5, "\u0628\u064a\u0632\u0648 \u062a\u0634\u064a\u0644\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v59

    const-string v0, "CN"

    const-string v1, "\ud83c\udde8\ud83c\uddf3"

    const-string v2, "\u0627\u0644\u0635\u064a\u0646"

    const-string v3, "China"

    const-string v4, "CNY"

    const-string v5, "\u064a\u0648\u0627\u0646 \u0635\u064a\u0646\u064a"

    const-string v6, "\u00a5"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v60

    const-string v0, "CO"

    const-string v1, "\ud83c\udde8\ud83c\uddf4"

    const-string v2, "\u0643\u0648\u0644\u0648\u0645\u0628\u064a\u0627"

    const-string v3, "Colombia"

    const-string v4, "COP"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0643\u0648\u0644\u0648\u0645\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v61

    const-string v0, "CR"

    const-string v1, "\ud83c\udde8\ud83c\uddf7"

    const-string v2, "\u0643\u0648\u0633\u062a\u0627\u0631\u064a\u0643\u0627"

    const-string v3, "Costa Rica"

    const-string v4, "CRC"

    const-string v5, "\u0643\u0648\u0644\u0648\u0646 \u0643\u0648\u0633\u062a\u0627\u0631\u064a\u0643\u064a"

    const-string v6, "\u20a1"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v62

    const-string v0, "HR"

    const-string v1, "\ud83c\udded\ud83c\uddf7"

    const-string v2, "\u0643\u0631\u0648\u0627\u062a\u064a\u0627"

    const-string v3, "Croatia"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v63

    const-string v0, "CU"

    const-string v1, "\ud83c\udde8\ud83c\uddfa"

    const-string v2, "\u0643\u0648\u0628\u0627"

    const-string v3, "Cuba"

    const-string v4, "CUP"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0643\u0648\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v64

    const-string v0, "CY"

    const-string v1, "\ud83c\udde8\ud83c\uddfe"

    const-string v2, "\u0642\u0628\u0631\u0635"

    const-string v3, "Cyprus"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v65

    const-string v0, "CZ"

    const-string v1, "\ud83c\udde8\ud83c\uddff"

    const-string v2, "\u0627\u0644\u062a\u0634\u064a\u0643"

    const-string v3, "Czechia"

    const-string v4, "CZK"

    const-string v5, "\u0643\u0631\u0648\u0646 \u062a\u0634\u064a\u0643\u064a"

    const-string v6, "K\u010d"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v66

    const-string v0, "CD"

    const-string v1, "\ud83c\udde8\ud83c\udde9"

    const-string v2, "\u0627\u0644\u0643\u0648\u0646\u063a\u0648 \u0627\u0644\u062f\u064a\u0645\u0642\u0631\u0627\u0637\u064a\u0629"

    const-string v3, "DR Congo"

    const-string v4, "CDF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0643\u0648\u0646\u063a\u0648\u0644\u064a"

    const-string v6, "FC"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v67

    const-string v0, "DK"

    const-string v1, "\ud83c\udde9\ud83c\uddf0"

    const-string v2, "\u0627\u0644\u062f\u0646\u0645\u0627\u0631\u0643"

    const-string v3, "Denmark"

    const-string v4, "DKK"

    const-string v5, "\u0643\u0631\u0648\u0646 \u062f\u0646\u0645\u0627\u0631\u0643\u064a"

    const-string v6, "kr"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v68

    const-string v0, "DO"

    const-string v1, "\ud83c\udde9\ud83c\uddf4"

    const-string v2, "\u0627\u0644\u062f\u0648\u0645\u064a\u0646\u064a\u0643\u0627\u0646"

    const-string v3, "Dominican Republic"

    const-string v4, "DOP"

    const-string v5, "\u0628\u064a\u0632\u0648 \u062f\u0648\u0645\u064a\u0646\u064a\u0643\u0627\u0646\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v69

    const-string v0, "EC"

    const-string v1, "\ud83c\uddea\ud83c\udde8"

    const-string v2, "\u0627\u0644\u0625\u0643\u0648\u0627\u062f\u0648\u0631"

    const-string v3, "Ecuador"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v70

    const-string v0, "SV"

    const-string v1, "\ud83c\uddf8\ud83c\uddfb"

    const-string v2, "\u0627\u0644\u0633\u0644\u0641\u0627\u062f\u0648\u0631"

    const-string v3, "El Salvador"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v71

    const-string v0, "GQ"

    const-string v1, "\ud83c\uddec\ud83c\uddf6"

    const-string v2, "\u063a\u064a\u0646\u064a\u0627 \u0627\u0644\u0627\u0633\u062a\u0648\u0627\u0626\u064a\u0629"

    const-string v3, "Equatorial Guinea"

    const-string v4, "XAF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0648\u0633\u0637 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "FCFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v72

    const-string v0, "ER"

    const-string v1, "\ud83c\uddea\ud83c\uddf7"

    const-string v2, "\u0625\u0631\u064a\u062a\u0631\u064a\u0627"

    const-string v3, "Eritrea"

    const-string v4, "ERN"

    const-string v5, "\u0646\u0627\u0643\u0641\u0627 \u0625\u0631\u064a\u062a\u0631\u064a"

    const-string v6, "Nfk"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v73

    const-string v0, "EE"

    const-string v1, "\ud83c\uddea\ud83c\uddea"

    const-string v2, "\u0625\u0633\u062a\u0648\u0646\u064a\u0627"

    const-string v3, "Estonia"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v74

    const-string v0, "SZ"

    const-string v1, "\ud83c\uddf8\ud83c\uddff"

    const-string v2, "\u0625\u0633\u0648\u0627\u062a\u064a\u0646\u064a"

    const-string v3, "Eswatini"

    const-string v4, "SZL"

    const-string v5, "\u0644\u064a\u0644\u0627\u0646\u062c\u064a"

    const-string v6, "E"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v75

    const-string v0, "ET"

    const-string v1, "\ud83c\uddea\ud83c\uddf9"

    const-string v2, "\u0625\u062b\u064a\u0648\u0628\u064a\u0627"

    const-string v3, "Ethiopia"

    const-string v4, "ETB"

    const-string v5, "\u0628\u064a\u0631 \u0625\u062b\u064a\u0648\u0628\u064a"

    const-string v6, "Br"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v76

    const-string v0, "FJ"

    const-string v1, "\ud83c\uddeb\ud83c\uddef"

    const-string v2, "\u0641\u064a\u062c\u064a"

    const-string v3, "Fiji"

    const-string v4, "FJD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0641\u064a\u062c\u064a"

    const-string v6, "FJ$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v77

    const-string v0, "FI"

    const-string v1, "\ud83c\uddeb\ud83c\uddee"

    const-string v2, "\u0641\u0646\u0644\u0646\u062f\u0627"

    const-string v3, "Finland"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v78

    const-string v0, "FR"

    const-string v1, "\ud83c\uddeb\ud83c\uddf7"

    const-string v2, "\u0641\u0631\u0646\u0633\u0627"

    const-string v3, "France"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v79

    const-string v0, "GA"

    const-string v1, "\ud83c\uddec\ud83c\udde6"

    const-string v2, "\u0627\u0644\u063a\u0627\u0628\u0648\u0646"

    const-string v3, "Gabon"

    const-string v4, "XAF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0648\u0633\u0637 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "FCFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v80

    const-string v0, "GM"

    const-string v1, "\ud83c\uddec\ud83c\uddf2"

    const-string v2, "\u063a\u0627\u0645\u0628\u064a\u0627"

    const-string v3, "Gambia"

    const-string v4, "GMD"

    const-string v5, "\u062f\u0644\u0627\u0633\u064a \u063a\u0627\u0645\u0628\u064a"

    const-string v6, "D"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v81

    const-string v0, "GE"

    const-string v1, "\ud83c\uddec\ud83c\uddea"

    const-string v2, "\u062c\u0648\u0631\u062c\u064a\u0627"

    const-string v3, "Georgia"

    const-string v4, "GEL"

    const-string v5, "\u0644\u0627\u0631\u064a \u062c\u0648\u0631\u062c\u064a"

    const-string v6, "\u20be"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v82

    const-string v0, "DE"

    const-string v1, "\ud83c\udde9\ud83c\uddea"

    const-string v2, "\u0623\u0644\u0645\u0627\u0646\u064a\u0627"

    const-string v3, "Germany"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v83

    const-string v0, "GH"

    const-string v1, "\ud83c\uddec\ud83c\udded"

    const-string v2, "\u063a\u0627\u0646\u0627"

    const-string v3, "Ghana"

    const-string v4, "GHS"

    const-string v5, "\u0633\u064a\u062f\u064a \u063a\u0627\u0646\u064a"

    const-string v6, "\u20b5"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v84

    const-string v0, "GR"

    const-string v1, "\ud83c\uddec\ud83c\uddf7"

    const-string v2, "\u0627\u0644\u064a\u0648\u0646\u0627\u0646"

    const-string v3, "Greece"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v85

    const-string v0, "GD"

    const-string v1, "\ud83c\uddec\ud83c\udde9"

    const-string v2, "\u063a\u0631\u064a\u0646\u0627\u062f\u0627"

    const-string v3, "Grenada"

    const-string v4, "XCD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0634\u0631\u0642 \u0643\u0627\u0631\u064a\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v86

    const-string v0, "GT"

    const-string v1, "\ud83c\uddec\ud83c\uddf9"

    const-string v2, "\u063a\u0648\u0627\u062a\u064a\u0645\u0627\u0644\u0627"

    const-string v3, "Guatemala"

    const-string v4, "GTQ"

    const-string v5, "\u0643\u064a\u062a\u0632\u0627\u0644"

    const-string v6, "Q"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v87

    const-string v0, "GN"

    const-string v1, "\ud83c\uddec\ud83c\uddf3"

    const-string v2, "\u063a\u064a\u0646\u064a\u0627"

    const-string v3, "Guinea"

    const-string v4, "GNF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u064a\u0646\u064a"

    const-string v6, "FG"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v88

    const-string v0, "GW"

    const-string v1, "\ud83c\uddec\ud83c\uddfc"

    const-string v2, "\u063a\u064a\u0646\u064a\u0627 \u0628\u064a\u0633\u0627\u0648"

    const-string v3, "Guinea-Bissau"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v89

    const-string v0, "GY"

    const-string v1, "\ud83c\uddec\ud83c\uddfe"

    const-string v2, "\u063a\u064a\u0627\u0646\u0627"

    const-string v3, "Guyana"

    const-string v4, "GYD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u063a\u064a\u0627\u0646\u0627\u064a"

    const-string v6, "G$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v90

    const-string v0, "HT"

    const-string v1, "\ud83c\udded\ud83c\uddf9"

    const-string v2, "\u0647\u0627\u064a\u062a\u064a"

    const-string v3, "Haiti"

    const-string v4, "HTG"

    const-string v5, "\u062c\u0648\u0631\u062f \u0647\u0627\u064a\u062a\u064a"

    const-string v6, "G"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v91

    const-string v0, "HN"

    const-string v1, "\ud83c\udded\ud83c\uddf3"

    const-string v2, "\u0647\u0646\u062f\u0648\u0631\u0627\u0633"

    const-string v3, "Honduras"

    const-string v4, "HNL"

    const-string v5, "\u0644\u064a\u0645\u0628\u064a\u0631\u0627 \u0647\u0646\u062f\u0648\u0631\u0627\u0633\u064a"

    const-string v6, "L"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v92

    const-string v0, "HU"

    const-string v1, "\ud83c\udded\ud83c\uddfa"

    const-string v2, "\u0627\u0644\u0645\u062c\u0631"

    const-string v3, "Hungary"

    const-string v4, "HUF"

    const-string v5, "\u0641\u0648\u0631\u0646\u062a \u0645\u062c\u0631\u064a"

    const-string v6, "Ft"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v93

    const-string v0, "IS"

    const-string v1, "\ud83c\uddee\ud83c\uddf8"

    const-string v2, "\u0622\u064a\u0633\u0644\u0646\u062f\u0627"

    const-string v3, "Iceland"

    const-string v4, "ISK"

    const-string v5, "\u0643\u0631\u0648\u0646 \u0622\u064a\u0633\u0644\u0646\u062f\u064a"

    const-string v6, "kr"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v94

    const-string v0, "IN"

    const-string v1, "\ud83c\uddee\ud83c\uddf3"

    const-string v2, "\u0627\u0644\u0647\u0646\u062f"

    const-string v3, "India"

    const-string v4, "INR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0647\u0646\u062f\u064a\u0629"

    const-string v6, "\u20b9"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v95

    const-string v0, "ID"

    const-string v1, "\ud83c\uddee\ud83c\udde9"

    const-string v2, "\u0625\u0646\u062f\u0648\u0646\u064a\u0633\u064a\u0627"

    const-string v3, "Indonesia"

    const-string v4, "IDR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0625\u0646\u062f\u0648\u0646\u064a\u0633\u064a\u0629"

    const-string v6, "Rp"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v96

    const-string v0, "IR"

    const-string v1, "\ud83c\uddee\ud83c\uddf7"

    const-string v2, "\u0625\u064a\u0631\u0627\u0646"

    const-string v3, "Iran"

    const-string v4, "IRR"

    const-string v5, "\u0631\u064a\u0627\u0644 \u0625\u064a\u0631\u0627\u0646\u064a"

    const-string v6, "\ufdfc"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v97

    const-string v0, "IE"

    const-string v1, "\ud83c\uddee\ud83c\uddea"

    const-string v2, "\u0623\u064a\u0631\u0644\u0646\u062f\u0627"

    const-string v3, "Ireland"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v98

    const-string v0, "IL"

    const-string v1, "\ud83c\uddee\ud83c\uddf1"

    const-string v2, "\u0625\u0633\u0631\u0627\u0626\u064a\u0644"

    const-string v3, "Israel"

    const-string v4, "ILS"

    const-string v5, "\u0634\u064a\u0643\u0644"

    const-string v6, "\u20aa"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v99

    const-string v0, "IT"

    const-string v1, "\ud83c\uddee\ud83c\uddf9"

    const-string v2, "\u0625\u064a\u0637\u0627\u0644\u064a\u0627"

    const-string v3, "Italy"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v100

    const-string v0, "CI"

    const-string v1, "\ud83c\udde8\ud83c\uddee"

    const-string v2, "\u0633\u0627\u062d\u0644 \u0627\u0644\u0639\u0627\u062c"

    const-string v3, "Ivory Coast"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v101

    const-string v0, "JM"

    const-string v1, "\ud83c\uddef\ud83c\uddf2"

    const-string v2, "\u062c\u0627\u0645\u0627\u064a\u0643\u0627"

    const-string v3, "Jamaica"

    const-string v4, "JMD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u062c\u0627\u0645\u0627\u064a\u0643\u064a"

    const-string v6, "J$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v102

    const-string v0, "JP"

    const-string v1, "\ud83c\uddef\ud83c\uddf5"

    const-string v2, "\u0627\u0644\u064a\u0627\u0628\u0627\u0646"

    const-string v3, "Japan"

    const-string v4, "JPY"

    const-string v5, "\u064a\u0646 \u064a\u0627\u0628\u0627\u0646\u064a"

    const-string v6, "\u00a5"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v103

    const-string v0, "KZ"

    const-string v1, "\ud83c\uddf0\ud83c\uddff"

    const-string v2, "\u0643\u0627\u0632\u0627\u062e\u0633\u062a\u0627\u0646"

    const-string v3, "Kazakhstan"

    const-string v4, "KZT"

    const-string v5, "\u062a\u064a\u0646\u063a \u0643\u0627\u0632\u0627\u062e\u0633\u062a\u0627\u0646\u064a"

    const-string v6, "\u20b8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v104

    const-string v0, "KE"

    const-string v1, "\ud83c\uddf0\ud83c\uddea"

    const-string v2, "\u0643\u064a\u0646\u064a\u0627"

    const-string v3, "Kenya"

    const-string v4, "KES"

    const-string v5, "\u0634\u0644\u0646 \u0643\u064a\u0646\u064a"

    const-string v6, "KSh"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v105

    const-string v0, "KI"

    const-string v1, "\ud83c\uddf0\ud83c\uddee"

    const-string v2, "\u0643\u064a\u0631\u064a\u0628\u0627\u062a\u064a"

    const-string v3, "Kiribati"

    const-string v4, "AUD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a"

    const-string v6, "A$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v106

    const-string v0, "KG"

    const-string v1, "\ud83c\uddf0\ud83c\uddec"

    const-string v2, "\u0642\u064a\u0631\u063a\u064a\u0632\u0633\u062a\u0627\u0646"

    const-string v3, "Kyrgyzstan"

    const-string v4, "KGS"

    const-string v5, "\u0633\u0648\u0645 \u0642\u064a\u0631\u063a\u064a\u0632\u064a"

    const-string v6, "\u0441"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v107

    const-string v0, "LA"

    const-string v1, "\ud83c\uddf1\ud83c\udde6"

    const-string v2, "\u0644\u0627\u0648\u0633"

    const-string v3, "Laos"

    const-string v4, "LAK"

    const-string v5, "\u0643\u064a\u0628 \u0644\u0627\u0648\u0633\u064a"

    const-string v6, "\u20ad"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v108

    const-string v0, "LV"

    const-string v1, "\ud83c\uddf1\ud83c\uddfb"

    const-string v2, "\u0644\u0627\u062a\u0641\u064a\u0627"

    const-string v3, "Latvia"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v109

    const-string v0, "LS"

    const-string v1, "\ud83c\uddf1\ud83c\uddf8"

    const-string v2, "\u0644\u064a\u0633\u0648\u062a\u0648"

    const-string v3, "Lesotho"

    const-string v4, "LSL"

    const-string v5, "\u0644\u0648\u062a\u064a \u0644\u064a\u0633\u0648\u062a\u0648"

    const-string v6, "L"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v110

    const-string v0, "LR"

    const-string v1, "\ud83c\uddf1\ud83c\uddef"

    const-string v2, "\u0644\u064a\u0628\u064a\u0631\u064a\u0627"

    const-string v3, "Liberia"

    const-string v4, "LRD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0644\u064a\u0628\u064a\u0631\u064a"

    const-string v6, "L$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v111

    const-string v0, "LI"

    const-string v1, "\ud83c\uddf1\ud83c\uddee"

    const-string v2, "\u0644\u064a\u062e\u062a\u0646\u0634\u062a\u0627\u064a\u0646"

    const-string v3, "Liechtenstein"

    const-string v4, "CHF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0633\u0648\u064a\u0633\u0631\u064a"

    const-string v6, "\u20a3"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v112

    const-string v0, "LT"

    const-string v1, "\ud83c\uddf1\ud83c\uddf9"

    const-string v2, "\u0644\u064a\u062a\u0648\u0627\u0646\u064a\u0627"

    const-string v3, "Lithuania"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v113

    const-string v0, "LU"

    const-string v1, "\ud83c\uddf1\ud83c\uddfa"

    const-string v2, "\u0644\u0648\u0643\u0633\u0645\u0628\u0648\u0631\u063a"

    const-string v3, "Luxembourg"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v114

    const-string v0, "MG"

    const-string v1, "\ud83c\uddf2\ud83c\uddec"

    const-string v2, "\u0645\u062f\u063a\u0634\u0642\u0631"

    const-string v3, "Madagascar"

    const-string v4, "MGA"

    const-string v5, "\u0623\u0631\u064a\u0627\u0631\u064a \u0645\u062f\u063a\u0634\u0642\u0631\u064a"

    const-string v6, "Ar"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v115

    const-string v0, "MW"

    const-string v1, "\ud83c\uddf2\ud83c\uddfc"

    const-string v2, "\u0645\u0627\u0644\u0627\u0648\u064a"

    const-string v3, "Malawi"

    const-string v4, "MWK"

    const-string v5, "\u0643\u0648\u0627\u0634\u0627 \u0645\u0627\u0644\u0627\u0648\u064a"

    const-string v6, "MK"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v116

    const-string v0, "MY"

    const-string v1, "\ud83c\uddf2\ud83c\uddfe"

    const-string v2, "\u0645\u0627\u0644\u064a\u0632\u064a\u0627"

    const-string v3, "Malaysia"

    const-string v4, "MYR"

    const-string v5, "\u0631\u064a\u0646\u063a\u064a\u062a \u0645\u0627\u0644\u064a\u0632\u064a"

    const-string v6, "RM"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v117

    const-string v0, "MV"

    const-string v1, "\ud83c\uddf2\ud83c\uddfb"

    const-string v2, "\u0627\u0644\u0645\u0627\u0644\u062f\u064a\u0641"

    const-string v3, "Maldives"

    const-string v4, "MVR"

    const-string v5, "\u0631\u0648\u0641\u064a\u0629 \u0645\u0627\u0644\u062f\u064a\u0641\u064a\u0629"

    const-string v6, "Rf"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v118

    const-string v0, "ML"

    const-string v1, "\ud83c\uddf2\ud83c\uddf1"

    const-string v2, "\u0645\u0627\u0644\u064a"

    const-string v3, "Mali"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v119

    const-string v0, "MT"

    const-string v1, "\ud83c\uddf2\ud83c\uddf9"

    const-string v2, "\u0645\u0627\u0644\u0637\u0627"

    const-string v3, "Malta"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v120

    const-string v0, "MH"

    const-string v1, "\ud83c\uddf2\ud83c\udded"

    const-string v2, "\u062c\u0632\u0631 \u0645\u0627\u0631\u0634\u0627\u0644"

    const-string v3, "Marshall Islands"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v121

    const-string v0, "MU"

    const-string v1, "\ud83c\uddf2\ud83c\uddfa"

    const-string v2, "\u0645\u0648\u0631\u064a\u0634\u064a\u0648\u0633"

    const-string v3, "Mauritius"

    const-string v4, "MUR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0645\u0648\u0631\u064a\u0634\u064a\u0629"

    const-string v6, "\u20a8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v122

    const-string v0, "MX"

    const-string v1, "\ud83c\uddf2\ud83c\uddfd"

    const-string v2, "\u0627\u0644\u0645\u0643\u0633\u064a\u0643"

    const-string v3, "Mexico"

    const-string v4, "MXN"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0645\u0643\u0633\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v123

    const-string v0, "FM"

    const-string v1, "\ud83c\uddeb\ud83c\uddf2"

    const-string v2, "\u0645\u064a\u0643\u0631\u0648\u0646\u064a\u0632\u064a\u0627"

    const-string v3, "Micronesia"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v124

    const-string v0, "MD"

    const-string v1, "\ud83c\uddf2\ud83c\udde9"

    const-string v2, "\u0645\u0648\u0644\u062f\u0648\u0641\u0627"

    const-string v3, "Moldova"

    const-string v4, "MDL"

    const-string v5, "\u0644\u064a\u0648 \u0645\u0648\u0644\u062f\u0648\u0641\u064a"

    const-string v6, "L"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v125

    const-string v0, "MC"

    const-string v1, "\ud83c\uddf2\ud83c\udde8"

    const-string v2, "\u0645\u0648\u0646\u0627\u0643\u0648"

    const-string v3, "Monaco"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v126

    const-string v0, "MN"

    const-string v1, "\ud83c\uddf2\ud83c\uddf3"

    const-string v2, "\u0645\u0646\u063a\u0648\u0644\u064a\u0627"

    const-string v3, "Mongolia"

    const-string v4, "MNT"

    const-string v5, "\u062a\u0648\u063a\u0631\u0648\u063a \u0645\u0646\u063a\u0648\u0644\u064a"

    const-string v6, "\u20ae"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v127

    const-string v0, "ME"

    const-string v1, "\ud83c\uddf2\ud83c\uddea"

    const-string v2, "\u0627\u0644\u062c\u0628\u0644 \u0627\u0644\u0623\u0633\u0648\u062f"

    const-string v3, "Montenegro"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v128

    const-string v0, "MZ"

    const-string v1, "\ud83c\uddf2\ud83c\uddff"

    const-string v2, "\u0645\u0648\u0632\u0645\u0628\u064a\u0642"

    const-string v3, "Mozambique"

    const-string v4, "MZN"

    const-string v5, "\u0645\u062a\u0643\u0627\u0644 \u0645\u0648\u0632\u0645\u0628\u064a\u0642\u064a"

    const-string v6, "MT"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v129

    const-string v0, "MM"

    const-string v1, "\ud83c\uddf2\ud83c\uddf2"

    const-string v2, "\u0645\u064a\u0627\u0646\u0645\u0627\u0631"

    const-string v3, "Myanmar"

    const-string v4, "MMK"

    const-string v5, "\u0643\u064a\u0627\u062a \u0645\u064a\u0627\u0646\u0645\u0627\u0631\u064a"

    const-string v6, "K"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v130

    const-string v0, "NA"

    const-string v1, "\ud83c\uddf3\ud83c\udde6"

    const-string v2, "\u0646\u0627\u0645\u064a\u0628\u064a\u0627"

    const-string v3, "Namibia"

    const-string v4, "NAD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0646\u0627\u0645\u064a\u0628\u064a"

    const-string v6, "N$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v131

    const-string v0, "NR"

    const-string v1, "\ud83c\uddf3\ud83c\uddf7"

    const-string v2, "\u0646\u0627\u0648\u0631\u0648"

    const-string v3, "Nauru"

    const-string v4, "AUD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a"

    const-string v6, "A$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v132

    const-string v0, "NP"

    const-string v1, "\ud83c\uddf3\ud83c\uddf5"

    const-string v2, "\u0646\u064a\u0628\u0627\u0644"

    const-string v3, "Nepal"

    const-string v4, "NPR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0646\u064a\u0628\u0627\u0644\u064a\u0629"

    const-string v6, "\u20a8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v133

    const-string v0, "NL"

    const-string v1, "\ud83c\uddf3\ud83c\uddf1"

    const-string v2, "\u0647\u0648\u0644\u0646\u062f\u0627"

    const-string v3, "Netherlands"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v134

    const-string v0, "NZ"

    const-string v1, "\ud83c\uddf3\ud83c\uddff"

    const-string v2, "\u0646\u064a\u0648\u0632\u064a\u0644\u0646\u062f\u0627"

    const-string v3, "New Zealand"

    const-string v4, "NZD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0646\u064a\u0648\u0632\u064a\u0644\u0646\u062f\u064a"

    const-string v6, "NZ$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v135

    const-string v0, "NI"

    const-string v1, "\ud83c\uddf3\ud83c\uddee"

    const-string v2, "\u0646\u064a\u0643\u0627\u0631\u0627\u063a\u0648\u0627"

    const-string v3, "Nicaragua"

    const-string v4, "NIO"

    const-string v5, "\u0643\u0648\u0631\u062f\u0648\u0628\u0627 \u0646\u064a\u0643\u0627\u0631\u0627\u063a\u0648\u064a"

    const-string v6, "C$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v136

    const-string v0, "NE"

    const-string v1, "\ud83c\uddf3\ud83c\uddea"

    const-string v2, "\u0627\u0644\u0646\u064a\u062c\u0631"

    const-string v3, "Niger"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v137

    const-string v0, "NG"

    const-string v1, "\ud83c\uddf3\ud83c\uddec"

    const-string v2, "\u0646\u064a\u062c\u064a\u0631\u064a\u0627"

    const-string v3, "Nigeria"

    const-string v4, "NGN"

    const-string v5, "\u0646\u0627\u064a\u0631\u0627 \u0646\u064a\u062c\u064a\u0631\u064a"

    const-string v6, "\u20a6"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v138

    const-string v0, "KP"

    const-string v1, "\ud83c\uddf0\ud83c\uddf5"

    const-string v2, "\u0643\u0648\u0631\u064a\u0627 \u0627\u0644\u0634\u0645\u0627\u0644\u064a\u0629"

    const-string v3, "North Korea"

    const-string v4, "KPW"

    const-string v5, "\u0648\u0648\u0646 \u0643\u0648\u0631\u064a \u0634\u0645\u0627\u0644\u064a"

    const-string v6, "\u20a9"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v139

    const-string v0, "MK"

    const-string v1, "\ud83c\uddf2\ud83c\uddf0"

    const-string v2, "\u0645\u0642\u062f\u0648\u0646\u064a\u0627 \u0627\u0644\u0634\u0645\u0627\u0644\u064a\u0629"

    const-string v3, "North Macedonia"

    const-string v4, "MKD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0645\u0642\u062f\u0648\u0646\u064a"

    const-string v6, "\u0434\u0435\u043d"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v140

    const-string v0, "NO"

    const-string v1, "\ud83c\uddf3\ud83c\uddf4"

    const-string v2, "\u0627\u0644\u0646\u0631\u0648\u064a\u062c"

    const-string v3, "Norway"

    const-string v4, "NOK"

    const-string v5, "\u0643\u0631\u0648\u0646 \u0646\u0631\u0648\u064a\u062c\u064a"

    const-string v6, "kr"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v141

    const-string v0, "PK"

    const-string v1, "\ud83c\uddf5\ud83c\uddf0"

    const-string v2, "\u0628\u0627\u0643\u0633\u062a\u0627\u0646"

    const-string v3, "Pakistan"

    const-string v4, "PKR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0628\u0627\u0643\u0633\u062a\u0627\u0646\u064a\u0629"

    const-string v6, "\u20a8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v142

    const-string v0, "PW"

    const-string v1, "\ud83c\uddf5\ud83c\uddfc"

    const-string v2, "\u0628\u0627\u0644\u0627\u0648"

    const-string v3, "Palau"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v143

    const-string v0, "PA"

    const-string v1, "\ud83c\uddf5\ud83c\udde6"

    const-string v2, "\u0628\u0646\u0645\u0627"

    const-string v3, "Panama"

    const-string v4, "PAB"

    const-string v5, "\u0628\u0627\u0644\u0628\u0648\u0627 \u0628\u0646\u0645\u064a"

    const-string v6, "B/."

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v144

    const-string v0, "PG"

    const-string v1, "\ud83c\uddf5\ud83c\uddec"

    const-string v2, "\u0628\u0627\u0628\u0648\u0627 \u063a\u064a\u0646\u064a\u0627 \u0627\u0644\u062c\u062f\u064a\u062f\u0629"

    const-string v3, "Papua New Guinea"

    const-string v4, "PGK"

    const-string v5, "\u0643\u064a\u0646\u0627 \u0628\u0627\u0628\u0648\u064a"

    const-string v6, "K"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v145

    const-string v0, "PY"

    const-string v1, "\ud83c\uddf5\ud83c\uddfe"

    const-string v2, "\u0628\u0627\u0631\u0627\u063a\u0648\u0627\u064a"

    const-string v3, "Paraguay"

    const-string v4, "PYG"

    const-string v5, "\u063a\u0648\u0627\u0631\u0627\u0646\u064a \u0628\u0627\u0631\u0627\u063a\u0648\u0627\u064a"

    const-string v6, "\u20b2"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v146

    const-string v0, "PE"

    const-string v1, "\ud83c\uddf5\ud83c\uddea"

    const-string v2, "\u0628\u064a\u0631\u0648"

    const-string v3, "Peru"

    const-string v4, "PEN"

    const-string v5, "\u0633\u0648\u0644 \u0628\u064a\u0631\u0648\u0641\u064a"

    const-string v6, "S/"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v147

    const-string v0, "PH"

    const-string v1, "\ud83c\uddf5\ud83c\udded"

    const-string v2, "\u0627\u0644\u0641\u0644\u0628\u064a\u0646"

    const-string v3, "Philippines"

    const-string v4, "PHP"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0641\u0644\u0628\u064a\u0646\u064a"

    const-string v6, "\u20b1"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v148

    const-string v0, "PL"

    const-string v1, "\ud83c\uddf5\ud83c\uddf1"

    const-string v2, "\u0628\u0648\u0644\u0646\u062f\u0627"

    const-string v3, "Poland"

    const-string v4, "PLN"

    const-string v5, "\u0632\u0644\u0648\u062a\u064a \u0628\u0648\u0644\u0646\u062f\u064a"

    const-string v6, "z\u0142"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v149

    const-string v0, "PT"

    const-string v1, "\ud83c\uddf5\ud83c\uddf9"

    const-string v2, "\u0627\u0644\u0628\u0631\u062a\u063a\u0627\u0644"

    const-string v3, "Portugal"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v150

    const-string v0, "RO"

    const-string v1, "\ud83c\uddf7\ud83c\uddf4"

    const-string v2, "\u0631\u0648\u0645\u0627\u0646\u064a\u0627"

    const-string v3, "Romania"

    const-string v4, "RON"

    const-string v5, "\u0644\u064a\u0648 \u0631\u0648\u0645\u0627\u0646\u064a"

    const-string v6, "lei"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v151

    const-string v0, "RU"

    const-string v1, "\ud83c\uddf7\ud83c\uddfa"

    const-string v2, "\u0631\u0648\u0633\u064a\u0627"

    const-string v3, "Russia"

    const-string v4, "RUB"

    const-string v5, "\u0631\u0648\u0628\u0644 \u0631\u0648\u0633\u064a"

    const-string v6, "\u20bd"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v152

    const-string v0, "RW"

    const-string v1, "\ud83c\uddf7\ud83c\uddfc"

    const-string v2, "\u0631\u0648\u0627\u0646\u062f\u0627"

    const-string v3, "Rwanda"

    const-string v4, "RWF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0631\u0648\u0627\u0646\u062f\u064a"

    const-string v6, "FRw"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v153

    const-string v0, "KN"

    const-string v1, "\ud83c\uddf0\ud83c\uddf3"

    const-string v2, "\u0633\u0627\u0646\u062a \u0643\u064a\u062a\u0633 \u0648\u0646\u064a\u0641\u064a\u0633"

    const-string v3, "Saint Kitts and Nevis"

    const-string v4, "XCD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0634\u0631\u0642 \u0643\u0627\u0631\u064a\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v154

    const-string v0, "LC"

    const-string v1, "\ud83c\uddf1\ud83c\udde8"

    const-string v2, "\u0633\u0627\u0646\u062a \u0644\u0648\u0633\u064a\u0627"

    const-string v3, "Saint Lucia"

    const-string v4, "XCD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0634\u0631\u0642 \u0643\u0627\u0631\u064a\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v155

    const-string v0, "VC"

    const-string v1, "\ud83c\uddfb\ud83c\udde8"

    const-string v2, "\u0633\u0627\u0646\u062a \u0641\u064a\u0646\u0633\u0646\u062a"

    const-string v3, "Saint Vincent and the Grenadines"

    const-string v4, "XCD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0634\u0631\u0642 \u0643\u0627\u0631\u064a\u0628\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v156

    const-string v0, "WS"

    const-string v1, "\ud83c\uddfc\ud83c\uddf8"

    const-string v2, "\u0633\u0627\u0645\u0648\u0627"

    const-string v3, "Samoa"

    const-string v4, "WST"

    const-string v5, "\u062a\u0627\u0644\u0627 \u0633\u0627\u0645\u0648\u064a"

    const-string v6, "WS$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v157

    const-string v0, "SM"

    const-string v1, "\ud83c\uddf8\ud83c\uddf2"

    const-string v2, "\u0633\u0627\u0646 \u0645\u0627\u0631\u064a\u0646\u0648"

    const-string v3, "San Marino"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v158

    const-string v0, "ST"

    const-string v1, "\ud83c\uddf8\ud83c\uddf9"

    const-string v2, "\u0633\u0627\u0648 \u062a\u0648\u0645\u064a \u0648\u0628\u0631\u064a\u0646\u0633\u064a\u0628\u064a"

    const-string v3, "S\u00e3o Tom\u00e9 and Pr\u00edncipe"

    const-string v4, "STN"

    const-string v5, "\u062f\u0648\u0628\u0631\u0627"

    const-string v6, "Db"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v159

    const-string v0, "SN"

    const-string v1, "\ud83c\uddf8\ud83c\uddf3"

    const-string v2, "\u0627\u0644\u0633\u0646\u063a\u0627\u0644"

    const-string v3, "Senegal"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v160

    const-string v0, "RS"

    const-string v1, "\ud83c\uddf7\ud83c\uddf8"

    const-string v2, "\u0635\u0631\u0628\u064a\u0627"

    const-string v3, "Serbia"

    const-string v4, "RSD"

    const-string v5, "\u062f\u064a\u0646\u0627\u0631 \u0635\u0631\u0628\u064a"

    const-string v6, "\u0434\u0438\u043d."

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v161

    const-string v0, "SC"

    const-string v1, "\ud83c\uddf8\ud83c\udde8"

    const-string v2, "\u0633\u064a\u0634\u0644"

    const-string v3, "Seychelles"

    const-string v4, "SCR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0633\u064a\u0634\u0644\u064a\u0629"

    const-string v6, "\u20a8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v162

    const-string v0, "SL"

    const-string v1, "\ud83c\uddf8\ud83c\uddf1"

    const-string v2, "\u0633\u064a\u0631\u0627\u0644\u064a\u0648\u0646"

    const-string v3, "Sierra Leone"

    const-string v4, "SLE"

    const-string v5, "\u0644\u064a\u0648\u0646 \u0633\u064a\u0631\u0627\u0644\u064a\u0648\u0646\u064a"

    const-string v6, "Le"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v163

    const-string v0, "SG"

    const-string v1, "\ud83c\uddf8\ud83c\uddec"

    const-string v2, "\u0633\u0646\u063a\u0627\u0641\u0648\u0631\u0629"

    const-string v3, "Singapore"

    const-string v4, "SGD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0633\u0646\u063a\u0627\u0641\u0648\u0631\u064a"

    const-string v6, "S$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v164

    const-string v0, "SK"

    const-string v1, "\ud83c\uddf8\ud83c\uddf0"

    const-string v2, "\u0633\u0644\u0648\u0641\u0627\u0643\u064a\u0627"

    const-string v3, "Slovakia"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v165

    const-string v0, "SI"

    const-string v1, "\ud83c\uddf8\ud83c\uddee"

    const-string v2, "\u0633\u0644\u0648\u0641\u064a\u0646\u064a\u0627"

    const-string v3, "Slovenia"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v166

    const-string v0, "SB"

    const-string v1, "\ud83c\uddf8\ud83c\udde7"

    const-string v2, "\u062c\u0632\u0631 \u0633\u0644\u064a\u0645\u0627\u0646"

    const-string v3, "Solomon Islands"

    const-string v4, "SBD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0633\u0644\u064a\u0645\u0627\u0646\u064a"

    const-string v6, "SI$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v167

    const-string v0, "ZA"

    const-string v1, "\ud83c\uddff\ud83c\udde6"

    const-string v2, "\u062c\u0646\u0648\u0628 \u0623\u0641\u0631\u064a\u0642\u064a\u0627"

    const-string v3, "South Africa"

    const-string v4, "ZAR"

    const-string v5, "\u0631\u0627\u0646\u062f \u062c\u0646\u0648\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "R"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v168

    const-string v0, "KR"

    const-string v1, "\ud83c\uddf0\ud83c\uddf7"

    const-string v2, "\u0643\u0648\u0631\u064a\u0627 \u0627\u0644\u062c\u0646\u0648\u0628\u064a\u0629"

    const-string v3, "South Korea"

    const-string v4, "KRW"

    const-string v5, "\u0648\u0648\u0646 \u0643\u0648\u0631\u064a"

    const-string v6, "\u20a9"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v169

    const-string v0, "SS"

    const-string v1, "\ud83c\uddf8\ud83c\uddf8"

    const-string v2, "\u062c\u0646\u0648\u0628 \u0627\u0644\u0633\u0648\u062f\u0627\u0646"

    const-string v3, "South Sudan"

    const-string v4, "SSP"

    const-string v5, "\u062c\u0646\u064a\u0647 \u062c\u0646\u0648\u0628 \u0633\u0648\u062f\u0627\u0646\u064a"

    const-string v6, "\u00a3"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v170

    const-string v0, "ES"

    const-string v1, "\ud83c\uddea\ud83c\uddf8"

    const-string v2, "\u0625\u0633\u0628\u0627\u0646\u064a\u0627"

    const-string v3, "Spain"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v171

    const-string v0, "LK"

    const-string v1, "\ud83c\uddf1\ud83c\uddf0"

    const-string v2, "\u0633\u0631\u064a\u0644\u0627\u0646\u0643\u0627"

    const-string v3, "Sri Lanka"

    const-string v4, "LKR"

    const-string v5, "\u0631\u0648\u0628\u064a\u0629 \u0633\u0631\u064a\u0644\u0627\u0646\u0643\u064a\u0629"

    const-string v6, "\u20a8"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v172

    const-string v0, "SR"

    const-string v1, "\ud83c\uddf8\ud83c\uddf7"

    const-string v2, "\u0633\u0648\u0631\u064a\u0646\u0627\u0645"

    const-string v3, "Suriname"

    const-string v4, "SRD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0633\u0648\u0631\u064a\u0646\u0627\u0645\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v173

    const-string v0, "SE"

    const-string v1, "\ud83c\uddf8\ud83c\uddea"

    const-string v2, "\u0627\u0644\u0633\u0648\u064a\u062f"

    const-string v3, "Sweden"

    const-string v4, "SEK"

    const-string v5, "\u0643\u0631\u0648\u0646\u0629 \u0633\u0648\u064a\u062f\u064a\u0629"

    const-string v6, "kr"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v174

    const-string v0, "CH"

    const-string v1, "\ud83c\udde8\ud83c\udded"

    const-string v2, "\u0633\u0648\u064a\u0633\u0631\u0627"

    const-string v3, "Switzerland"

    const-string v4, "CHF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u0633\u0648\u064a\u0633\u0631\u064a"

    const-string v6, "\u20a3"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v175

    const-string v0, "TW"

    const-string v1, "\ud83c\uddf9\ud83c\uddfc"

    const-string v2, "\u062a\u0627\u064a\u0648\u0627\u0646"

    const-string v3, "Taiwan"

    const-string v4, "TWD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u062a\u0627\u064a\u0648\u0627\u0646\u064a"

    const-string v6, "NT$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v176

    const-string v0, "TJ"

    const-string v1, "\ud83c\uddf9\ud83c\uddef"

    const-string v2, "\u0637\u0627\u062c\u064a\u0643\u0633\u062a\u0627\u0646"

    const-string v3, "Tajikistan"

    const-string v4, "TJS"

    const-string v5, "\u0633\u0648\u0645\u0648\u0646\u064a \u0637\u0627\u062c\u064a\u0643\u064a"

    const-string v6, "SM"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v177

    const-string v0, "TZ"

    const-string v1, "\ud83c\uddf9\ud83c\uddff"

    const-string v2, "\u062a\u0646\u0632\u0627\u0646\u064a\u0627"

    const-string v3, "Tanzania"

    const-string v4, "TZS"

    const-string v5, "\u0634\u0644\u0646 \u062a\u0646\u0632\u0627\u0646\u064a"

    const-string v6, "TSh"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v178

    const-string v0, "TH"

    const-string v1, "\ud83c\uddf9\ud83c\udded"

    const-string v2, "\u062a\u0627\u064a\u0644\u0627\u0646\u062f"

    const-string v3, "Thailand"

    const-string v4, "THB"

    const-string v5, "\u0628\u0627\u062a \u062a\u0627\u064a\u0644\u0627\u0646\u062f\u064a"

    const-string v6, "\u0e3f"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v179

    const-string v0, "TL"

    const-string v1, "\ud83c\uddf9\ud83c\uddf1"

    const-string v2, "\u062a\u064a\u0645\u0648\u0631 \u0627\u0644\u0634\u0631\u0642\u064a\u0629"

    const-string v3, "Timor-Leste"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v180

    const-string v0, "TG"

    const-string v1, "\ud83c\uddf9\ud83c\uddec"

    const-string v2, "\u062a\u0648\u063a\u0648"

    const-string v3, "Togo"

    const-string v4, "XOF"

    const-string v5, "\u0641\u0631\u0646\u0643 \u063a\u0631\u0628 \u0623\u0641\u0631\u064a\u0642\u064a"

    const-string v6, "CFA"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v181

    const-string v0, "TO"

    const-string v1, "\ud83c\uddf9\ud83c\uddf4"

    const-string v2, "\u062a\u0648\u0646\u063a\u0627"

    const-string v3, "Tonga"

    const-string v4, "TOP"

    const-string v5, "\u0628\u0627\u0646\u063a\u0627 \u062a\u0648\u0646\u063a\u064a"

    const-string v6, "T$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v182

    const-string v0, "TT"

    const-string v1, "\ud83c\uddf9\ud83c\uddf9"

    const-string v2, "\u062a\u0631\u064a\u0646\u064a\u062f\u0627\u062f \u0648\u062a\u0648\u0628\u0627\u063a\u0648"

    const-string v3, "Trinidad and Tobago"

    const-string v4, "TTD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u062a\u0631\u064a\u0646\u064a\u062f\u0627\u062f\u064a"

    const-string v6, "TT$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v183

    const-string v0, "TR"

    const-string v1, "\ud83c\uddf9\ud83c\uddf7"

    const-string v2, "\u062a\u0631\u0643\u064a\u0627"

    const-string v3, "Turkey"

    const-string v4, "TRY"

    const-string v5, "\u0644\u064a\u0631\u0629 \u062a\u0631\u0643\u064a\u0629"

    const-string v6, "\u20ba"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v184

    const-string v0, "TM"

    const-string v1, "\ud83c\uddf9\ud83c\uddf2"

    const-string v2, "\u062a\u0631\u0643\u0645\u0627\u0646\u0633\u062a\u0627\u0646"

    const-string v3, "Turkmenistan"

    const-string v4, "TMT"

    const-string v5, "\u0645\u0627\u0646\u0627\u062a \u062a\u0631\u0643\u0645\u0627\u0646\u064a"

    const-string v6, "m"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v185

    const-string v0, "TV"

    const-string v1, "\ud83c\uddf9\ud83c\uddfb"

    const-string v2, "\u062a\u0648\u0641\u0627\u0644\u0648"

    const-string v3, "Tuvalu"

    const-string v4, "AUD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a"

    const-string v6, "A$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v186

    const-string v0, "UG"

    const-string v1, "\ud83c\uddfa\ud83c\uddec"

    const-string v2, "\u0623\u0648\u063a\u0646\u062f\u0627"

    const-string v3, "Uganda"

    const-string v4, "UGX"

    const-string v5, "\u0634\u0644\u0646 \u0623\u0648\u063a\u0646\u062f\u064a"

    const-string v6, "USh"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v187

    const-string v0, "UA"

    const-string v1, "\ud83c\uddfa\ud83c\udde6"

    const-string v2, "\u0623\u0648\u0643\u0631\u0627\u0646\u064a\u0627"

    const-string v3, "Ukraine"

    const-string v4, "UAH"

    const-string v5, "\u0647\u0631\u064a\u0641\u0646\u064a\u0627 \u0623\u0648\u0643\u0631\u0627\u0646\u064a"

    const-string v6, "\u20b4"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v188

    const-string v0, "GB"

    const-string v1, "\ud83c\uddec\ud83c\udde7"

    const-string v2, "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0645\u062a\u062d\u062f\u0629"

    const-string v3, "United Kingdom"

    const-string v4, "GBP"

    const-string v5, "\u062c\u0646\u064a\u0647 \u0625\u0633\u062a\u0631\u0644\u064a\u0646\u064a"

    const-string v6, "\u00a3"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v189

    const-string v0, "US"

    const-string v1, "\ud83c\uddfa\ud83c\uddf8"

    const-string v2, "\u0627\u0644\u0648\u0644\u0627\u064a\u0627\u062a \u0627\u0644\u0645\u062a\u062d\u062f\u0629"

    const-string v3, "United States"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v190

    const-string v0, "UY"

    const-string v1, "\ud83c\uddfa\ud83c\uddfe"

    const-string v2, "\u0623\u0648\u0631\u0648\u063a\u0648\u0627\u064a"

    const-string v3, "Uruguay"

    const-string v4, "UYU"

    const-string v5, "\u0628\u064a\u0632\u0648 \u0623\u0648\u0631\u0648\u063a\u0648\u0627\u064a"

    const-string v6, "$U"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v191

    const-string v0, "UZ"

    const-string v1, "\ud83c\uddfa\ud83c\uddff"

    const-string v2, "\u0623\u0648\u0632\u0628\u0643\u0633\u062a\u0627\u0646"

    const-string v3, "Uzbekistan"

    const-string v4, "UZS"

    const-string v5, "\u0633\u0648\u0645 \u0623\u0648\u0632\u0628\u0643\u064a"

    const-string v6, "so\'m"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v192

    const-string v0, "VU"

    const-string v1, "\ud83c\uddfb\ud83c\uddfa"

    const-string v2, "\u0641\u0627\u0646\u0648\u0627\u062a\u0648"

    const-string v3, "Vanuatu"

    const-string v4, "VUV"

    const-string v5, "\u0641\u0627\u062a\u0648 \u0641\u0627\u0646\u0648\u0627\u062a\u0648"

    const-string v6, "VT"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v193

    const-string v0, "VA"

    const-string v1, "\ud83c\uddfb\ud83c\udde6"

    const-string v2, "\u0627\u0644\u0641\u0627\u062a\u064a\u0643\u0627\u0646"

    const-string v3, "Vatican City"

    const-string v4, "EUR"

    const-string v5, "\u064a\u0648\u0631\u0648"

    const-string v6, "\u20ac"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v194

    const-string v0, "VE"

    const-string v1, "\ud83c\uddfb\ud83c\uddea"

    const-string v2, "\u0641\u0646\u0632\u0648\u064a\u0644\u0627"

    const-string v3, "Venezuela"

    const-string v4, "VES"

    const-string v5, "\u0628\u0648\u0644\u064a\u0641\u0627\u0631 \u0641\u0646\u0632\u0648\u064a\u0644\u064a"

    const-string v6, "Bs."

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v195

    const-string v0, "VN"

    const-string v1, "\ud83c\uddfb\ud83c\uddf3"

    const-string v2, "\u0641\u064a\u062a\u0646\u0627\u0645"

    const-string v3, "Vietnam"

    const-string v4, "VND"

    const-string v5, "\u062f\u0648\u0646\u063a \u0641\u064a\u062a\u0646\u0627\u0645\u064a"

    const-string v6, "\u20ab"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v196

    const-string v0, "ZM"

    const-string v1, "\ud83c\uddff\ud83c\uddf2"

    const-string v2, "\u0632\u0627\u0645\u0628\u064a\u0627"

    const-string v3, "Zambia"

    const-string v4, "ZMW"

    const-string v5, "\u0643\u0648\u0627\u0634\u0627 \u0632\u0627\u0645\u0628\u064a"

    const-string v6, "ZK"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v197

    const-string v0, "ZW"

    const-string v1, "\ud83c\uddff\ud83c\uddfc"

    const-string v2, "\u0632\u064a\u0645\u0628\u0627\u0628\u0648\u064a"

    const-string v3, "Zimbabwe"

    const-string v4, "ZWG"

    const-string v5, "\u0632\u064a\u063a \u0632\u064a\u0645\u0628\u0627\u0628\u0648\u064a"

    const-string v6, "ZiG"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v198

    const-string v0, "HK"

    const-string v1, "\ud83c\udded\ud83c\uddf0"

    const-string v2, "\u0647\u0648\u0646\u063a \u0643\u0648\u0646\u063a"

    const-string v3, "Hong Kong"

    const-string v4, "HKD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0647\u0648\u0646\u063a \u0643\u0648\u0646\u063a\u064a"

    const-string v6, "HK$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v199

    const-string v0, "MO"

    const-string v1, "\ud83c\uddf2\ud83c\uddf4"

    const-string v2, "\u0645\u0627\u0643\u0627\u0648"

    const-string v3, "Macau"

    const-string v4, "MOP"

    const-string v5, "\u0628\u0627\u062a\u0627\u0643\u0627 \u0645\u0627\u0643\u0627\u0648\u064a"

    const-string v6, "MOP$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v200

    const-string v0, "GL"

    const-string v1, "\ud83c\uddec\ud83c\uddf1"

    const-string v2, "\u063a\u0631\u064a\u0646\u0644\u0627\u0646\u062f"

    const-string v3, "Greenland"

    const-string v4, "DKK"

    const-string v5, "\u0643\u0631\u0648\u0646 \u062f\u0646\u0645\u0627\u0631\u0643\u064a"

    const-string v6, "kr"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v201

    const-string v0, "PR"

    const-string v1, "\ud83c\uddf5\ud83c\uddf7"

    const-string v2, "\u0628\u0648\u0631\u062a\u0648\u0631\u064a\u0643\u0648"

    const-string v3, "Puerto Rico"

    const-string v4, "USD"

    const-string v5, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v6, "$"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v202

    filled-new-array/range {v7 .. v202}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    const-string v1, "LY"

    const-string v2, "SA"

    const-string v3, "AE"

    const-string v4, "EG"

    const-string v5, "TN"

    const-string v6, "DZ"

    const-string v7, "MA"

    const-string v8, "SD"

    const-string v9, "JO"

    const-string v10, "IQ"

    const-string v11, "KW"

    const-string v12, "QA"

    const-string v13, "BH"

    const-string v14, "OM"

    const-string v15, "US"

    const-string v16, "GB"

    const-string v17, "FR"

    const-string v18, "DE"

    const-string v19, "TR"

    const-string v20, "IT"

    const-string v21, "ES"

    const-string v22, "RU"

    const-string v23, "CN"

    const-string v24, "IN"

    const-string v25, "CA"

    const-string v26, "AU"

    const-string v27, "JP"

    const-string v28, "KR"

    .line 216
    filled-new-array/range {v1 .. v28}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Countries;->POPULAR:[Ljava/lang/String;

    const-string v1, "LYD"

    const-string v2, "USD"

    const-string v3, "EUR"

    const-string v4, "GBP"

    const-string v5, "SAR"

    const-string v6, "AED"

    const-string v7, "EGP"

    const-string v8, "TND"

    const-string v9, "DZD"

    const-string v10, "MAD"

    const-string v11, "QAR"

    const-string v12, "KWD"

    const-string v13, "BHD"

    const-string v14, "OMR"

    const-string v15, "JOD"

    const-string v16, "TRY"

    const-string v17, "CHF"

    const-string v18, "CNY"

    const-string v19, "JPY"

    const-string v20, "CAD"

    const-string v21, "AUD"

    const-string v22, "RUB"

    const-string v23, "INR"

    const-string v24, "KRW"

    const-string v25, "IQD"

    const-string v26, "SYP"

    const-string v27, "YER"

    const-string v28, "SDG"

    .line 223
    filled-new-array/range {v1 .. v28}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Countries;->POPULAR_CUR:[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static byCode(Ljava/lang/String;)[Ljava/lang/String;
    .locals 7

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 232
    :cond_0
    sget-object v1, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_2

    aget-object v5, v1, v4

    aget-object v6, v5, v3

    invoke-virtual {v6, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    return-object v5

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public static currencyByCode(Ljava/lang/String;)[Ljava/lang/String;
    .locals 7

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    .line 269
    :cond_0
    sget-object v1, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    aget-object v4, v1, v3

    const/4 v5, 0x3

    aget-object v6, v4, v5

    invoke-virtual {v6, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    aget-object p0, v4, v5

    const/4 v0, 0x4

    aget-object v0, v4, v0

    const/4 v1, 0x5

    aget-object v1, v4, v1

    filled-new-array {p0, v0, v1}, [Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public static currencyList()Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 251
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 252
    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 253
    sget-object v2, Lcom/marwanalsidi/masrofi/Countries;->POPULAR_CUR:[Ljava/lang/String;

    array-length v3, v2

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    if-ge v5, v3, :cond_0

    aget-object v6, v2, v5

    invoke-virtual {v1, v6}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 254
    :cond_0
    sget-object v2, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v3, v2

    move v5, v4

    :goto_1
    const/4 v6, 0x3

    if-ge v5, v3, :cond_2

    aget-object v7, v2, v5

    aget-object v8, v7, v6

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_1

    aget-object v6, v7, v6

    invoke-virtual {v1, v6}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 255
    :cond_2
    invoke-virtual {v1}, Ljava/util/LinkedHashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 256
    sget-object v3, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v5, v3

    move v7, v4

    :goto_3
    if-ge v7, v5, :cond_3

    aget-object v8, v3, v7

    .line 257
    aget-object v9, v8, v6

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_4

    .line 258
    aget-object v2, v8, v6

    const/4 v3, 0x4

    aget-object v3, v8, v3

    const/4 v5, 0x5

    aget-object v5, v8, v5

    filled-new-array {v2, v3, v5}, [Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_4
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_5
    return-object v0
.end method

.method public static pickerList()Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 238
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 239
    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 240
    sget-object v2, Lcom/marwanalsidi/masrofi/Countries;->POPULAR:[Ljava/lang/String;

    array-length v3, v2

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    if-ge v5, v3, :cond_0

    aget-object v6, v2, v5

    invoke-virtual {v1, v6}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 241
    :cond_0
    sget-object v2, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v3, v2

    move v5, v4

    :goto_1
    if-ge v5, v3, :cond_1

    aget-object v6, v2, v5

    aget-object v6, v6, v4

    invoke-virtual {v1, v6}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 242
    :cond_1
    invoke-virtual {v1}, Ljava/util/LinkedHashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 243
    invoke-static {v2}, Lcom/marwanalsidi/masrofi/Countries;->byCode(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_2

    .line 244
    aget-object v3, v2, v4

    const/4 v5, 0x1

    aget-object v5, v2, v5

    const/4 v6, 0x2

    aget-object v2, v2, v6

    filled-new-array {v3, v5, v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    return-object v0
.end method
