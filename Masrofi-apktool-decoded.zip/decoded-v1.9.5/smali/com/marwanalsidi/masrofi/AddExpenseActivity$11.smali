.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPay()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$g:I


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 221
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->val$g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    # v1.9.5 — حماية كاملة (الالتقاط الصامت في الأعلى يكفي نظرياً؛ هذا حزام أمان)
    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->val$g:I

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$700(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
