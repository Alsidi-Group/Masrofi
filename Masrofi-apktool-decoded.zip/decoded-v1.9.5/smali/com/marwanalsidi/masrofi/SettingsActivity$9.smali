.class Lcom/marwanalsidi/masrofi/SettingsActivity$9;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->currencySection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 285
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$9;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    .line 286
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$9;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->access$100(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    return-void
.end method
