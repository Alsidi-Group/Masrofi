.class Lcom/marwanalsidi/masrofi/AboutActivity$1;
.super Ljava/lang/Object;
.source "AboutActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AboutActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AboutActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V
    .locals 0

    .line 24
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$1;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 25
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$1;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/AboutActivity;->finish()V

    return-void
.end method
