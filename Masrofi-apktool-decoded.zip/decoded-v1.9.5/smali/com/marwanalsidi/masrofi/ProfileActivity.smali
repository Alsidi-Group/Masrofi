.class public Lcom/marwanalsidi/masrofi/ProfileActivity;
.super Landroid/app/Activity;
.source "ProfileActivity.java"


# static fields
.field private static final REQ_PICK:I = 0x3c


# instance fields
.field private country:Ljava/lang/String;

.field private imgAvatar:Landroid/widget/ImageView;

.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 28
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const-string v0, "LY"

    .line 33
    iput-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    const/4 v0, -0x1

    .line 34
    iput v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/ProfileActivity;)V
    .locals 0

    .line 28
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->pickAvatar()V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0

    .line 28
    invoke-direct {p0, p1, p2}, Lcom/marwanalsidi/masrofi/ProfileActivity;->pickCountry(Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;)V
    .locals 0

    .line 28
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->pickCurrency(Landroid/widget/TextView;)V

    return-void
.end method

.method static synthetic access$300(Lcom/marwanalsidi/masrofi/ProfileActivity;)Ljava/lang/String;
    .locals 0

    .line 28
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$400(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0

    .line 28
    invoke-direct/range {p0 .. p5}, Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCountryList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method

.method static synthetic access$500(Lcom/marwanalsidi/masrofi/ProfileActivity;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0

    .line 28
    invoke-direct {p0, p1, p2, p3}, Lcom/marwanalsidi/masrofi/ProfileActivity;->applyCountry(Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method

.method static synthetic access$600(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V
    .locals 0

    .line 28
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCurrencyList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V

    return-void
.end method

.method static synthetic access$700(Lcom/marwanalsidi/masrofi/ProfileActivity;)Landroid/widget/ImageView;
    .locals 0

    .line 28
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    return-object p0
.end method

.method private applyCountry(Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 3

    .line 224
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    .line 225
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Prefs;->setCountryCode(Landroid/content/Context;Ljava/lang/String;)V

    .line 226
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Countries;->byCode(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    const/4 p3, 0x3

    .line 229
    aget-object p3, p1, p3

    invoke-static {p0, p3}, Lcom/marwanalsidi/masrofi/Prefs;->setCurrencyCode(Landroid/content/Context;Ljava/lang/String;)V

    .line 230
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v0, 0x1

    aget-object v1, p1, v0

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    const-string v1, "  "

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    const/4 v1, 0x2

    aget-object v2, p1, v1

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 231
    aget-object p2, p1, v0

    aget-object p1, p1, v1

    filled-new-array {p2, p1}, [Ljava/lang/Object;

    move-result-object p1

    const p2, 0x7f0800a4

    invoke-virtual {p0, p2, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private countryRow()Landroid/widget/TextView;
    .locals 3

    .line 161
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/Countries;->byCode(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    .line 162
    aget-object v1, v0, v1

    goto :goto_0

    :cond_0
    const-string v1, "\ud83c\udff3"

    :goto_0
    if-eqz v0, :cond_1

    const/4 v2, 0x2

    .line 163
    aget-object v0, v0, v2

    goto :goto_1

    :cond_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    .line 164
    :goto_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p0

    const v0, 0x7f040004

    .line 165
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method private currencyRow()Landroid/widget/TextView;
    .locals 4

    .line 170
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyInfo(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object v0

    .line 171
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    aget-object v3, v0, v2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "  ("

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/4 v3, 0x1

    aget-object v0, v0, v3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v2, v1}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p0

    const v0, 0x7f040004

    .line 172
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method private decodeScaled(Landroid/net/Uri;I)Landroid/graphics/Bitmap;
    .locals 4

    const/4 v0, 0x0

    .line 345
    :try_start_0
    new-instance v1, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v1}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v2, 0x1

    .line 346
    iput-boolean v2, v1, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 347
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3

    .line 348
    invoke-static {v3, v0, v1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    if-eqz v3, :cond_0

    .line 349
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    .line 351
    :cond_0
    :goto_0
    iget v3, v1, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    div-int/2addr v3, v2

    if-gt v3, p2, :cond_3

    iget v3, v1, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    div-int/2addr v3, v2

    if-le v3, p2, :cond_1

    goto :goto_1

    .line 353
    :cond_1
    new-instance p2, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {p2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 354
    iput v2, p2, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 355
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0

    .line 356
    invoke-static {p0, v0, p2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    if-eqz p0, :cond_2

    .line 357
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_2
    return-object p1

    :cond_3
    :goto_1
    mul-int/lit8 v2, v2, 0x2

    goto :goto_0

    :catch_0
    return-object v0
.end method

.method private fillCountryList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Landroid/widget/TextView;",
            "Landroid/widget/EditText;",
            ")V"
        }
    .end annotation

    .line 210
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 211
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p3, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    .line 212
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    .line 213
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_0

    aget-object v1, v0, v3

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 214
    invoke-virtual {v1, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    aget-object v1, v0, v2

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 215
    invoke-virtual {v1, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 216
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    aget-object v4, v0, v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, "  "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget-object v3, v0, v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    aget-object v2, v0, v2

    iget-object v3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    .line 217
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    new-instance v3, Lcom/marwanalsidi/masrofi/ProfileActivity$7;

    invoke-direct {v3, p0, v0, p4, p5}, Lcom/marwanalsidi/masrofi/ProfileActivity$7;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;[Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    .line 216
    invoke-static {p0, v1, v2, v3}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method private fillCurrencyList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    .line 269
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 270
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p3, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    .line 271
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyCode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 272
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    .line 273
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_0

    aget-object v2, v1, v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 274
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    aget-object v2, v1, v3

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 275
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    .line 276
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v4, v1, v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "  ("

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/4 v4, 0x2

    aget-object v4, v1, v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ")"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aget-object v3, v1, v3

    .line 277
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    new-instance v4, Lcom/marwanalsidi/masrofi/ProfileActivity$9;

    invoke-direct {v4, p0, v1, p4}, Lcom/marwanalsidi/masrofi/ProfileActivity$9;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;[Ljava/lang/String;Landroid/widget/TextView;)V

    .line 276
    invoke-static {p0, v2, v3, v4}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method private loadAvatar()Landroid/graphics/Bitmap;
    .locals 2

    .line 365
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->avatar(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    .line 366
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return-object v1

    .line 367
    :cond_0
    :try_start_0
    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    return-object v1
.end method

.method private pickAvatar()V
    .locals 7

    .line 291
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 292
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v0, 0x7f0800a2

    .line 293
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcom/marwanalsidi/masrofi/ProfileActivity$10;

    invoke-direct {v1, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity$10;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 305
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->avatar(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    const v0, 0x7f0800a9

    .line 306
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcom/marwanalsidi/masrofi/ProfileActivity$11;

    invoke-direct {v1, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity$11;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V

    invoke-static {p0, v0, v3, v1}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_0
    const v0, 0x7f0800a1

    .line 317
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const v0, 0x7f08002a

    .line 318
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    move-object v0, p0

    .line 317
    invoke-static/range {v0 .. v6}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private pickCountry(Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 12

    .line 179
    invoke-static {}, Lcom/marwanalsidi/masrofi/Countries;->pickerList()Ljava/util/List;

    move-result-object v7

    .line 180
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 181
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 183
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 184
    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v0, 0x7f0800ac

    .line 186
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v1, 0x20001

    invoke-static {p0, v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v10

    .line 187
    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v0, 0x6

    .line 188
    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 189
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 190
    invoke-virtual {v0, v9}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 191
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x43be0000    # 380.0f

    .line 192
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 191
    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 193
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v3, ""

    move-object v0, p0

    move-object v1, v9

    move-object v2, v7

    move-object v4, p1

    move-object v5, p2

    .line 195
    invoke-direct/range {v0 .. v5}, Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCountryList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    .line 196
    new-instance v11, Lcom/marwanalsidi/masrofi/ProfileActivity$6;

    move-object v0, v11

    move-object v1, p0

    move-object v2, v9

    move-object v3, v7

    invoke-direct/range {v0 .. v5}, Lcom/marwanalsidi/masrofi/ProfileActivity$6;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Landroid/widget/TextView;Landroid/widget/EditText;)V

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const v0, 0x7f08009c

    .line 204
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const v0, 0x7f08002a

    .line 205
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    move-object v0, p0

    move-object v2, v8

    move-object v6, v7

    .line 204
    invoke-static/range {v0 .. v6}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private pickCurrency(Landroid/widget/TextView;)V
    .locals 8

    .line 238
    invoke-static {}, Lcom/marwanalsidi/masrofi/Countries;->currencyList()Ljava/util/List;

    move-result-object v0

    .line 239
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 240
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 242
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 243
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x7f0800ac

    .line 245
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v4, 0x20001

    invoke-static {p0, v1, v4}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v1

    .line 246
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v4, 0x6

    .line 247
    invoke-direct {p0, v4}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 248
    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 249
    invoke-virtual {v4, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 250
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x43be0000    # 380.0f

    .line 251
    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    const/4 v7, -0x1

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 250
    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 252
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v4, ""

    .line 254
    invoke-direct {p0, v2, v0, v4, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCurrencyList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 255
    new-instance v4, Lcom/marwanalsidi/masrofi/ProfileActivity$8;

    invoke-direct {v4, p0, v2, v0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity$8;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Landroid/widget/TextView;)V

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const p1, 0x7f08009d

    .line 263
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const p1, 0x7f08002a

    .line 264
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 263
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private spacer(I)Landroid/view/View;
    .locals 2

    .line 153
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 154
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p1, p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    const/4 p1, 0x1

    invoke-direct {v1, p1, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 37
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 3

    .line 323
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/16 v0, 0x3c

    if-ne p1, v0, :cond_1

    const/4 p1, -0x1

    if-ne p2, p1, :cond_1

    if-eqz p3, :cond_1

    .line 324
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    if-eqz p1, :cond_1

    const p1, 0x7f0800a8

    .line 326
    :try_start_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    const/16 p3, 0x200

    invoke-direct {p0, p2, p3}, Lcom/marwanalsidi/masrofi/ProfileActivity;->decodeScaled(Landroid/net/Uri;I)Landroid/graphics/Bitmap;

    move-result-object p2

    if-nez p2, :cond_0

    .line 327
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p2}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 328
    :cond_0
    new-instance p3, Ljava/io/File;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    const-string v1, "profile.png"

    invoke-direct {p3, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 329
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 330
    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x5c

    invoke-virtual {p2, v1, v2, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 331
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V

    .line 332
    invoke-virtual {p3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p3

    invoke-static {p0, p3}, Lcom/marwanalsidi/masrofi/Prefs;->setAvatar(Landroid/content/Context;Ljava/lang/String;)V

    .line 333
    iget-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    invoke-virtual {p3, p2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 334
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    const/4 p3, 0x0

    invoke-virtual {p2, p3, p3, p3, p3}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 335
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    const p3, 0x106000d

    invoke-virtual {p2, p3}, Landroid/widget/ImageView;->setBackgroundResource(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 337
    :catch_0
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11

    .line 41
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->setTheme(I)V

    .line 42
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 43
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->tGen:I

    .line 45
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 46
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x7f010002

    .line 47
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 50
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    .line 51
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v3, 0x10

    .line 52
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v4, 0x41800000    # 16.0f

    .line 53
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v1, v5, v6, v7, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 55
    new-instance v5, Landroid/widget/ImageView;

    invoke-direct {v5, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v6, 0x7f04000e

    .line 56
    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setImageResource(I)V

    const v6, 0x7f040007

    .line 57
    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    const/high16 v6, 0x41000000    # 8.0f

    .line 58
    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v5, v7, v8, v9, v6}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 59
    new-instance v6, Lcom/marwanalsidi/masrofi/ProfileActivity$1;

    invoke-direct {v6, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity$1;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V

    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 62
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42180000    # 38.0f

    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-direct {v6, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v5, 0x7f0800ad

    .line 64
    invoke-virtual {p0, v5}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/high16 v6, 0x41980000    # 19.0f

    invoke-static {p0, v5, v6, v2}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v5

    .line 65
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v6, v2, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v7, 0x41400000    # 12.0f

    .line 67
    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v6, v7, v2, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 68
    invoke-virtual {v1, v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 69
    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 71
    new-instance v1, Landroid/widget/ScrollView;

    invoke-direct {v1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 72
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 73
    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 74
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    const/high16 v7, 0x40800000    # 4.0f

    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    const/high16 v8, 0x41c00000    # 24.0f

    invoke-static {p0, v8}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v5, v6, v7, v4, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 75
    invoke-virtual {v1, v5}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 78
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 79
    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 80
    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 81
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->loadAvatar()Landroid/graphics/Bitmap;

    move-result-object v6

    const/16 v7, 0x60

    invoke-static {p0, v6, v7}, Lcom/marwanalsidi/masrofi/Ui;->circleImage(Landroid/content/Context;Landroid/graphics/Bitmap;I)Landroid/widget/ImageView;

    move-result-object v6

    iput-object v6, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    .line 82
    new-instance v7, Lcom/marwanalsidi/masrofi/ProfileActivity$2;

    invoke-direct {v7, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity$2;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V

    invoke-virtual {v6, v7}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 85
    iget-object v6, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->imgAvatar:Landroid/widget/ImageView;

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v6, 0x7f0800a2

    .line 86
    invoke-virtual {p0, v6}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    const/high16 v7, 0x40c00000    # 6.0f

    .line 87
    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v6, v2, v7, v2, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 88
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 89
    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 90
    invoke-direct {p0, v3}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 93
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v2

    .line 94
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v3

    .line 95
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->userName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    .line 96
    invoke-virtual {v3, v4}, Lcom/marwanalsidi/masrofi/DBHelper;->userRow(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const v6, 0x7f0800a7

    .line 98
    invoke-virtual {p0, v6}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v7

    const/high16 v8, 0x41500000    # 13.0f

    invoke-static {p0, v7, v8, v0}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 99
    invoke-virtual {p0, v6}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const v7, 0x20001

    invoke-static {p0, v6, v7}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v6

    if-eqz v3, :cond_0

    .line 100
    aget-object v7, v3, v0

    if-eqz v7, :cond_0

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    aget-object v7, v3, v0

    goto :goto_0

    :cond_0
    move-object v7, v4

    :goto_0
    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 101
    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v7, 0xc

    .line 102
    invoke-direct {p0, v7}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v9, 0x7f0800a6

    .line 104
    invoke-virtual {p0, v9}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-static {p0, v10, v8, v0}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v10

    invoke-virtual {v2, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 105
    invoke-virtual {p0, v9}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v9

    const v10, 0x20021

    invoke-static {p0, v9, v10}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v9

    if-eqz v3, :cond_1

    const/4 v10, 0x2

    .line 107
    aget-object v3, v3, v10

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->email(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    :goto_1
    invoke-virtual {v9, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 108
    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 109
    invoke-direct {p0, v7}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 111
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->countryCode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->country:Ljava/lang/String;

    const v3, 0x7f0800a3

    .line 112
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3, v8, v0}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 113
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->countryRow()Landroid/widget/TextView;

    move-result-object v3

    .line 114
    new-instance v10, Lcom/marwanalsidi/masrofi/ProfileActivity$3;

    invoke-direct {v10, p0, v3, v9}, Lcom/marwanalsidi/masrofi/ProfileActivity$3;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;Landroid/widget/EditText;)V

    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 117
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 118
    invoke-direct {p0, v7}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v3, 0x7f0800a5

    .line 120
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3, v8, v0}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 121
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->currencyRow()Landroid/widget/TextView;

    move-result-object v0

    .line 122
    new-instance v3, Lcom/marwanalsidi/masrofi/ProfileActivity$4;

    invoke-direct {v3, p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity$4;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;)V

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 125
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 126
    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v0, 0x12

    .line 127
    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->spacer(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v0, 0x7f0800aa

    .line 130
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->btnAccent(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    .line 131
    new-instance v2, Lcom/marwanalsidi/masrofi/ProfileActivity$5;

    invoke-direct {v2, p0, v6, v9, v4}, Lcom/marwanalsidi/masrofi/ProfileActivity$5;-><init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/EditText;Landroid/widget/EditText;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 146
    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 148
    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 149
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 372
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 373
    iget v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->recreate()V

    :cond_0
    return-void
.end method
