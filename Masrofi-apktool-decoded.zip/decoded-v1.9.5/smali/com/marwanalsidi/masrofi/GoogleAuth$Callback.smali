.class public interface abstract Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;
.super Ljava/lang/Object;
.source "GoogleAuth.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/GoogleAuth;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onDone(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
.end method
