.class public final Lcom/marwanalsidi/masrofi/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final bg_badge:I = 0x7f040000

.field public static final bg_btn:I = 0x7f040001

.field public static final bg_card:I = 0x7f040002

.field public static final bg_chip_on:I = 0x7f040003

.field public static final bg_edit:I = 0x7f040004

.field public static final bg_error:I = 0x7f040005

.field public static final bg_hero:I = 0x7f040006

.field public static final bg_icon:I = 0x7f040007

.field public static final bg_icon_accent:I = 0x7f040008

.field public static final bg_logo:I = 0x7f040009

.field public static final bg_row:I = 0x7f04000a

.field public static final bg_update:I = 0x7f04000b

.field public static final ic_about:I = 0x7f04000c

.field public static final ic_add:I = 0x7f04000d

.field public static final ic_back:I = 0x7f04000e

.field public static final ic_calc:I = 0x7f04000f

.field public static final ic_camera:I = 0x7f040010

.field public static final ic_check:I = 0x7f040011

.field public static final ic_chev:I = 0x7f040012

.field public static final ic_close:I = 0x7f040013

.field public static final ic_csv:I = 0x7f040014

.field public static final ic_data:I = 0x7f040015

.field public static final ic_gmail:I = 0x7f040016

.field public static final ic_launcher_fg:I = 0x7f040017

.field public static final ic_loc:I = 0x7f040018

.field public static final ic_notif:I = 0x7f040019

.field public static final ic_salary:I = 0x7f04001a

.field public static final ic_search:I = 0x7f04001b

.field public static final ic_settings:I = 0x7f04001c

.field public static final ic_shield:I = 0x7f04001d

.field public static final ic_shops:I = 0x7f04001e

.field public static final ic_trash:I = 0x7f04001f

.field public static final ic_update:I = 0x7f040020

.field public static final ic_user:I = 0x7f040021


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 297
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
