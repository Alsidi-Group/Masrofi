.class Lcom/marwanalsidi/masrofi/SettingsActivity$10;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->pickCurrency()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$all:Ljava/util/List;

.field final synthetic val$listBox:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;Landroid/widget/LinearLayout;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 309
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->val$listBox:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->val$all:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 2

    .line 313
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->val$listBox:Landroid/widget/LinearLayout;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$10;->val$all:Ljava/util/List;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, v1, p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->access$200(Lcom/marwanalsidi/masrofi/SettingsActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method
