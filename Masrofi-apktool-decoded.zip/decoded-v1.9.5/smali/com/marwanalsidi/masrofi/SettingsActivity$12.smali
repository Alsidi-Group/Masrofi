.class Lcom/marwanalsidi/masrofi/SettingsActivity$12;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->notifSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 361
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    .line 363
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p1, p2}, Lcom/marwanalsidi/masrofi/Prefs;->setNotifications(Landroid/content/Context;Z)V

    if-eqz p2, :cond_0

    .line 365
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Perm;->requestNotifications(Landroid/app/Activity;)V

    .line 366
    :try_start_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    const-class v2, Lcom/marwanalsidi/masrofi/NotificationService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 368
    :catch_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/MidnightReceiver;->schedule(Landroid/content/Context;)V

    goto :goto_0

    .line 370
    :cond_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->cancel(Landroid/content/Context;)V

    .line 372
    :goto_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$12;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    if-eqz p2, :cond_1

    const p1, 0x7f080084

    goto :goto_1

    :cond_1
    const p1, 0x7f080083

    :goto_1
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 373
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method
