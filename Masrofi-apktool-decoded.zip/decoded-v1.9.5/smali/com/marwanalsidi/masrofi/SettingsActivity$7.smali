.class Lcom/marwanalsidi/masrofi/SettingsActivity$7;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->langSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$lang:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;[Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 214
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->val$lang:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 216
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->val$lang:[Ljava/lang/String;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {v2}, Lcom/marwanalsidi/masrofi/Lang;->cur(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 217
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->val$lang:[Ljava/lang/String;

    aget-object v1, v2, v1

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Lang;->set(Landroid/content/Context;Ljava/lang/String;)V

    .line 218
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$7;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->recreate()V

    :cond_0
    return-void
.end method
