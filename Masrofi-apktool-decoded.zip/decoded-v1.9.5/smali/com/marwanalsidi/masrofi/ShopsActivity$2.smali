.class Lcom/marwanalsidi/masrofi/ShopsActivity$2;
.super Ljava/lang/Object;
.source "ShopsActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ShopsActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ShopsActivity;)V
    .locals 0

    .line 40
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 1

    .line 44
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->access$002(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->access$100(Lcom/marwanalsidi/masrofi/ShopsActivity;)V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method
