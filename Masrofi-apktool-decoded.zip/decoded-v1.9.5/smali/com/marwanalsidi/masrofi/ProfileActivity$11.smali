.class Lcom/marwanalsidi/masrofi/ProfileActivity$11;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->pickAvatar()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V
    .locals 0

    .line 307
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 309
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/Prefs;->avatar(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 310
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Prefs;->setAvatar(Landroid/content/Context;Ljava/lang/String;)V

    .line 311
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$700(Lcom/marwanalsidi/masrofi/ProfileActivity;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 312
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$700(Lcom/marwanalsidi/masrofi/ProfileActivity;)Landroid/widget/ImageView;

    move-result-object v0

    const v1, 0x7f040021

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 313
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$11;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$700(Lcom/marwanalsidi/masrofi/ProfileActivity;)Landroid/widget/ImageView;

    move-result-object p0

    const v0, 0x7f040007

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    return-void
.end method
