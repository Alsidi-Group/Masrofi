.class Lcom/marwanalsidi/masrofi/ProfileActivity$1;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V
    .locals 0

    .line 59
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$1;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 60
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$1;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->finish()V

    return-void
.end method
