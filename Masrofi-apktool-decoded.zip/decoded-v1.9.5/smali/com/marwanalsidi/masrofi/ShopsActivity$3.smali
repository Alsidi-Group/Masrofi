.class Lcom/marwanalsidi/masrofi/ShopsActivity$3;
.super Ljava/lang/Object;
.source "ShopsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ShopsActivity;->build()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

.field final synthetic val$edName:Landroid/widget/EditText;

.field final synthetic val$edSection:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Landroid/widget/EditText;Landroid/widget/EditText;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 86
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edName:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edSection:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 88
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edName:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 89
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 90
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    const p1, 0x7f0800e1

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 93
    :cond_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edSection:Landroid/widget/EditText;

    .line 94
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 93
    invoke-virtual {v0, p1, v1}, Lcom/marwanalsidi/masrofi/DBHelper;->addStore(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 95
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    const v1, 0x7f0800e3

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    .line 96
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edName:Landroid/widget/EditText;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 97
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->val$edSection:Landroid/widget/EditText;

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 98
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->access$100(Lcom/marwanalsidi/masrofi/ShopsActivity;)V

    goto :goto_0

    .line 100
    :cond_1
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    const p1, 0x7f080054

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method
