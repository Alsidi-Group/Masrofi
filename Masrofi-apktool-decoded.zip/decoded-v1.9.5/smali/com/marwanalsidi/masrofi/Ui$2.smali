.class Lcom/marwanalsidi/masrofi/Ui$2;
.super Ljava/lang/Object;
.source "Ui.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/Ui;->sectionHeader(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;Z)[Landroid/widget/LinearLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field isOpen:Z

.field final synthetic val$arrow:Landroid/widget/ImageView;

.field final synthetic val$contentBox:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;Landroid/widget/ImageView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 327
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/Ui$2;->val$contentBox:Landroid/view/View;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/Ui$2;->val$arrow:Landroid/widget/ImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 328
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, Lcom/marwanalsidi/masrofi/Ui$2;->isOpen:Z

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 331
    iget-boolean p1, p0, Lcom/marwanalsidi/masrofi/Ui$2;->isOpen:Z

    xor-int/lit8 p1, p1, 0x1

    iput-boolean p1, p0, Lcom/marwanalsidi/masrofi/Ui$2;->isOpen:Z

    .line 332
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/Ui$2;->val$contentBox:Landroid/view/View;

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 333
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/Ui$2;->val$arrow:Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/widget/ImageView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    iget-boolean p0, p0, Lcom/marwanalsidi/masrofi/Ui$2;->isOpen:Z

    if-eqz p0, :cond_1

    const/high16 p0, 0x42b40000    # 90.0f

    goto :goto_1

    :cond_1
    const/high16 p0, 0x43870000    # 270.0f

    :goto_1
    invoke-virtual {p1, p0}, Landroid/view/ViewPropertyAnimator;->rotation(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0xb4

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method
