.class Lcom/marwanalsidi/masrofi/ProfileActivity$9;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCurrencyList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$r:[Ljava/lang/String;

.field final synthetic val$tvCur:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;[Ljava/lang/String;Landroid/widget/TextView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 277
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$r:[Ljava/lang/String;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$tvCur:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 279
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$r:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Prefs;->setCurrencyCode(Landroid/content/Context;Ljava/lang/String;)V

    .line 280
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$tvCur:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$r:[Ljava/lang/String;

    const/4 v3, 0x1

    aget-object v2, v2, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$r:[Ljava/lang/String;

    const/4 v4, 0x2

    aget-object v2, v2, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 281
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$9;->val$r:[Ljava/lang/String;

    aget-object v1, p0, v3

    aget-object p0, p0, v4

    filled-new-array {v1, p0}, [Ljava/lang/Object;

    move-result-object p0

    const v1, 0x7f080046

    .line 282
    invoke-virtual {v0, v1, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    .line 281
    invoke-static {v0, p0}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
