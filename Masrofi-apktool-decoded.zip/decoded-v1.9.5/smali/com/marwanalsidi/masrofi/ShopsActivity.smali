.class public Lcom/marwanalsidi/masrofi/ShopsActivity;
.super Landroid/app/Activity;
.source "ShopsActivity.java"


# instance fields
.field private boxList:Landroid/widget/LinearLayout;

.field private query:Ljava/lang/String;

.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const-string v0, ""

    .line 23
    iput-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->query:Ljava/lang/String;

    const/4 v0, -0x1

    .line 169
    iput v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->tGen:I

    return-void
.end method

.method static synthetic access$002(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 20
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->query:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/ShopsActivity;)V
    .locals 0

    .line 20
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->build()V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V
    .locals 0

    .line 20
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->confirmRemove(Ljava/lang/String;)V

    return-void
.end method

.method private build()V
    .locals 11

    .line 73
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 76
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    const v1, 0x7f0800dc

    .line 77
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/high16 v2, 0x41700000    # 15.0f

    const/4 v3, 0x1

    invoke-static {p0, v1, v2, v3}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v1, 0x8

    .line 78
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v2, 0x7f08007a

    .line 79
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v4, 0x20001

    invoke-static {p0, v2, v4}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v2

    .line 80
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 81
    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->spacer(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v1, 0x7f08007b

    .line 82
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1, v4}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v1

    .line 83
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v4, 0xa

    .line 84
    invoke-direct {p0, v4}, Lcom/marwanalsidi/masrofi/ShopsActivity;->spacer(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v4, 0x7f0800db

    .line 85
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->btnAccent(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    .line 86
    new-instance v5, Lcom/marwanalsidi/masrofi/ShopsActivity$3;

    invoke-direct {v5, p0, v2, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity$3;-><init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 104
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 105
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 108
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    invoke-virtual {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->storeCount()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const v2, 0x7f0800dd

    invoke-virtual {p0, v2, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->head(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 109
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Ui;->card(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 110
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->query:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 111
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v2

    invoke-virtual {v2}, Lcom/marwanalsidi/masrofi/DBHelper;->allStores()Ljava/util/List;

    move-result-object v2

    .line 114
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v6, v4

    move-object v7, v5

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [Ljava/lang/String;

    .line 115
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_0

    aget-object v9, v8, v3

    invoke-virtual {v9, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_0

    aget-object v9, v8, v4

    invoke-virtual {v9, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_0

    goto :goto_0

    :cond_0
    add-int/lit8 v6, v6, 0x1

    .line 117
    aget-object v9, v8, v4

    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1

    .line 118
    aget-object v7, v8, v4

    const/4 v9, 0x4

    .line 119
    invoke-direct {p0, v9}, Lcom/marwanalsidi/masrofi/ShopsActivity;->spacer(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v0, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 120
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 121
    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v10, 0x10

    .line 122
    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v10, 0x41600000    # 14.0f

    .line 123
    invoke-static {p0, v7, v10, v3}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v10

    .line 124
    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 125
    invoke-virtual {v0, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v9, 0x2

    .line 126
    invoke-direct {p0, v9}, Lcom/marwanalsidi/masrofi/ShopsActivity;->spacer(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v0, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 128
    :cond_1
    aget-object v8, v8, v3

    invoke-direct {p0, v8}, Lcom/marwanalsidi/masrofi/ShopsActivity;->trashIcon(Ljava/lang/String;)Landroid/widget/ImageView;

    move-result-object v9

    invoke-static {p0, v8, v5, v9, v5}, Lcom/marwanalsidi/masrofi/Ui;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/widget/ImageView;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v8

    .line 129
    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_0

    .line 131
    :cond_2
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-nez v6, :cond_3

    .line 133
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    const v1, 0x7f0800de

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->sub(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_3
    return-void
.end method

.method private confirmRemove(Ljava/lang/String;)V
    .locals 8

    const v0, 0x7f080050

    .line 149
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f08004f

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v1

    .line 150
    invoke-virtual {p0, v0, v1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const v0, 0x7f08002c

    .line 151
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/ShopsActivity$5;

    invoke-direct {v5, p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity$5;-><init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V

    const p1, 0x7f08002a

    .line 159
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 149
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private head(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 4

    .line 59
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 60
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41500000    # 13.0f

    .line 61
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 p1, 0x7f010000

    .line 62
    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const-string p1, "sans-serif-medium"

    const/4 v1, 0x0

    .line 63
    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 65
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {p1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x40c00000    # 6.0f

    .line 67
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x41900000    # 18.0f

    invoke-static {p0, v3}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {p1, v2, p0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 68
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private spacer(I)Landroid/view/View;
    .locals 2

    .line 53
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 54
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p1, p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    const/4 p1, 0x1

    invoke-direct {v1, p1, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private trashIcon(Ljava/lang/String;)Landroid/widget/ImageView;
    .locals 5

    .line 138
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v1, 0x7f04001f

    .line 139
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    const v1, 0x7f010005

    .line 140
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setColorFilter(I)V

    const/high16 v1, 0x41000000    # 8.0f

    .line 141
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    const/high16 v4, 0x40000000    # 2.0f

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 142
    new-instance v1, Lcom/marwanalsidi/masrofi/ShopsActivity$4;

    invoke-direct {v1, p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity$4;-><init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 26
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 30
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->setTheme(I)V

    .line 31
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 32
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->tGen:I

    const p1, 0x7f060007

    .line 33
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 35
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/ShopsActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/ShopsActivity$1;-><init>(Lcom/marwanalsidi/masrofi/ShopsActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05001e

    .line 39
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    .line 40
    new-instance v0, Lcom/marwanalsidi/masrofi/ShopsActivity$2;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/ShopsActivity$2;-><init>(Lcom/marwanalsidi/masrofi/ShopsActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const p1, 0x7f050001

    .line 48
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ShopsActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->boxList:Landroid/widget/LinearLayout;

    .line 49
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->build()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 164
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 165
    iget v0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->recreate()V

    return-void

    .line 166
    :cond_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->build()V

    return-void
.end method
