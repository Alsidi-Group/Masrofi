.class Lcom/marwanalsidi/masrofi/ProfileActivity$7;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->fillCountryList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$edEmail:Landroid/widget/EditText;

.field final synthetic val$r:[Ljava/lang/String;

.field final synthetic val$tvCountry:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;[Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 217
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$r:[Ljava/lang/String;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$tvCountry:Landroid/widget/TextView;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$edEmail:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 218
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$r:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$tvCountry:Landroid/widget/TextView;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$7;->val$edEmail:Landroid/widget/EditText;

    invoke-static {v0, v1, v2, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$500(Lcom/marwanalsidi/masrofi/ProfileActivity;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method
