.class Lcom/marwanalsidi/masrofi/DataActivity$1;
.super Ljava/lang/Object;
.source "DataActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/DataActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/DataActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/DataActivity;)V
    .locals 0

    .line 46
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/DataActivity$1;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 47
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/DataActivity$1;->this$0:Lcom/marwanalsidi/masrofi/DataActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/DataActivity;->finish()V

    return-void
.end method
