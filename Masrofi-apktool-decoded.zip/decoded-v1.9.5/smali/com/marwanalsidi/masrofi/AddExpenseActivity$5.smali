.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 77
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 79
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Perm;->cameraGranted(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$200(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    goto :goto_0

    .line 80
    :cond_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const-string p1, "android.permission.CAMERA"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x29

    invoke-virtual {p0, p1, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->requestPermissions([Ljava/lang/String;I)V

    :goto_0
    return-void
.end method
