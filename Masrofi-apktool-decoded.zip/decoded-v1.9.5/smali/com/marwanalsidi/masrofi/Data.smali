.class public final Lcom/marwanalsidi/masrofi/Data;
.super Ljava/lang/Object;
.source "Data.java"


# static fields
.field public static final CUSTOM_SECTION:Ljava/lang/String; = "\u0645\u062a\u0627\u062c\u0631 \u0645\u0636\u0627\u0641\u0629"

.field public static final PAY_GROUPS:[Ljava/lang/String;

.field public static final PAY_ITEMS:[[Ljava/lang/String;

.field public static final SECTIONS:[Ljava/lang/String;

.field public static final SHOPS:[[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 37

    const-string v0, "\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0632\u0627\u0648\u064a\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064a\u0629"

    const-string v1, "\u0645\u0648\u0627\u062f \u063a\u0630\u0627\u0626\u064a\u0629"

    .line 8
    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v2

    const-string v0, "\u0633\u0648\u0642 \u0627\u0644\u062c\u0645\u064a\u0644 \u0644\u0644\u062e\u0636\u0627\u0631"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v3

    const-string v0, "\u0628\u0642\u0627\u0644\u0629 \u0627\u0644\u0646\u062f\u0649"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v4

    const-string v0, "\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0641\u062a\u062d"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v5

    const-string v0, "\u0645\u0639\u0631\u0636 \u0627\u0644\u0623\u0635\u064a\u0644 \u0644\u0644\u062d\u0644\u0648\u064a\u0627\u062a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v6

    const-string v0, "\u0645\u062e\u0628\u0632 \u0648\u062a\u0639\u0627\u062c\u064a \u0637\u0631\u0627\u0628\u0644\u0633"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v7

    const-string v0, "\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0639\u0632\u064a\u0632\u064a\u0629 \u0627\u0644\u062a\u062c\u0627\u0631\u064a\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v8

    const-string v0, "\u0645\u0637\u0639\u0645 \u0623\u0628\u0648 \u0633\u062a\u064a\u062a\u0647"

    const-string v1, "\u0645\u0637\u0627\u0639\u0645 \u0648\u0645\u0642\u0627\u0647\u064a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v9

    const-string v0, "\u0645\u0637\u0639\u0645 \u0627\u0644\u0633\u062f \u0644\u0644\u0643\u0628\u0633\u0648\u0644\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v10

    const-string v0, "\u0645\u0642\u0627\u0647\u064a \u0627\u0644\u062f\u064a\u0627\u0631"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v11

    const-string v0, "\u0628\u064a\u062a\u0632\u0627 \u0637\u0631\u0627\u0628\u0644\u0633"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v12

    const-string v0, "\u0645\u0637\u0639\u0645 \u0628\u064a\u062a \u0627\u0644\u0634\u0627\u0648\u0631\u0645\u0627"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v13

    const-string v0, "\u0643\u0627\u0641\u062a\u064a\u0631\u064a\u0627 \u0627\u0644\u0648\u0627\u062d\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v14

    const-string v0, "\u0642\u0647\u0648\u0629 \u0633\u0648\u0642 \u0627\u0644\u062c\u0645\u0639\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v15

    const-string v0, "\u0645\u062d\u0637\u0629 \u0637\u0631\u064a\u0641 \u0627\u0644\u0634\u0645\u0627\u0644\u064a\u0629 \u0644\u0644\u0648\u0642\u0648\u062f"

    const-string v1, "\u0648\u0642\u0648\u062f \u0648\u0645\u0648\u0627\u0635\u0644\u0627\u062a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v16

    const-string v0, "\u0645\u062d\u0637\u0629 \u0632\u0644\u064a\u062a\u0646 \u0644\u0644\u0628\u062a\u0631\u0648\u0644"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v17

    const-string v0, "\u0645\u0643\u062a\u0628 \u0627\u0644\u0646\u0642\u0644 \u0627\u0644\u062c\u0645\u0627\u0639\u064a \u2014 \u0627\u0644\u0645\u0631\u062c"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v18

    const-string v0, "\u0623\u062c\u0631\u0629 \u062a\u0627\u0643\u0633\u064a \u0645\u062f\u064a\u0646\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v19

    const-string v0, "\u063a\u0633\u064a\u0644 \u0627\u0644\u0633\u064a\u0627\u0631\u0627\u062a \u0627\u0644\u0633\u0631\u064a\u0639"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v20

    const-string v0, "\u0635\u064a\u062f\u0644\u064a\u0629 \u0627\u0644\u0646\u0648\u0631"

    const-string v1, "\u0635\u064a\u062f\u0644\u064a\u0629 \u0648\u0635\u062d\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v21

    const-string v0, "\u0635\u064a\u062f\u0644\u064a\u0629 \u0627\u0644\u0634\u0641\u0627\u0621"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v22

    const-string v0, "\u0639\u064a\u0627\u062f\u0629 \u0627\u0644\u0631\u0627\u0632\u064a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v23

    const-string v0, "\u0645\u0631\u0643\u0632 \u0627\u0644\u0641\u062d\u0648\u0635\u0627\u062a \u0627\u0644\u0637\u0628\u064a\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v24

    const-string v0, "\u0645\u0639\u0631\u0636 \u0623\u0632\u064a\u0627\u0621 \u0627\u0644\u0632\u0647\u0631\u0627\u0621"

    const-string v1, "\u0623\u0632\u064a\u0627\u0621 \u0648\u0645\u062d\u0644\u0627\u062a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v25

    const-string v0, "\u0628\u0648\u062a\u064a\u0643 \u0627\u0644\u0631\u062d\u0645\u0629 \u0644\u0644\u0645\u0644\u0627\u0628\u0633"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v26

    const-string v0, "\u0645\u0639\u0631\u0636 \u0627\u0644\u0623\u062d\u0630\u064a\u0629 \u0627\u0644\u062d\u062f\u064a\u062b"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v27

    const-string v0, "\u0645\u062d\u0644\u0627\u062a \u0627\u0644\u0639\u0631\u0627\u064a\u0633 \u2014 \u0645\u064a\u062f\u0627\u0646 \u0627\u0644\u062c\u0632\u0627\u0626\u0631"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v28

    const-string v0, "\u0645\u0639\u0631\u0636 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0627\u062a \u0627\u0644\u062d\u062f\u064a\u062b\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v29

    const-string v0, "\u0641\u0627\u062a\u0648\u0631\u0629 \u0643\u0647\u0631\u0628\u0627\u0621 \u2014 \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u0639\u0627\u0645\u0629"

    const-string v1, "\u062e\u062f\u0645\u0627\u062a \u0648\u0641\u0648\u0627\u062a\u064a\u0631"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v30

    const-string v0, "\u0641\u0627\u062a\u0648\u0631\u0629 \u0645\u0627\u0621 \u0648\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0645\u062f\u064a\u0646\u0629"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v31

    const-string v0, "\u0625\u0646\u062a\u0631\u0646\u062a \u0627\u0644\u0644\u064a\u0628\u064a\u0629 \u0644\u0644\u0627\u062a\u0635\u0627\u0644\u0627\u062a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v32

    const-string v0, "\u0635\u064a\u0627\u0646\u0629 \u0627\u0644\u0633\u064a\u0627\u0631\u0627\u062a \u2014 \u0648\u0631\u0634\u0629 \u0627\u0644\u0623\u0645\u064a\u0646"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v33

    const-string v0, "\u0645\u0643\u062a\u0628 \u062a\u062c\u062f\u064a\u062f \u0647\u0627\u062a\u0641 \u0648\u0644\u0648\u062d\u0627\u062a"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v34

    const-string v0, "\u0645\u0643\u062a\u0628\u0629 \u0627\u0644\u0646\u0647\u0636\u0629 \u0644\u0644\u0643\u062a\u0628"

    const-string v1, "\u062a\u0639\u0644\u064a\u0645 \u0648\u0645\u0646\u0632\u0644"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v35

    const-string v0, "\u0623\u062f\u0648\u0627\u062a \u0645\u0646\u0632\u0644\u064a\u0629 \u2014 \u0633\u0648\u0642 \u0627\u0644\u062d\u0634\u0627\u0626\u0634"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v36

    filled-new-array/range {v2 .. v36}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Data;->SHOPS:[[Ljava/lang/String;

    const-string v1, "\u0645\u0648\u0627\u062f \u063a\u0630\u0627\u0626\u064a\u0629"

    const-string v2, "\u0645\u0637\u0627\u0639\u0645 \u0648\u0645\u0642\u0627\u0647\u064a"

    const-string v3, "\u0648\u0642\u0648\u062f \u0648\u0645\u0648\u0627\u0635\u0644\u0627\u062a"

    const-string v4, "\u0635\u064a\u062f\u0644\u064a\u0629 \u0648\u0635\u062d\u0629"

    const-string v5, "\u0623\u0632\u064a\u0627\u0621 \u0648\u0645\u062d\u0644\u0627\u062a"

    const-string v6, "\u062e\u062f\u0645\u0627\u062a \u0648\u0641\u0648\u0627\u062a\u064a\u0631"

    const-string v7, "\u062a\u0639\u0644\u064a\u0645 \u0648\u0645\u0646\u0632\u0644"

    .line 46
    filled-new-array/range {v1 .. v7}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Data;->SECTIONS:[Ljava/lang/String;

    const-string v0, "\u0627\u0644\u062f\u0641\u0639 \u0639\u0628\u0631 \u062e\u062f\u0645\u0627\u062a \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a"

    const-string v1, "\u0627\u0644\u062f\u0641\u0639 \u0639\u0628\u0631 \u0627\u0644\u0645\u062d\u0627\u0641\u0638 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629"

    const-string v2, "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u064a (\u0643\u0627\u0634)"

    const-string v3, "\u0627\u0644\u062f\u0641\u0639 \u0639\u0628\u0631 \u0628\u0637\u0627\u0642\u0629 \u0645\u0635\u0631\u0641\u064a\u0629"

    const-string v4, "\u0627\u0644\u062f\u0641\u0639 \u0639\u0628\u0631 \u0627\u0644\u062a\u062d\u0648\u064a\u0644 \u0627\u0644\u0645\u0635\u0631\u0641\u064a"

    .line 55
    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Data;->PAY_GROUPS:[Ljava/lang/String;

    const-string v0, "\u0643\u0627\u0634"

    .line 64
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u0628\u0637\u0627\u0642\u0629 \u0645\u0635\u0631\u0641\u064a\u0629"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u0648\u0627\u0646 \u0628\u0627\u064a (OnePay)"

    const-string v3, "\u0644\u0627\u064a \u0628\u0627\u064a (LyPay)"

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u0625\u062f\u0641\u0639 \u0644\u064a"

    const-string v4, "\u0645\u0648\u0628\u064a \u0643\u0627\u0634"

    const-string v5, "\u0623\u0645\u0627\u0646 \u0645\u0648\u0628\u0627\u064a\u0644"

    const-string v6, "\u0627\u0644\u0645\u062a\u062d\u062f \u0645\u0648\u0628\u0627\u064a\u0644"

    const-string v7, "\u0627\u0644\u064a\u0642\u064a\u0646 \u0645\u0648\u0628\u0627\u064a\u0644"

    const-string v8, "\u0627\u0644\u0623\u0646\u062f\u0644\u0633 \u0645\u0648\u0628\u0627\u064a\u0644"

    const-string v9, "\u0627\u0644\u0633\u0631\u0627\u064a \u0645\u0648\u0628\u0627\u064a\u0644"

    const-string v10, "\u064a\u0633\u0631 \u0628\u0627\u064a"

    const-string v11, "\u0645\u0635\u0631\u0641\u064a \u0628\u0627\u064a"

    const-string v12, "\u0635\u062d\u0627\u0631\u0649 \u0628\u0627\u064a"

    const-string v13, "\u0646\u0627\u0628 \u0628\u0632\u0646\u0633"

    const-string v14, "\u0646\u0627\u0628 \u0645\u0648\u0628\u0627\u064a\u0644"

    filled-new-array/range {v3 .. v14}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "\u0631\u0646 \u0628\u0627\u064a"

    const-string v5, "\u062e\u062f\u0645\u0629 \u0641\u0648\u0631\u064a"

    const-string v6, "\u062c\u064a \u0628\u0627\u064a"

    const-string v7, "\u062f\u064a\u062c\u064a\u062a\u0627\u0644 \u0644\u064a\u0628"

    const-string v8, "\u0633\u062f\u0627\u062f"

    const-string v9, "\u062a\u062f\u0627\u0648\u0644"

    const-string v10, "\u0648\u062a\u064a \u0644\u0646\u0643"

    filled-new-array/range {v4 .. v10}, [Ljava/lang/String;

    move-result-object v4

    filled-new-array {v0, v1, v2, v3, v4}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Data;->PAY_ITEMS:[[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
