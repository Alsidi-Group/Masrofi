.class public final Lcom/marwanalsidi/masrofi/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final bl_accent:I = 0x7f020000

.field public static final bl_accent2:I = 0x7f020001

.field public static final bl_bg:I = 0x7f020002

.field public static final bl_bgD:I = 0x7f020003

.field public static final bl_btn:I = 0x7f020004

.field public static final bl_btnD:I = 0x7f020005

.field public static final bl_card:I = 0x7f020006

.field public static final bl_cardD:I = 0x7f020007

.field public static final bl_danger:I = 0x7f020008

.field public static final bl_line:I = 0x7f020009

.field public static final bl_lineD:I = 0x7f02000a

.field public static final bl_ok:I = 0x7f02000b

.field public static final bl_text:I = 0x7f02000c

.field public static final bl_textD:I = 0x7f02000d

.field public static final bl_textSub:I = 0x7f02000e

.field public static final bl_textSubD:I = 0x7f02000f

.field public static final co_accent:I = 0x7f020010

.field public static final co_accent2:I = 0x7f020011

.field public static final co_bg:I = 0x7f020012

.field public static final co_bgD:I = 0x7f020013

.field public static final co_btn:I = 0x7f020014

.field public static final co_btnD:I = 0x7f020015

.field public static final co_card:I = 0x7f020016

.field public static final co_cardD:I = 0x7f020017

.field public static final co_danger:I = 0x7f020018

.field public static final co_line:I = 0x7f020019

.field public static final co_lineD:I = 0x7f02001a

.field public static final co_ok:I = 0x7f02001b

.field public static final co_text:I = 0x7f02001c

.field public static final co_textD:I = 0x7f02001d

.field public static final co_textSub:I = 0x7f02001e

.field public static final co_textSubD:I = 0x7f02001f

.field public static final cy_accent:I = 0x7f020020

.field public static final cy_accent2:I = 0x7f020021

.field public static final cy_bg:I = 0x7f020022

.field public static final cy_bgD:I = 0x7f020023

.field public static final cy_btn:I = 0x7f020024

.field public static final cy_btnD:I = 0x7f020025

.field public static final cy_card:I = 0x7f020026

.field public static final cy_cardD:I = 0x7f020027

.field public static final cy_danger:I = 0x7f020028

.field public static final cy_line:I = 0x7f020029

.field public static final cy_lineD:I = 0x7f02002a

.field public static final cy_ok:I = 0x7f02002b

.field public static final cy_text:I = 0x7f02002c

.field public static final cy_textD:I = 0x7f02002d

.field public static final cy_textSub:I = 0x7f02002e

.field public static final cy_textSubD:I = 0x7f02002f

.field public static final danger:I = 0x7f020030

.field public static final dk_accent:I = 0x7f020031

.field public static final dk_accent2:I = 0x7f020032

.field public static final dk_bg:I = 0x7f020033

.field public static final dk_btn:I = 0x7f020034

.field public static final dk_card:I = 0x7f020035

.field public static final dk_danger:I = 0x7f020036

.field public static final dk_line:I = 0x7f020037

.field public static final dk_ok:I = 0x7f020038

.field public static final dk_text:I = 0x7f020039

.field public static final dk_textSub:I = 0x7f02003a

.field public static final em_accent:I = 0x7f02003b

.field public static final em_accent2:I = 0x7f02003c

.field public static final em_bg:I = 0x7f02003d

.field public static final em_bgD:I = 0x7f02003e

.field public static final em_btn:I = 0x7f02003f

.field public static final em_btnD:I = 0x7f020040

.field public static final em_card:I = 0x7f020041

.field public static final em_cardD:I = 0x7f020042

.field public static final em_danger:I = 0x7f020043

.field public static final em_line:I = 0x7f020044

.field public static final em_lineD:I = 0x7f020045

.field public static final em_ok:I = 0x7f020046

.field public static final em_text:I = 0x7f020047

.field public static final em_textD:I = 0x7f020048

.field public static final em_textSub:I = 0x7f020049

.field public static final em_textSubD:I = 0x7f02004a

.field public static final gd_accent:I = 0x7f02004b

.field public static final gd_accent2:I = 0x7f02004c

.field public static final gd_bg:I = 0x7f02004d

.field public static final gd_bgD:I = 0x7f02004e

.field public static final gd_btn:I = 0x7f02004f

.field public static final gd_btnD:I = 0x7f020050

.field public static final gd_card:I = 0x7f020051

.field public static final gd_cardD:I = 0x7f020052

.field public static final gd_danger:I = 0x7f020053

.field public static final gd_line:I = 0x7f020054

.field public static final gd_lineD:I = 0x7f020055

.field public static final gd_ok:I = 0x7f020056

.field public static final gd_text:I = 0x7f020057

.field public static final gd_textD:I = 0x7f020058

.field public static final gd_textSub:I = 0x7f020059

.field public static final gd_textSubD:I = 0x7f02005a

.field public static final ic_launcher_bg:I = 0x7f02005b

.field public static final ok:I = 0x7f02005c

.field public static final or_accent:I = 0x7f02005d

.field public static final or_accent2:I = 0x7f02005e

.field public static final or_bg:I = 0x7f02005f

.field public static final or_bgD:I = 0x7f020060

.field public static final or_btn:I = 0x7f020061

.field public static final or_btnD:I = 0x7f020062

.field public static final or_card:I = 0x7f020063

.field public static final or_cardD:I = 0x7f020064

.field public static final or_danger:I = 0x7f020065

.field public static final or_line:I = 0x7f020066

.field public static final or_lineD:I = 0x7f020067

.field public static final or_ok:I = 0x7f020068

.field public static final or_text:I = 0x7f020069

.field public static final or_textD:I = 0x7f02006a

.field public static final or_textSub:I = 0x7f02006b

.field public static final or_textSubD:I = 0x7f02006c

.field public static final pu_accent:I = 0x7f02006d

.field public static final pu_accent2:I = 0x7f02006e

.field public static final pu_bg:I = 0x7f02006f

.field public static final pu_bgD:I = 0x7f020070

.field public static final pu_btn:I = 0x7f020071

.field public static final pu_btnD:I = 0x7f020072

.field public static final pu_card:I = 0x7f020073

.field public static final pu_cardD:I = 0x7f020074

.field public static final pu_danger:I = 0x7f020075

.field public static final pu_line:I = 0x7f020076

.field public static final pu_lineD:I = 0x7f020077

.field public static final pu_ok:I = 0x7f020078

.field public static final pu_text:I = 0x7f020079

.field public static final pu_textD:I = 0x7f02007a

.field public static final pu_textSub:I = 0x7f02007b

.field public static final pu_textSubD:I = 0x7f02007c

.field public static final ro_accent:I = 0x7f02007d

.field public static final ro_accent2:I = 0x7f02007e

.field public static final ro_bg:I = 0x7f02007f

.field public static final ro_bgD:I = 0x7f020080

.field public static final ro_btn:I = 0x7f020081

.field public static final ro_btnD:I = 0x7f020082

.field public static final ro_card:I = 0x7f020083

.field public static final ro_cardD:I = 0x7f020084

.field public static final ro_danger:I = 0x7f020085

.field public static final ro_line:I = 0x7f020086

.field public static final ro_lineD:I = 0x7f020087

.field public static final ro_ok:I = 0x7f020088

.field public static final ro_text:I = 0x7f020089

.field public static final ro_textD:I = 0x7f02008a

.field public static final ro_textSub:I = 0x7f02008b

.field public static final ro_textSubD:I = 0x7f02008c

.field public static final sl_accent:I = 0x7f02008d

.field public static final sl_accent2:I = 0x7f02008e

.field public static final sl_bg:I = 0x7f02008f

.field public static final sl_bgD:I = 0x7f020090

.field public static final sl_btn:I = 0x7f020091

.field public static final sl_btnD:I = 0x7f020092

.field public static final sl_card:I = 0x7f020093

.field public static final sl_cardD:I = 0x7f020094

.field public static final sl_danger:I = 0x7f020095

.field public static final sl_line:I = 0x7f020096

.field public static final sl_lineD:I = 0x7f020097

.field public static final sl_ok:I = 0x7f020098

.field public static final sl_text:I = 0x7f020099

.field public static final sl_textD:I = 0x7f02009a

.field public static final sl_textSub:I = 0x7f02009b

.field public static final sl_textSubD:I = 0x7f02009c


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 74
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
