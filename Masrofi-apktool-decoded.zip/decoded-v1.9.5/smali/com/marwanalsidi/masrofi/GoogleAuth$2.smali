.class Lcom/marwanalsidi/masrofi/GoogleAuth$2;
.super Ljava/lang/Object;
.source "GoogleAuth.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/GoogleAuth;->finish(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$cb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

.field final synthetic val$email:Ljava/lang/String;

.field final synthetic val$error:Ljava/lang/String;

.field final synthetic val$name:Ljava/lang/String;

.field final synthetic val$verified:Z


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 194
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$cb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$email:Ljava/lang/String;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$name:Ljava/lang/String;

    iput-boolean p4, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$verified:Z

    iput-object p5, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$error:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 196
    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$cb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$email:Ljava/lang/String;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$name:Ljava/lang/String;

    iget-boolean v3, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$verified:Z

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$2;->val$error:Ljava/lang/String;

    invoke-interface {v0, v1, v2, v3, p0}, Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;->onDone(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
