.class public interface abstract Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;
.super Ljava/lang/Object;
.source "UpdateChecker.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/UpdateChecker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V
.end method
