.class Lcom/marwanalsidi/masrofi/SettingsActivity$1;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 42
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 43
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->finish()V

    return-void
.end method
