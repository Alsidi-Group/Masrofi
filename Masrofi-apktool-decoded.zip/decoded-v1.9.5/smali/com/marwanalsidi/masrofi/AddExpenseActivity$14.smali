.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->save()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$amt:D


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;D)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 340
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-wide p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;->val$amt:D

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 341
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-wide v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;->val$amt:D

    invoke-static {p1, v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$1000(Lcom/marwanalsidi/masrofi/AddExpenseActivity;D)V

    return-void
.end method
