.class Lcom/marwanalsidi/masrofi/UpdateChecker$4;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/UpdateChecker;->autoCheckSilent(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$act:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 213
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$4;->val$act:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V
    .locals 0

    if-eqz p1, :cond_0

    .line 215
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$4;->val$act:Landroid/app/Activity;

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/UpdateChecker;->access$100(Landroid/app/Activity;Lcom/marwanalsidi/masrofi/UpdateChecker$Info;)V

    :cond_0
    return-void
.end method
