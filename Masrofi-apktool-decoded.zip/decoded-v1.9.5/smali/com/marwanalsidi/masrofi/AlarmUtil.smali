.class public Lcom/marwanalsidi/masrofi/AlarmUtil;
.super Ljava/lang/Object;
.source "AlarmUtil.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static scheduleMidnight(Landroid/content/Context;)V
    .locals 8

    const-string v0, "alarm"

    .line 15
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/app/AlarmManager;

    if-nez v1, :cond_0

    return-void

    .line 17
    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-class v2, Lcom/marwanalsidi/masrofi/MidnightReceiver;

    invoke-direct {v0, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x3e9

    const/high16 v3, 0xc000000

    .line 18
    invoke-static {p0, v2, v0, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v7

    .line 20
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p0

    const/16 v0, 0xb

    const/4 v2, 0x0

    .line 21
    invoke-virtual {p0, v0, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v0, 0xc

    .line 22
    invoke-virtual {p0, v0, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v0, 0xd

    const/4 v3, 0x5

    .line 23
    invoke-virtual {p0, v0, v3}, Ljava/util/Calendar;->set(II)V

    .line 24
    invoke-virtual {p0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    cmp-long v0, v3, v5

    const/4 v3, 0x1

    if-gtz v0, :cond_1

    const/4 v0, 0x6

    .line 25
    invoke-virtual {p0, v0, v3}, Ljava/util/Calendar;->add(II)V

    .line 28
    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1f

    if-lt v0, v4, :cond_2

    .line 29
    invoke-virtual {v1}, Landroid/app/AlarmManager;->canScheduleExactAlarms()Z

    move-result v3

    :cond_2
    if-eqz v3, :cond_3

    .line 32
    invoke-virtual {p0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4, v7}, Landroid/app/AlarmManager;->setExactAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    .line 34
    invoke-virtual {p0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v3

    const-wide/32 v5, 0xea60

    invoke-virtual/range {v1 .. v7}, Landroid/app/AlarmManager;->setWindow(IJJLandroid/app/PendingIntent;)V

    :goto_0
    return-void
.end method
