.class Lcom/marwanalsidi/masrofi/ProfileActivity$8;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->pickCurrency(Landroid/widget/TextView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$all:Ljava/util/List;

.field final synthetic val$listBox:Landroid/widget/LinearLayout;

.field final synthetic val$tvCur:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Landroid/widget/TextView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 255
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$listBox:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$all:Ljava/util/List;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$tvCur:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 3

    .line 259
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$listBox:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$all:Ljava/util/List;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$8;->val$tvCur:Landroid/widget/TextView;

    invoke-static {v0, v1, v2, p1, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$600(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;)V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method
