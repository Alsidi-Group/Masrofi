.class Lcom/marwanalsidi/masrofi/CalculatorActivity$1;
.super Ljava/lang/Object;
.source "CalculatorActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/CalculatorActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/CalculatorActivity;)V
    .locals 0

    .line 60
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$1;->this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 61
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity$1;->this$0:Lcom/marwanalsidi/masrofi/CalculatorActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->finish()V

    return-void
.end method
