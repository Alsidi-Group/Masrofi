.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickShop()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$holder:[Landroid/app/AlertDialog;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Landroid/app/AlertDialog;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 133
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;->val$holder:[Landroid/app/AlertDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 134
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;->val$holder:[Landroid/app/AlertDialog;

    const/4 v0, 0x0

    aget-object p0, p0, v0

    invoke-static {p1, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$500(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Landroid/app/AlertDialog;)V

    return-void
.end method
