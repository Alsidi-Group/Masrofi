.class Lcom/marwanalsidi/masrofi/AboutActivity$2;
.super Ljava/lang/Object;
.source "AboutActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AboutActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AboutActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AboutActivity;)V
    .locals 0

    .line 32
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 34
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    const v0, 0x7f050032

    invoke-virtual {p1, v0}, Lcom/marwanalsidi/masrofi/AboutActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const/4 v0, 0x0

    .line 35
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 36
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    const v1, 0x7f080001

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/AboutActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    new-instance v1, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;

    invoke-direct {v1, p0, p1}, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;-><init>(Lcom/marwanalsidi/masrofi/AboutActivity$2;Landroid/widget/TextView;)V

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/UpdateChecker;->check(Landroid/content/Context;Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;)V

    return-void
.end method
