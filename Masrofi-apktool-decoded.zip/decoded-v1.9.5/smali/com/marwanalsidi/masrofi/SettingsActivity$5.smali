.class Lcom/marwanalsidi/masrofi/SettingsActivity$5;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->uiSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$m:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 170
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$5;->val$m:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 172
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$5;->val$m:Ljava/lang/String;

    invoke-static {p1, v0}, Lcom/marwanalsidi/masrofi/Prefs;->setMode(Landroid/content/Context;Ljava/lang/String;)V

    .line 173
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->recreate()V

    return-void
.end method
