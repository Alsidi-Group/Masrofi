.class public Lcom/marwanalsidi/masrofi/BootReceiver;
.super Landroid/content/BroadcastReceiver;
.source "BootReceiver.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    const-string p0, "android.intent.action.BOOT_COMPLETED"

    .line 11
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    return-void

    .line 12
    :cond_0
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Prefs;->notifications(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 13
    :try_start_0
    new-instance p0, Landroid/content/Intent;

    const-class p2, Lcom/marwanalsidi/masrofi/NotificationService;

    invoke-direct {p0, p1, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    :catch_0
    :cond_1
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/MidnightReceiver;->schedule(Landroid/content/Context;)V

    return-void
.end method
