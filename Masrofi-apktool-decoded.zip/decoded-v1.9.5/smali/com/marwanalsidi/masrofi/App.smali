.class public Lcom/marwanalsidi/masrofi/App;
.super Landroid/app/Application;
.source "App.java"


# static fields
.field public static final CH_ALERT:Ljava/lang/String; = "masrofi_salary_alert"

.field public static final CH_ID:Ljava/lang/String; = "masrofi_service"

.field private static instance:Lcom/marwanalsidi/masrofi/App;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    invoke-static {}, Lcom/marwanalsidi/masrofi/CrashLog;->install()V

    return-void
.end method

.method public static get()Lcom/marwanalsidi/masrofi/App;
    .locals 1

    .line 14
    sget-object v0, Lcom/marwanalsidi/masrofi/App;->instance:Lcom/marwanalsidi/masrofi/App;

    return-object v0
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 18
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method public onCreate()V
    .locals 5

    .line 23
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 24
    sput-object p0, Lcom/marwanalsidi/masrofi/App;->instance:Lcom/marwanalsidi/masrofi/App;

    .line 26
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/App;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_0

    .line 28
    new-instance v1, Landroid/app/NotificationChannel;

    const v2, 0x7f08007d

    .line 29
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    const-string v4, "masrofi_service"

    invoke-direct {v1, v4, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const v2, 0x7f080080

    .line 30
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const/4 v2, 0x0

    .line 31
    invoke-virtual {v1, v2}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    .line 32
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 35
    new-instance v1, Landroid/app/NotificationChannel;

    const v2, 0x7f08007e

    .line 36
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x4

    const-string v4, "masrofi_salary_alert"

    invoke-direct {v1, v4, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const v2, 0x7f08007f

    .line 37
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const/4 p0, 0x1

    .line 38
    invoke-virtual {v1, p0}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 39
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    :cond_0
    return-void
.end method
