.class Lcom/marwanalsidi/masrofi/SalaryActivity$1;
.super Ljava/lang/Object;
.source "SalaryActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SalaryActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SalaryActivity;)V
    .locals 0

    .line 27
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 28
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$1;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SalaryActivity;->finish()V

    return-void
.end method
