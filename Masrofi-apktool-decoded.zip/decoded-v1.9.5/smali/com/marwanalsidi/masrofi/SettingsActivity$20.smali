.class Lcom/marwanalsidi/masrofi/SettingsActivity$20;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->dataSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 469
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$20;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 471
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$20;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/Prefs;->logout(Landroid/content/Context;)V

    .line 472
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$20;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$20;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    const-class v3, Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->startActivity(Landroid/content/Intent;)V

    .line 473
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$20;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->finish()V

    return-void
.end method
