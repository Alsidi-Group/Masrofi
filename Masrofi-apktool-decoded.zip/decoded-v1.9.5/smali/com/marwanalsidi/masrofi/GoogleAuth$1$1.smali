.class Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;
.super Ljava/lang/Object;
.source "GoogleAuth.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/GoogleAuth$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/GoogleAuth$1;

.field final synthetic val$consent:Landroid/content/Intent;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/GoogleAuth$1;Landroid/content/Intent;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 86
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->this$0:Lcom/marwanalsidi/masrofi/GoogleAuth$1;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->val$consent:Landroid/content/Intent;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 89
    :try_start_0
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->this$0:Lcom/marwanalsidi/masrofi/GoogleAuth$1;

    iget-object v2, v2, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$act:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->this$0:Lcom/marwanalsidi/masrofi/GoogleAuth$1;

    iget-object v2, v2, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$act:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    .line 93
    :cond_0
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->this$0:Lcom/marwanalsidi/masrofi/GoogleAuth$1;

    iget-object v2, v2, Lcom/marwanalsidi/masrofi/GoogleAuth$1;->val$act:Landroid/app/Activity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/GoogleAuth$1$1;->val$consent:Landroid/content/Intent;

    const/16 v3, 0x38

    invoke-virtual {v2, p0, v3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_1

    .line 90
    :cond_1
    :goto_0
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object p0

    const v2, 0x7f080020

    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, v1, v0, p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 95
    :catch_0
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object p0

    const v2, 0x7f080027

    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, v1, v0, p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    :goto_1
    return-void
.end method
