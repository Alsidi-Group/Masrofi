.class Lcom/marwanalsidi/masrofi/ShopsActivity$4;
.super Ljava/lang/Object;
.source "ShopsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ShopsActivity;->trashIcon(Ljava/lang/String;)Landroid/widget/ImageView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 142
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$4;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$4;->val$name:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 143
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$4;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$4;->val$name:Ljava/lang/String;

    invoke-static {p1, p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->access$200(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V

    return-void
.end method
