.class Lcom/marwanalsidi/masrofi/ProfileActivity$4;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$tvCur:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 122
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$4;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$4;->val$tvCur:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 123
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$4;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$4;->val$tvCur:Landroid/widget/TextView;

    invoke-static {p1, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$200(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;)V

    return-void
.end method
