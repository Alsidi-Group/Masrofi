.class Lcom/marwanalsidi/masrofi/LoginActivity$2;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/LoginActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/LoginActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/LoginActivity;)V
    .locals 0

    .line 45
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity$2;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 46
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/LoginActivity$2;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->access$100(Lcom/marwanalsidi/masrofi/LoginActivity;)V

    return-void
.end method
