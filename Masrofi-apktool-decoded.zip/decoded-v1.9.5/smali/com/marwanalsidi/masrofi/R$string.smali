.class public final Lcom/marwanalsidi/masrofi/R$string;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final about_check_updates:I = 0x7f080000

.field public static final about_connecting:I = 0x7f080001

.field public static final about_desc:I = 0x7f080002

.field public static final about_dev:I = 0x7f080003

.field public static final about_fail:I = 0x7f080004

.field public static final about_new:I = 0x7f080005

.field public static final about_premium:I = 0x7f080006

.field public static final about_title:I = 0x7f080007

.field public static final about_updates_hint:I = 0x7f080008

.field public static final about_uptodate:I = 0x7f080009

.field public static final about_ver:I = 0x7f08000a

.field public static final about_verified:I = 0x7f08000b

.field public static final add_amount:I = 0x7f08000c

.field public static final add_available:I = 0x7f08000d

.field public static final add_camera:I = 0x7f08000e

.field public static final add_camera_done:I = 0x7f08000f

.field public static final add_camera_fail:I = 0x7f080010

.field public static final add_loc:I = 0x7f080011

.field public static final add_loc_fail:I = 0x7f080012

.field public static final add_loc_ok:I = 0x7f080013

.field public static final add_pay_hint:I = 0x7f080014

.field public static final add_qty:I = 0x7f080015

.field public static final add_qty_hint:I = 0x7f080016

.field public static final add_save:I = 0x7f080017

.field public static final add_store_hint:I = 0x7f080018

.field public static final add_title:I = 0x7f080019

.field public static final alert_0_text:I = 0x7f08001a

.field public static final alert_0_title:I = 0x7f08001b

.field public static final alert_5_text:I = 0x7f08001c

.field public static final alert_5_title:I = 0x7f08001d

.field public static final alert_debt_text:I = 0x7f08001e

.field public static final app_name:I = 0x7f08001f

.field public static final auth_cancelled:I = 0x7f080020

.field public static final auth_cloud_fail:I = 0x7f080021

.field public static final auth_conn_fail:I = 0x7f080022

.field public static final auth_email_unverified:I = 0x7f080023

.field public static final auth_fail:I = 0x7f080024

.field public static final auth_no_consent:I = 0x7f080025

.field public static final auth_no_token:I = 0x7f080026

.field public static final auth_no_window:I = 0x7f080027

.field public static final back:I = 0x7f080028

.field public static final btn_add:I = 0x7f080029

.field public static final btn_cancel:I = 0x7f08002a

.field public static final btn_continue:I = 0x7f08002b

.field public static final btn_delete:I = 0x7f08002c

.field public static final btn_ok:I = 0x7f08002d

.field public static final btn_yes:I = 0x7f08002e

.field public static final calc_error:I = 0x7f08002f

.field public static final calc_insert:I = 0x7f080030

.field public static final calc_invalid:I = 0x7f080031

.field public static final calc_result:I = 0x7f080032

.field public static final calc_title:I = 0x7f080033

.field public static final card_add:I = 0x7f080034

.field public static final card_calc:I = 0x7f080035

.field public static final card_data:I = 0x7f080036

.field public static final card_salary:I = 0x7f080037

.field public static final card_shops:I = 0x7f080038

.field public static final chip_daily:I = 0x7f080039

.field public static final chip_monthly:I = 0x7f08003a

.field public static final col_amount:I = 0x7f08003b

.field public static final col_date:I = 0x7f08003c

.field public static final col_day:I = 0x7f08003d

.field public static final col_hour:I = 0x7f08003e

.field public static final col_item:I = 0x7f08003f

.field public static final col_pay:I = 0x7f080040

.field public static final col_qty:I = 0x7f080041

.field public static final col_remaining:I = 0x7f080042

.field public static final col_store:I = 0x7f080043

.field public static final csv_done:I = 0x7f080044

.field public static final csv_fail:I = 0x7f080045

.field public static final cur_set:I = 0x7f080046

.field public static final data_day_sum:I = 0x7f080047

.field public static final data_empty_day:I = 0x7f080048

.field public static final data_empty_month:I = 0x7f080049

.field public static final data_remaining:I = 0x7f08004a

.field public static final data_title:I = 0x7f08004b

.field public static final data_today:I = 0x7f08004c

.field public static final data_total_month:I = 0x7f08004d

.field public static final del_done:I = 0x7f08004e

.field public static final del_msg:I = 0x7f08004f

.field public static final del_title:I = 0x7f080050

.field public static final err_amount:I = 0x7f080051

.field public static final err_pay:I = 0x7f080052

.field public static final err_store:I = 0x7f080053

.field public static final err_store_exists:I = 0x7f080054

.field public static final err_store_name:I = 0x7f080055

.field public static final login_btn:I = 0x7f080056

.field public static final login_btn_register:I = 0x7f080057

.field public static final login_cloud_ok:I = 0x7f080058

.field public static final login_err_confirm:I = 0x7f080059

.field public static final login_err_name:I = 0x7f08005a

.field public static final login_err_pass:I = 0x7f08005b

.field public static final login_err_save:I = 0x7f08005c

.field public static final login_err_taken:I = 0x7f08005d

.field public static final login_err_wrong:I = 0x7f08005e

.field public static final login_gmail:I = 0x7f08005f

.field public static final login_gmail_sub:I = 0x7f080060

.field public static final login_have_account:I = 0x7f080061

.field public static final login_hint_full_name:I = 0x7f080062

.field public static final login_hint_username:I = 0x7f080063

.field public static final login_linking:I = 0x7f080064

.field public static final login_local_ok:I = 0x7f080065

.field public static final login_no_google:I = 0x7f080066

.field public static final login_register:I = 0x7f080067

.field public static final login_register_title:I = 0x7f080068

.field public static final login_sub:I = 0x7f080069

.field public static final login_title:I = 0x7f08006a

.field public static final login_welcome:I = 0x7f08006b

.field public static final main_available:I = 0x7f08006c

.field public static final main_empty:I = 0x7f08006d

.field public static final main_greeting:I = 0x7f08006e

.field public static final main_greeting_name:I = 0x7f08006f

.field public static final main_month_spent:I = 0x7f080070

.field public static final main_recent:I = 0x7f080071

.field public static final main_salary:I = 0x7f080072

.field public static final main_sub:I = 0x7f080073

.field public static final main_updates:I = 0x7f080074

.field public static final main_view_all:I = 0x7f080075

.field public static final mode_auto:I = 0x7f080076

.field public static final mode_dark:I = 0x7f080077

.field public static final mode_light:I = 0x7f080078

.field public static final new_store:I = 0x7f080079

.field public static final new_store_name:I = 0x7f08007a

.field public static final new_store_section:I = 0x7f08007b

.field public static final notif_add_action:I = 0x7f08007c

.field public static final notif_channel:I = 0x7f08007d

.field public static final notif_channel_alert:I = 0x7f08007e

.field public static final notif_channel_alert_desc:I = 0x7f08007f

.field public static final notif_channel_desc:I = 0x7f080080

.field public static final notif_midnight_text:I = 0x7f080081

.field public static final notif_midnight_title:I = 0x7f080082

.field public static final notif_off:I = 0x7f080083

.field public static final notif_on:I = 0x7f080084

.field public static final notif_ops_1:I = 0x7f080085

.field public static final notif_ops_n:I = 0x7f080086

.field public static final notif_remaining:I = 0x7f080087

.field public static final notif_salary_over:I = 0x7f080088

.field public static final notif_salary_warn:I = 0x7f080089

.field public static final notif_text:I = 0x7f08008a

.field public static final notif_title:I = 0x7f08008b

.field public static final notif_today_expense:I = 0x7f08008c

.field public static final overdraft_msg:I = 0x7f08008d

.field public static final overdraft_nab_msg:I = 0x7f08008e

.field public static final overdraft_nab_title:I = 0x7f08008f

.field public static final overdraft_title:I = 0x7f080090

.field public static final perm_alarm:I = 0x7f080091

.field public static final perm_alarm_d:I = 0x7f080092

.field public static final perm_batt:I = 0x7f080093

.field public static final perm_batt_d:I = 0x7f080094

.field public static final perm_cam:I = 0x7f080095

.field public static final perm_cam_d:I = 0x7f080096

.field public static final perm_granted:I = 0x7f080097

.field public static final perm_loc:I = 0x7f080098

.field public static final perm_loc_d:I = 0x7f080099

.field public static final perm_notif:I = 0x7f08009a

.field public static final perm_notif_d:I = 0x7f08009b

.field public static final pick_country:I = 0x7f08009c

.field public static final pick_currency:I = 0x7f08009d

.field public static final pick_pay_group:I = 0x7f08009e

.field public static final pick_store:I = 0x7f08009f

.field public static final pick_store_add:I = 0x7f0800a0

.field public static final prof_avatar:I = 0x7f0800a1

.field public static final prof_change_pic:I = 0x7f0800a2

.field public static final prof_country:I = 0x7f0800a3

.field public static final prof_country_set:I = 0x7f0800a4

.field public static final prof_currency:I = 0x7f0800a5

.field public static final prof_email:I = 0x7f0800a6

.field public static final prof_name:I = 0x7f0800a7

.field public static final prof_pic_fail:I = 0x7f0800a8

.field public static final prof_remove_pic:I = 0x7f0800a9

.field public static final prof_save:I = 0x7f0800aa

.field public static final prof_saved:I = 0x7f0800ab

.field public static final prof_search:I = 0x7f0800ac

.field public static final prof_title:I = 0x7f0800ad

.field public static final salary_current:I = 0x7f0800ae

.field public static final salary_debt_note:I = 0x7f0800af

.field public static final salary_hint:I = 0x7f0800b0

.field public static final salary_invalid:I = 0x7f0800b1

.field public static final salary_log:I = 0x7f0800b2

.field public static final salary_new_balance:I = 0x7f0800b3

.field public static final salary_none:I = 0x7f0800b4

.field public static final salary_prev_neg:I = 0x7f0800b5

.field public static final salary_save:I = 0x7f0800b6

.field public static final salary_saved:I = 0x7f0800b7

.field public static final salary_title:I = 0x7f0800b8

.field public static final saved_expense:I = 0x7f0800b9

.field public static final sec_account:I = 0x7f0800ba

.field public static final sec_currency:I = 0x7f0800bb

.field public static final sec_data:I = 0x7f0800bc

.field public static final sec_lang:I = 0x7f0800bd

.field public static final sec_notif:I = 0x7f0800be

.field public static final sec_perms:I = 0x7f0800bf

.field public static final sec_ui:I = 0x7f0800c0

.field public static final set_created:I = 0x7f0800c1

.field public static final set_cur_desc:I = 0x7f0800c2

.field public static final set_cur_row:I = 0x7f0800c3

.field public static final set_cur_sym:I = 0x7f0800c4

.field public static final set_edit_profile:I = 0x7f0800c5

.field public static final set_edit_profile_sub:I = 0x7f0800c6

.field public static final set_email_row:I = 0x7f0800c7

.field public static final set_lang_desc:I = 0x7f0800c8

.field public static final set_login_as:I = 0x7f0800c9

.field public static final set_logout:I = 0x7f0800ca

.field public static final set_logout_d:I = 0x7f0800cb

.field public static final set_no_account:I = 0x7f0800cc

.field public static final set_no_email:I = 0x7f0800cd

.field public static final set_notif_desc:I = 0x7f0800ce

.field public static final set_notif_row:I = 0x7f0800cf

.field public static final set_perms_desc:I = 0x7f0800d0

.field public static final set_prov_glocal:I = 0x7f0800d1

.field public static final set_prov_google:I = 0x7f0800d2

.field public static final set_prov_local:I = 0x7f0800d3

.field public static final set_prov_src:I = 0x7f0800d4

.field public static final set_stores:I = 0x7f0800d5

.field public static final set_stores_d:I = 0x7f0800d6

.field public static final set_title:I = 0x7f0800d7

.field public static final set_ui_desc:I = 0x7f0800d8

.field public static final set_wipe:I = 0x7f0800d9

.field public static final set_wipe_d:I = 0x7f0800da

.field public static final shops_add_btn:I = 0x7f0800db

.field public static final shops_add_title:I = 0x7f0800dc

.field public static final shops_list:I = 0x7f0800dd

.field public static final shops_none:I = 0x7f0800de

.field public static final shops_search:I = 0x7f0800df

.field public static final shops_title:I = 0x7f0800e0

.field public static final shops_write:I = 0x7f0800e1

.field public static final splash_sub:I = 0x7f0800e2

.field public static final store_added:I = 0x7f0800e3

.field public static final theme_applied:I = 0x7f0800e4

.field public static final theme_bl:I = 0x7f0800e5

.field public static final theme_co:I = 0x7f0800e6

.field public static final theme_current:I = 0x7f0800e7

.field public static final theme_cy:I = 0x7f0800e8

.field public static final theme_dk:I = 0x7f0800e9

.field public static final theme_em:I = 0x7f0800ea

.field public static final theme_gd:I = 0x7f0800eb

.field public static final theme_or:I = 0x7f0800ec

.field public static final theme_press:I = 0x7f0800ed

.field public static final theme_pu:I = 0x7f0800ee

.field public static final theme_ro:I = 0x7f0800ef

.field public static final theme_sl:I = 0x7f0800f0

.field public static final ui_mode:I = 0x7f0800f1

.field public static final upd_404:I = 0x7f0800f2

.field public static final upd_ask:I = 0x7f0800f3

.field public static final upd_checking:I = 0x7f0800f4

.field public static final upd_fail_title:I = 0x7f0800f5

.field public static final upd_great:I = 0x7f0800f6

.field public static final upd_http:I = 0x7f0800f7

.field public static final upd_later:I = 0x7f0800f8

.field public static final upd_new_ver:I = 0x7f0800f9

.field public static final upd_no_browser:I = 0x7f0800fa

.field public static final upd_no_net:I = 0x7f0800fb

.field public static final upd_now:I = 0x7f0800fc

.field public static final upd_title:I = 0x7f0800fd

.field public static final upd_unknown:I = 0x7f0800fe

.field public static final upd_uptd_msg:I = 0x7f0800ff

.field public static final upd_uptd_title:I = 0x7f080100

.field public static final upd_whats_new:I = 0x7f080101

.field public static final update_url:I = 0x7f080102

.field public static final update_url_fallback1:I = 0x7f080103

.field public static final update_url_fallback2:I = 0x7f080104

.field public static final wipe_done:I = 0x7f080105

.field public static final wipe_msg:I = 0x7f080106

.field public static final wipe_title:I = 0x7f080107

.field public static final wipe_yes:I = 0x7f080108


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 402
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
