.class Lcom/marwanalsidi/masrofi/SettingsActivity$21;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->confirmWipe()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 482
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$21;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 484
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$21;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object p1

    invoke-virtual {p1}, Lcom/marwanalsidi/masrofi/DBHelper;->wipeAll()I

    move-result p1

    .line 485
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$21;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    .line 486
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const p2, 0x7f080105

    invoke-virtual {p0, p2, p1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    .line 485
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 486
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method
