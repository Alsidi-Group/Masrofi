.class public Lcom/marwanalsidi/masrofi/LoginActivity;
.super Landroid/app/Activity;
.source "LoginActivity.java"


# static fields
.field private static final REQ_GMAIL:I = 0x37


# instance fields
.field private edConfirm:Landroid/widget/EditText;

.field private edName:Landroid/widget/EditText;

.field private edPass:Landroid/widget/EditText;

.field private registerMode:Z

.field private tGen:I

.field private tvError:Landroid/widget/TextView;

.field private tvTitle:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 17
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    .line 18
    iput-boolean v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    const/4 v0, -0x1

    .line 21
    iput v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/LoginActivity;)V
    .locals 0

    .line 17
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->doMain()V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/LoginActivity;)V
    .locals 0

    .line 17
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->toggleMode()V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/LoginActivity;)V
    .locals 0

    .line 17
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->pickGmail()V

    return-void
.end method

.method static synthetic access$300(Lcom/marwanalsidi/masrofi/LoginActivity;Ljava/lang/String;)V
    .locals 0

    .line 17
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$400(Lcom/marwanalsidi/masrofi/LoginActivity;)V
    .locals 0

    .line 17
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->goMain()V

    return-void
.end method

.method private doMain()V
    .locals 4

    .line 70
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edName:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 71
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edPass:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 72
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 73
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x2

    if-ge v2, v3, :cond_0

    const v0, 0x7f08005a

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void

    .line 74
    :cond_0
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x4

    if-ge v2, v3, :cond_1

    const v0, 0x7f08005b

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void

    .line 75
    :cond_1
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v2

    .line 76
    iget-boolean v3, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    if-eqz v3, :cond_4

    .line 77
    iget-object v3, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edConfirm:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 78
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    const v0, 0x7f080059

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void

    .line 79
    :cond_2
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->email(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v0, v1, v3}, Lcom/marwanalsidi/masrofi/DBHelper;->register(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_3

    const v0, 0x7f08005d

    .line 80
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void

    .line 83
    :cond_3
    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Prefs;->setLoggedIn(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x7f08006b

    .line 84
    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 85
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->goMain()V

    goto :goto_0

    .line 87
    :cond_4
    invoke-virtual {v2, v0, v1}, Lcom/marwanalsidi/masrofi/DBHelper;->login(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_5

    const v0, 0x7f08005e

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->err(Ljava/lang/String;)V

    return-void

    .line 88
    :cond_5
    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Prefs;->setLoggedIn(Landroid/content/Context;Ljava/lang/String;)V

    .line 89
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->goMain()V

    :goto_0
    return-void
.end method

.method private err(Ljava/lang/String;)V
    .locals 1

    .line 94
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 95
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    return-void
.end method

.method private goMain()V
    .locals 2

    .line 99
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/marwanalsidi/masrofi/MainActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->startActivity(Landroid/content/Intent;)V

    .line 100
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->finish()V

    return-void
.end method

.method private linkGoogle(Ljava/lang/String;)V
    .locals 2

    .line 136
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    const v0, 0x7f080064

    .line 137
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 138
    new-instance v0, Lcom/marwanalsidi/masrofi/LoginActivity$4;

    invoke-direct {v0, p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity$4;-><init>(Lcom/marwanalsidi/masrofi/LoginActivity;Ljava/lang/String;)V

    invoke-static {p0, p1, v0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->link(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;)V

    return-void
.end method

.method private pickGmail()V
    .locals 8

    const/4 v0, 0x0

    .line 108
    :try_start_0
    invoke-static {p0}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/String;

    const-string v4, "com.google"

    aput-object v4, v3, v0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 111
    invoke-static/range {v1 .. v7}, Landroid/accounts/AccountManager;->newChooseAccountIntent(Landroid/accounts/Account;Ljava/util/List;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x37

    .line 117
    invoke-virtual {p0, v1, v2}, Lcom/marwanalsidi/masrofi/LoginActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const v1, 0x7f080066

    .line 119
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method private toggleMode()V
    .locals 3

    .line 56
    iget-boolean v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    .line 57
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvTitle:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    const v0, 0x7f080068

    goto :goto_0

    :cond_0
    const v0, 0x7f08006a

    :goto_0
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 59
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edConfirm:Landroid/widget/EditText;

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    const/16 v2, 0x8

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    move v1, v2

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setVisibility(I)V

    .line 60
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edName:Landroid/widget/EditText;

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    if-eqz v1, :cond_2

    const v1, 0x7f080062

    goto :goto_2

    :cond_2
    const v1, 0x7f080063

    :goto_2
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const v0, 0x7f05000b

    .line 62
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    if-eqz v1, :cond_3

    const v1, 0x7f080057

    goto :goto_3

    :cond_3
    const v1, 0x7f080056

    :goto_3
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f050010

    .line 64
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iget-boolean v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->registerMode:Z

    if-eqz v1, :cond_4

    const v1, 0x7f080061

    goto :goto_4

    :cond_4
    const v1, 0x7f080067

    :goto_4
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 66
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 24
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    .line 125
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 126
    invoke-static {p1, p2}, Lcom/marwanalsidi/masrofi/GoogleAuth;->onConsentResult(II)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/16 v0, 0x37

    if-ne p1, v0, :cond_1

    const/4 p1, -0x1

    if-ne p2, p1, :cond_1

    if-eqz p3, :cond_1

    const-string p1, "authAccount"

    .line 129
    invoke-virtual {p3, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 130
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->linkGoogle(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 28
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->setTheme(I)V

    .line 29
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tGen:I

    const p1, 0x7f060003

    .line 31
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->setContentView(I)V

    const p1, 0x7f050019

    .line 33
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edName:Landroid/widget/EditText;

    const p1, 0x7f05001b

    .line 34
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edPass:Landroid/widget/EditText;

    const p1, 0x7f050018

    .line 35
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->edConfirm:Landroid/widget/EditText;

    const p1, 0x7f05002a

    .line 36
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvError:Landroid/widget/TextView;

    const p1, 0x7f05001f

    .line 37
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tvTitle:Landroid/widget/TextView;

    const p1, 0x7f05000b

    .line 38
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    const v0, 0x7f050010

    .line 39
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    const v1, 0x7f050021

    .line 40
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 42
    new-instance v2, Lcom/marwanalsidi/masrofi/LoginActivity$1;

    invoke-direct {v2, p0}, Lcom/marwanalsidi/masrofi/LoginActivity$1;-><init>(Lcom/marwanalsidi/masrofi/LoginActivity;)V

    invoke-virtual {p1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 45
    new-instance p1, Lcom/marwanalsidi/masrofi/LoginActivity$2;

    invoke-direct {p1, p0}, Lcom/marwanalsidi/masrofi/LoginActivity$2;-><init>(Lcom/marwanalsidi/masrofi/LoginActivity;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 48
    new-instance p1, Lcom/marwanalsidi/masrofi/LoginActivity$3;

    invoke-direct {p1, p0}, Lcom/marwanalsidi/masrofi/LoginActivity$3;-><init>(Lcom/marwanalsidi/masrofi/LoginActivity;)V

    invoke-virtual {v1, p1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 52
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object p1

    invoke-virtual {p1}, Lcom/marwanalsidi/masrofi/DBHelper;->hasUser()Z

    move-result p1

    if-nez p1, :cond_0

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->toggleMode()V

    :cond_0
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 159
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 160
    iget v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->recreate()V

    :cond_0
    return-void
.end method
