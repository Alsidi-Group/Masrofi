.class public Lcom/marwanalsidi/masrofi/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# instance fields
.field private tGen:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 10
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, -0x1

    .line 12
    iput v0, p0, Lcom/marwanalsidi/masrofi/MainActivity;->tGen:I

    return-void
.end method

.method private refresh()V
    .locals 17

    move-object/from16 v0, p0

    .line 74
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    const v2, 0x7f05002b

    .line 75
    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 76
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->userName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 77
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    const-string v3, ""

    goto :goto_0

    :cond_0
    invoke-virtual {v1, v3}, Lcom/marwanalsidi/masrofi/DBHelper;->displayName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 78
    :goto_0
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    const/4 v5, 0x0

    const-string v6, " "

    if-eqz v4, :cond_1

    const v3, 0x7f08006e

    invoke-virtual {v0, v3}, Lcom/marwanalsidi/masrofi/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    .line 79
    :cond_1
    invoke-virtual {v3, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v5

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const v4, 0x7f08006f

    invoke-virtual {v0, v4, v3}, Lcom/marwanalsidi/masrofi/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 78
    :goto_1
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 81
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    const/4 v3, 0x1

    .line 82
    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v4

    const/4 v7, 0x2

    .line 83
    invoke-virtual {v2, v7}, Ljava/util/Calendar;->get(I)I

    move-result v2

    add-int/2addr v2, v3

    .line 84
    invoke-virtual {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->getSalary()D

    move-result-wide v8

    .line 85
    invoke-virtual {v1, v4, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->sumMonth(II)D

    move-result-wide v10

    sub-double v12, v8, v10

    const v14, 0x7f050026

    .line 88
    invoke-virtual {v0, v14}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    const v15, 0x7f05002f

    .line 89
    invoke-virtual {v0, v15}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    const v7, 0x7f05002d

    .line 90
    invoke-virtual {v0, v7}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    .line 91
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencySymbol(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 92
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v16, v1

    invoke-static {v12, v13}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 93
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8, v9}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v15, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 94
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v10, v11}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-wide/16 v7, 0x0

    cmpg-double v1, v12, v7

    if-gez v1, :cond_2

    const v1, 0x7f010005

    .line 95
    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    goto :goto_2

    :cond_2
    const/4 v1, -0x1

    :goto_2
    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const v1, 0x7f050003

    .line 99
    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 100
    invoke-virtual {v1}, Landroid/widget/LinearLayout;->removeAllViews()V

    move-object/from16 v5, v16

    .line 101
    invoke-virtual {v5, v4, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->expensesForMonth(II)Ljava/util/List;

    move-result-object v2

    const v4, 0x7f050029

    .line 102
    invoke-virtual {v0, v4}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 104
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v5, 0x0

    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/String;

    const/4 v8, 0x4

    if-lt v5, v8, :cond_3

    goto :goto_4

    :cond_3
    add-int/lit8 v5, v5, 0x1

    const/4 v8, 0x0

    .line 107
    aget-object v9, v7, v8

    invoke-static {v9}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v9

    const/4 v11, 0x1

    .line 108
    aget-object v12, v7, v11

    invoke-static {v12}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v11

    const/4 v13, 0x2

    .line 109
    aget-object v14, v7, v13

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v9, v10}, Lcom/marwanalsidi/masrofi/Fmt;->day(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " \u2022 "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const/4 v10, 0x3

    aget-object v7, v7, v10

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "- "

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 110
    invoke-static {v11, v12}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x1

    .line 109
    invoke-static {v0, v14, v7, v9, v10}, Lcom/marwanalsidi/masrofi/Ui;->itemRow(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {v1, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_3

    :cond_4
    :goto_4
    const/4 v8, 0x0

    if-nez v5, :cond_5

    move v5, v8

    goto :goto_5

    :cond_5
    const/16 v5, 0x8

    .line 112
    :goto_5
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 15
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 19
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/MainActivity;->setTheme(I)V

    .line 20
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/CrashLog;->maybeShow(Landroid/app/Activity;)V

    .line 21
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/MainActivity;->tGen:I

    const p1, 0x7f060004

    .line 22
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->setContentView(I)V

    .line 24
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->requestNotifications(Landroid/app/Activity;)V

    .line 26
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->notifications(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 27
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/marwanalsidi/masrofi/NotificationService;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 30
    :catch_0
    :cond_0
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/MidnightReceiver;->schedule(Landroid/content/Context;)V

    .line 33
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->autoCheckSilent(Landroid/app/Activity;)V

    const p1, 0x7f050012

    .line 35
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$1;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050015

    .line 38
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$2;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$2;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050016

    .line 41
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$3;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$3;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050014

    .line 44
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$4;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$4;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050013

    .line 47
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$5;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$5;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05000f

    .line 50
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$6;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$6;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050006

    .line 53
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$7;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$7;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050011

    .line 56
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$8;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$8;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050025

    .line 59
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/MainActivity$9;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/MainActivity$9;-><init>(Lcom/marwanalsidi/masrofi/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 66
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 68
    iget v0, p0, Lcom/marwanalsidi/masrofi/MainActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/MainActivity;->recreate()V

    return-void

    .line 69
    :cond_0
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/MainActivity;->refresh()V

    .line 70
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    return-void
.end method
