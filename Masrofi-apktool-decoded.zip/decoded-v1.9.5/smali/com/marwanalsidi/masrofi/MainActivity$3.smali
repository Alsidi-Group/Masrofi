.class Lcom/marwanalsidi/masrofi/MainActivity$3;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/MainActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/MainActivity;)V
    .locals 0

    .line 41
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/MainActivity$3;->this$0:Lcom/marwanalsidi/masrofi/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 42
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/MainActivity$3;->this$0:Lcom/marwanalsidi/masrofi/MainActivity;

    new-instance v0, Landroid/content/Intent;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/MainActivity$3;->this$0:Lcom/marwanalsidi/masrofi/MainActivity;

    const-class v1, Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, v0}, Lcom/marwanalsidi/masrofi/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
