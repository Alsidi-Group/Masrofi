.class Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/UpdateChecker$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

.field final synthetic val$fErr:Ljava/lang/String;

.field final synthetic val$fInfo:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/UpdateChecker$1;Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 109
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fInfo:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fErr:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 111
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fInfo:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 112
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iget-object v0, v0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->currentVersionCode(Landroid/content/Context;)I

    move-result v0

    .line 113
    iget-object v2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fInfo:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    iget v2, v2, Lcom/marwanalsidi/masrofi/UpdateChecker$Info;->versionCode:I

    if-le v2, v0, :cond_0

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iget-object v0, v0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$cb:Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fInfo:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    invoke-interface {v0, p0, v1}, Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;->onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V

    return-void

    .line 114
    :cond_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$cb:Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;

    invoke-interface {p0, v1, v1}, Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;->onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V

    goto :goto_0

    .line 116
    :cond_1
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iget-object v0, v0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$cb:Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->val$fErr:Ljava/lang/String;

    if-nez v2, :cond_2

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;->this$0:Lcom/marwanalsidi/masrofi/UpdateChecker$1;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v2, 0x7f0800fe

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    :cond_2
    invoke-interface {v0, v1, v2}, Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;->onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V

    :goto_0
    return-void
.end method
