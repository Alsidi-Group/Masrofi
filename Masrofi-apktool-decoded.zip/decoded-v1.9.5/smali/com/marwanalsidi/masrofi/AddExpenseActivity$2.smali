.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 65
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 67
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    new-instance v0, Landroid/content/Intent;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const-class v1, Lcom/marwanalsidi/masrofi/CalculatorActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p0, "pick"

    const/4 v1, 0x1

    .line 68
    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x32

    .line 67
    invoke-virtual {p1, p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method
