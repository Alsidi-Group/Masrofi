.class public final Lcom/marwanalsidi/masrofi/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/marwanalsidi/masrofi/R$xml;,
        Lcom/marwanalsidi/masrofi/R$style;,
        Lcom/marwanalsidi/masrofi/R$string;,
        Lcom/marwanalsidi/masrofi/R$mipmap;,
        Lcom/marwanalsidi/masrofi/R$layout;,
        Lcom/marwanalsidi/masrofi/R$id;,
        Lcom/marwanalsidi/masrofi/R$drawable;,
        Lcom/marwanalsidi/masrofi/R$dimen;,
        Lcom/marwanalsidi/masrofi/R$color;,
        Lcom/marwanalsidi/masrofi/R$attr;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
