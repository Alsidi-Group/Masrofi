.class public Lcom/marwanalsidi/masrofi/MidnightReceiver;
.super Landroid/content/BroadcastReceiver;
.source "MidnightReceiver.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static schedule(Landroid/content/Context;)V
    .locals 8

    :try_start_0
    const-string v0, "alarm"

    .line 28
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/app/AlarmManager;

    if-nez v1, :cond_0

    return-void

    .line 30
    :cond_0
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v3, 0x1

    .line 31
    invoke-virtual {v0, v2, v3}, Ljava/util/Calendar;->add(II)V

    const/16 v2, 0xb

    const/4 v4, 0x0

    .line 32
    invoke-virtual {v0, v2, v4}, Ljava/util/Calendar;->set(II)V

    const/16 v2, 0xc

    .line 33
    invoke-virtual {v0, v2, v4}, Ljava/util/Calendar;->set(II)V

    const/16 v2, 0xd

    .line 34
    invoke-virtual {v0, v2, v4}, Ljava/util/Calendar;->set(II)V

    .line 37
    new-instance v2, Landroid/content/Intent;

    const-class v5, Lcom/marwanalsidi/masrofi/MidnightReceiver;

    invoke-direct {v2, p0, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v5, 0xc000000

    const/16 v6, 0x1e

    invoke-static {p0, v6, v2, v5}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v7

    .line 40
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1f

    if-lt v2, v5, :cond_2

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Perm;->exactAlarmsGranted(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    move v3, v4

    :cond_2
    :goto_0
    if-eqz v3, :cond_3

    .line 42
    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v2

    invoke-virtual {v1, v4, v2, v3, v7}, Landroid/app/AlarmManager;->setExactAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V

    goto :goto_1

    :cond_3
    const/4 v2, 0x0

    .line 44
    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v3

    const-wide/32 v5, 0xea60

    invoke-virtual/range {v1 .. v7}, Landroid/app/AlarmManager;->setWindow(IJJLandroid/app/PendingIntent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_1
    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    .line 15
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    .line 16
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->notifications(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    const p1, 0x7f080082

    .line 18
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const p2, 0x7f080081

    .line 19
    invoke-virtual {p0, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    .line 17
    invoke-static {p0, p1, p2}, Lcom/marwanalsidi/masrofi/NotificationService;->notifyDaily(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 21
    :cond_0
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/MidnightReceiver;->schedule(Landroid/content/Context;)V

    .line 22
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    return-void
.end method
