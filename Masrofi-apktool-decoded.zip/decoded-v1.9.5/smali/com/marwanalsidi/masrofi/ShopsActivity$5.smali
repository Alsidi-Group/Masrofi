.class Lcom/marwanalsidi/masrofi/ShopsActivity$5;
.super Ljava/lang/Object;
.source "ShopsActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ShopsActivity;->confirmRemove(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ShopsActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 152
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->val$name:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    .line 154
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object p1

    iget-object p2, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->val$name:Ljava/lang/String;

    invoke-virtual {p1, p2}, Lcom/marwanalsidi/masrofi/DBHelper;->removeStore(Ljava/lang/String;)Z

    .line 155
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    iget-object p2, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->val$name:Ljava/lang/String;

    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object p2

    const v0, 0x7f08004e

    invoke-virtual {p1, v0, p2}, Lcom/marwanalsidi/masrofi/ShopsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    .line 156
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ShopsActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ShopsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/ShopsActivity;->access$100(Lcom/marwanalsidi/masrofi/ShopsActivity;)V

    return-void
.end method
