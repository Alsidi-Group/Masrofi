.class Lcom/marwanalsidi/masrofi/SettingsActivity$2;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->accountSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;)V
    .locals 0

    .line 82
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    .line 83
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    new-instance v0, Landroid/content/Intent;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    const-class v1, Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, v0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
