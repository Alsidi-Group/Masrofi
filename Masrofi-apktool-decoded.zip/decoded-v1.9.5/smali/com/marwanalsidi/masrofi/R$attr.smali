.class public final Lcom/marwanalsidi/masrofi/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final themeAccent:I = 0x7f010000

.field public static final themeAccent2:I = 0x7f010001

.field public static final themeBg:I = 0x7f010002

.field public static final themeBtn:I = 0x7f010003

.field public static final themeCard:I = 0x7f010004

.field public static final themeDanger:I = 0x7f010005

.field public static final themeLine:I = 0x7f010006

.field public static final themeOk:I = 0x7f010007

.field public static final themeText:I = 0x7f010008

.field public static final themeTextSub:I = 0x7f010009


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
