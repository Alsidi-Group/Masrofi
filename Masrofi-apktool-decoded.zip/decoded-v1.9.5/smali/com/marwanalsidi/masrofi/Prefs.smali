.class public Lcom/marwanalsidi/masrofi/Prefs;
.super Ljava/lang/Object;
.source "Prefs.java"


# static fields
.field public static final CURRENCIES:[[Ljava/lang/String;

.field private static final FILE:Ljava/lang/String; = "masrofi_prefs"

.field public static final LEGACY_CODES:[Ljava/lang/String;

.field public static final THEME_NAMES:[Ljava/lang/String;

.field public static final THEME_NAME_RES:[I

.field public static final THEME_STYLES:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 30

    const-string v0, "Theme_Masrofi"

    const-string v1, "Theme_Masrofi_Blue"

    const-string v2, "Theme_Masrofi_Purple"

    const-string v3, "Theme_Masrofi_Dark"

    const-string v4, "Theme_Masrofi_Orange"

    const-string v5, "Theme_Masrofi_Rose"

    const-string v6, "Theme_Masrofi_Sky"

    const-string v7, "Theme_Masrofi_Gold"

    const-string v8, "Theme_Masrofi_Coral"

    const-string v9, "Theme_Masrofi_Slate"

    .line 12
    filled-new-array/range {v0 .. v9}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Prefs;->THEME_STYLES:[Ljava/lang/String;

    const-string v1, "\u0632\u0645\u0631\u062f\u064a"

    const-string v2, "\u0623\u0632\u0631\u0642 \u0645\u062d\u064a\u0637\u064a"

    const-string v3, "\u0628\u0646\u0641\u0633\u062c\u064a \u0645\u0644\u0643\u064a"

    const-string v4, "\u0644\u064a\u0644\u064a \u062f\u0627\u0643\u0646"

    const-string v5, "\u0628\u0631\u062a\u0642\u0627\u0644\u064a \u0635\u062d\u0631\u0627\u0648\u064a"

    const-string v6, "\u0648\u0631\u062f\u064a \u0623\u0646\u064a\u0642"

    const-string v7, "\u0633\u0645\u0627\u0648\u064a \u0645\u0634\u0631\u0642"

    const-string v8, "\u0630\u0647\u0628\u064a \u0641\u0627\u062e\u0631"

    const-string v9, "\u0623\u062d\u0645\u0631 \u0645\u0631\u062c\u0627\u0646\u064a"

    const-string v10, "\u0631\u0645\u0627\u062f\u064a \u0643\u0644\u0627\u0633\u064a\u0643\u064a"

    .line 19
    filled-new-array/range {v1 .. v10}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Prefs;->THEME_NAMES:[Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [I

    .line 23
    fill-array-data v0, :array_0

    sput-object v0, Lcom/marwanalsidi/masrofi/Prefs;->THEME_NAME_RES:[I

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u0644\u064a\u0628\u064a"

    const-string v1, "\u062f.\u0644"

    .line 30
    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v2

    const-string v0, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a"

    const-string v1, "$"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v3

    const-string v0, "\u064a\u0648\u0631\u0648"

    const-string v1, "\u20ac"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v4

    const-string v0, "\u062c\u0646\u064a\u0647 \u0625\u0633\u062a\u0631\u0644\u064a\u0646\u064a"

    const-string v1, "\u00a3"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v5

    const-string v0, "\u0631\u064a\u0627\u0644 \u0633\u0639\u0648\u062f\u064a"

    const-string v1, "\u0631.\u0633"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v6

    const-string v0, "\u062f\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062a\u064a"

    const-string v1, "\u062f.\u0625"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v7

    const-string v0, "\u062c\u0646\u064a\u0647 \u0645\u0635\u0631\u064a"

    const-string v1, "\u062c.\u0645"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v8

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u062a\u0648\u0646\u0633\u064a"

    const-string v1, "\u062f.\u062a"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v9

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u062c\u0632\u0627\u0626\u0631\u064a"

    const-string v1, "\u062f.\u062c"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v10

    const-string v0, "\u062f\u0631\u0647\u0645 \u0645\u063a\u0631\u0628\u064a"

    const-string v1, "\u062f.\u0645"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v11

    const-string v0, "\u0631\u064a\u0627\u0644 \u0642\u0637\u0631\u064a"

    const-string v1, "\u0631.\u0642"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v12

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u0643\u0648\u064a\u062a\u064a"

    const-string v1, "\u062f.\u0643"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v13

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u0628\u062d\u0631\u064a\u0646\u064a"

    const-string v1, "\u062f.\u0628"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v14

    const-string v0, "\u0631\u064a\u0627\u0644 \u0639\u0645\u0627\u0646\u064a"

    const-string v1, "\u0631.\u0639"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v15

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u0623\u0631\u062f\u0646\u064a"

    const-string v1, "\u062f.\u0623"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v16

    const-string v0, "\u0644\u064a\u0631\u0629 \u062a\u0631\u0643\u064a\u0629"

    const-string v1, "\u20ba"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v17

    const-string v0, "\u0641\u0631\u0646\u0643 \u0633\u0648\u064a\u0633\u0631\u064a"

    const-string v1, "\u20a3"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v18

    const-string v0, "\u064a\u0648\u0627\u0646 \u0635\u064a\u0646\u064a"

    const-string v1, "\u00a5"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v19

    const-string v0, "\u064a\u0646 \u064a\u0627\u0628\u0627\u0646\u064a"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v20

    const-string v0, "\u062f\u0648\u0644\u0627\u0631 \u0643\u0646\u062f\u064a"

    const-string v1, "C$"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v21

    const-string v0, "\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a"

    const-string v1, "A$"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v22

    const-string v0, "\u0631\u0648\u0628\u0644 \u0631\u0648\u0633\u064a"

    const-string v1, "\u20bd"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v23

    const-string v0, "\u0631\u0648\u0628\u064a\u0629 \u0647\u0646\u062f\u064a\u0629"

    const-string v1, "\u20b9"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v24

    const-string v0, "\u0648\u0648\u0646 \u0643\u0648\u0631\u064a"

    const-string v1, "\u20a9"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v25

    const-string v0, "\u062f\u064a\u0646\u0627\u0631 \u0639\u0631\u0627\u0642\u064a"

    const-string v1, "\u062f.\u0639"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v26

    const-string v0, "\u0644\u064a\u0631\u0629 \u0633\u0648\u0631\u064a\u0629"

    const-string v1, "\u0644.\u0633"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v27

    const-string v0, "\u0631\u064a\u0627\u0644 \u064a\u0645\u0646\u064a"

    const-string v1, "\u0631.\u064a"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v28

    const-string v0, "\u0631\u064a\u0627\u0644 \u0633\u0648\u062f\u0627\u0646\u064a"

    const-string v1, "\u062c.\u0633"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v29

    filled-new-array/range {v2 .. v29}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Prefs;->CURRENCIES:[[Ljava/lang/String;

    const-string v1, "LYD"

    const-string v2, "USD"

    const-string v3, "EUR"

    const-string v4, "GBP"

    const-string v5, "SAR"

    const-string v6, "AED"

    const-string v7, "EGP"

    const-string v8, "TND"

    const-string v9, "DZD"

    const-string v10, "MAD"

    const-string v11, "QAR"

    const-string v12, "KWD"

    const-string v13, "BHD"

    const-string v14, "OMR"

    const-string v15, "JOD"

    const-string v16, "TRY"

    const-string v17, "CHF"

    const-string v18, "CNY"

    const-string v19, "JPY"

    const-string v20, "CAD"

    const-string v21, "AUD"

    const-string v22, "RUB"

    const-string v23, "INR"

    const-string v24, "KRW"

    const-string v25, "IQD"

    const-string v26, "SYP"

    const-string v27, "YER"

    const-string v28, "SDG"

    .line 43
    filled-new-array/range {v1 .. v28}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Prefs;->LEGACY_CODES:[Ljava/lang/String;

    return-void

    :array_0
    .array-data 4
        0x7f0800ea
        0x7f0800e5
        0x7f0800ee
        0x7f0800e9
        0x7f0800ec
        0x7f0800ef
        0x7f0800e8
        0x7f0800eb
        0x7f0800e6
        0x7f0800f0
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static avatar(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 133
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "avatar"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static bumpThemeGen(Landroid/content/Context;)V
    .locals 2

    .line 90
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p0

    add-int/lit8 p0, p0, 0x1

    const-string v1, "theme_gen"

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static countryCode(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 127
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "country"

    const-string v1, "LY"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static currencyCode(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 97
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v1, 0x0

    const-string v2, "cur_code"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 98
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    return-object v0

    .line 99
    :cond_0
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "currency"

    const/4 v3, 0x0

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-ltz v0, :cond_1

    .line 100
    sget-object v1, Lcom/marwanalsidi/masrofi/Prefs;->LEGACY_CODES:[Ljava/lang/String;

    array-length v3, v1

    if-ge v0, v3, :cond_1

    aget-object v0, v1, v0

    goto :goto_0

    :cond_1
    const-string v0, "LYD"

    .line 101
    :goto_0
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-object v0
.end method

.method public static currencyInfo(Landroid/content/Context;)[Ljava/lang/String;
    .locals 6

    .line 111
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyCode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    .line 112
    sget-object v0, Lcom/marwanalsidi/masrofi/Countries;->ROWS:[[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, v0, v3

    const/4 v5, 0x3

    .line 113
    aget-object v5, v4, v5

    invoke-virtual {v5, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 p0, 0x4

    aget-object p0, v4, p0

    const/4 v0, 0x5

    aget-object v0, v4, v0

    filled-new-array {p0, v0}, [Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 115
    :cond_1
    :goto_1
    sget-object v0, Lcom/marwanalsidi/masrofi/Prefs;->LEGACY_CODES:[Ljava/lang/String;

    array-length v1, v0

    if-ge v2, v1, :cond_3

    .line 116
    aget-object v0, v0, v2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lcom/marwanalsidi/masrofi/Prefs;->CURRENCIES:[[Ljava/lang/String;

    array-length v1, v0

    if-ge v2, v1, :cond_2

    aget-object p0, v0, v2

    return-object p0

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    const-string p0, "\u062f\u064a\u0646\u0627\u0631 \u0644\u064a\u0628\u064a"

    const-string v0, "\u062f.\u0644"

    .line 118
    filled-new-array {p0, v0}, [Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static currencyName(Landroid/content/Context;)Ljava/lang/String;
    .locals 1

    .line 123
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyInfo(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    aget-object p0, p0, v0

    return-object p0
.end method

.method public static currencySymbol(Landroid/content/Context;)Ljava/lang/String;
    .locals 1

    .line 121
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->currencyInfo(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x1

    aget-object p0, p0, v0

    return-object p0
.end method

.method public static email(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 162
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "email"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static isDark(Landroid/content/Context;)Z
    .locals 3

    .line 68
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->mode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "dark"

    .line 69
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    return v2

    :cond_0
    const-string v1, "light"

    .line 70
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    return v1

    .line 71
    :cond_1
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    iget p0, p0, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 p0, p0, 0x30

    const/16 v0, 0x20

    if-ne p0, v0, :cond_2

    goto :goto_0

    :cond_2
    move v2, v1

    :goto_0
    return v2
.end method

.method public static loggedIn(Landroid/content/Context;)Z
    .locals 2

    .line 152
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "logged"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public static logout(Landroid/content/Context;)V
    .locals 2

    .line 160
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "logged"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static mode(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 60
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "ui_mode"

    const-string v1, "auto"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static notifications(Landroid/content/Context;)Z
    .locals 2

    .line 141
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "notif"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public static salAlert(Landroid/content/Context;)I
    .locals 2

    .line 146
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "sal_alert"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static sectionOpen(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 2

    .line 169
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "open_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public static setAvatar(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 136
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "avatar"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setCountryCode(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 130
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "country"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setCurrencyCode(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 106
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "cur_code"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setEmail(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 164
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "email"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setLoggedIn(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    .line 157
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "logged"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "uname"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setMode(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    .line 63
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ui_mode"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 64
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->bumpThemeGen(Landroid/content/Context;)V

    return-void
.end method

.method public static setNotifications(Landroid/content/Context;Z)V
    .locals 1

    .line 143
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "notif"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setSalAlert(Landroid/content/Context;I)V
    .locals 1

    .line 148
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sal_alert"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setSectionOpen(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 2

    .line 173
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "open_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setTheme(Landroid/content/Context;I)V
    .locals 1

    .line 57
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "theme"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private static sp(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 2

    .line 50
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "masrofi_prefs"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method public static themeGen(Landroid/content/Context;)I
    .locals 2

    .line 87
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "theme_gen"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static themeIndex(Landroid/content/Context;)I
    .locals 2

    .line 55
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "theme"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static themeRes(Landroid/content/Context;)I
    .locals 6

    .line 77
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeIndex(Landroid/content/Context;)I

    move-result v0

    if-ltz v0, :cond_0

    .line 78
    sget-object v1, Lcom/marwanalsidi/masrofi/Prefs;->THEME_STYLES:[Ljava/lang/String;

    array-length v1, v1

    if-lt v0, v1, :cond_1

    :cond_0
    const/4 v0, 0x0

    .line 79
    :cond_1
    sget-object v1, Lcom/marwanalsidi/masrofi/Prefs;->THEME_STYLES:[Ljava/lang/String;

    aget-object v2, v1, v0

    .line 80
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->isDark(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, 0x3

    if-eq v0, v3, :cond_2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "_Dark"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 81
    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "style"

    invoke-virtual {v3, v2, v5, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_3

    .line 82
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    aget-object v0, v1, v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, v0, v5, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    :cond_3
    if-eqz v2, :cond_4

    goto :goto_0

    :cond_4
    const/high16 v2, 0x7f090000

    :goto_0
    return v2
.end method

.method public static userName(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 154
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->sp(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "uname"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
