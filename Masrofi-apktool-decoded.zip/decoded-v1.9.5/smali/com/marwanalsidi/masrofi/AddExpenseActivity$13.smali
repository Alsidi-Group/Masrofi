.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 246
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    # v1.9.5 — زر back محمي: لا انهيار ولا استثناء هارب من هذه السلسلة
    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$100(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/CrashLog;->capture(Ljava/lang/Throwable;)V

    return-void
.end method
