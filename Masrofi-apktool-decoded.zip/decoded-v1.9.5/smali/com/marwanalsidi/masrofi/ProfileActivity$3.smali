.class Lcom/marwanalsidi/masrofi/ProfileActivity$3;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$edEmail:Landroid/widget/EditText;

.field final synthetic val$tvCountry:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 114
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->val$tvCountry:Landroid/widget/TextView;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->val$edEmail:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 115
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->val$tvCountry:Landroid/widget/TextView;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$3;->val$edEmail:Landroid/widget/EditText;

    invoke-static {p1, v0, p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$100(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method
