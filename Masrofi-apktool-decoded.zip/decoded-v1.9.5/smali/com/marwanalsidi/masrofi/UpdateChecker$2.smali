.class Lcom/marwanalsidi/masrofi/UpdateChecker$2;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/UpdateChecker;->showUpdateDialog(Landroid/app/Activity;Lcom/marwanalsidi/masrofi/UpdateChecker$Info;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$act:Landroid/app/Activity;

.field final synthetic val$u:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;


# direct methods
.method constructor <init>(Landroid/app/Activity;Lcom/marwanalsidi/masrofi/UpdateChecker$Info;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 169
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$2;->val$act:Landroid/app/Activity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$2;->val$u:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 172
    :try_start_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$2;->val$act:Landroid/app/Activity;

    new-instance p2, Landroid/content/Intent;

    const-string v0, "android.intent.action.VIEW"

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$2;->val$u:Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    iget-object v1, v1, Lcom/marwanalsidi/masrofi/UpdateChecker$Info;->apkUrl:Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-direct {p2, v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p1, p2}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 174
    :catch_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$2;->val$act:Landroid/app/Activity;

    const p1, 0x7f0800fa

    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method
