.class Lcom/marwanalsidi/masrofi/ProfileActivity$10;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->pickAvatar()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;)V
    .locals 0

    .line 294
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$10;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 297
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.PICK"

    sget-object v2, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 299
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$10;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    const/16 v2, 0x3c

    invoke-virtual {v1, v0, v2}, Lcom/marwanalsidi/masrofi/ProfileActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 301
    :catch_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$10;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    const v0, 0x7f0800a8

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method
