.class public final Lcom/marwanalsidi/masrofi/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final Theme_Masrofi:I = 0x7f090000

.field public static final Theme_Masrofi_Blue:I = 0x7f090001

.field public static final Theme_Masrofi_Blue_Dark:I = 0x7f090002

.field public static final Theme_Masrofi_Coral:I = 0x7f090003

.field public static final Theme_Masrofi_Coral_Dark:I = 0x7f090004

.field public static final Theme_Masrofi_Dark:I = 0x7f090005

.field public static final Theme_Masrofi_Gold:I = 0x7f090006

.field public static final Theme_Masrofi_Gold_Dark:I = 0x7f090007

.field public static final Theme_Masrofi_Orange:I = 0x7f090008

.field public static final Theme_Masrofi_Orange_Dark:I = 0x7f090009

.field public static final Theme_Masrofi_Purple:I = 0x7f09000a

.field public static final Theme_Masrofi_Purple_Dark:I = 0x7f09000b

.field public static final Theme_Masrofi_Rose:I = 0x7f09000c

.field public static final Theme_Masrofi_Rose_Dark:I = 0x7f09000d

.field public static final Theme_Masrofi_Sky:I = 0x7f09000e

.field public static final Theme_Masrofi_Sky_Dark:I = 0x7f09000f

.field public static final Theme_Masrofi_Slate:I = 0x7f090010

.field public static final Theme_Masrofi_Slate_Dark:I = 0x7f090011


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 732
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
