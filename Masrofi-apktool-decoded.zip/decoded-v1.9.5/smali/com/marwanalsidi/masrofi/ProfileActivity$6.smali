.class Lcom/marwanalsidi/masrofi/ProfileActivity$6;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->pickCountry(Landroid/widget/TextView;Landroid/widget/EditText;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$all:Ljava/util/List;

.field final synthetic val$edEmail:Landroid/widget/EditText;

.field final synthetic val$listBox:Landroid/widget/LinearLayout;

.field final synthetic val$tvCountry:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 196
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$listBox:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$all:Ljava/util/List;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$tvCountry:Landroid/widget/TextView;

    iput-object p5, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$edEmail:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 6

    .line 200
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$listBox:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$all:Ljava/util/List;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$tvCountry:Landroid/widget/TextView;

    iget-object v5, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$6;->val$edEmail:Landroid/widget/EditText;

    invoke-static/range {v0 .. v5}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$400(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;Landroid/widget/TextView;Landroid/widget/EditText;)V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method
