.class Lcom/marwanalsidi/masrofi/AboutActivity$2$1;
.super Ljava/lang/Object;
.source "AboutActivity.java"

# interfaces
.implements Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AboutActivity$2;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

.field final synthetic val$status:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AboutActivity$2;Landroid/widget/TextView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 37
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->val$status:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDone(Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V
    .locals 2

    if-eqz p1, :cond_0

    .line 40
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->val$status:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

    iget-object v0, v0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    iget-object p1, p1, Lcom/marwanalsidi/masrofi/UpdateChecker$Info;->versionName:Ljava/lang/String;

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const v1, 0x7f080005

    invoke-virtual {v0, v1, p1}, Lcom/marwanalsidi/masrofi/AboutActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 41
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/UpdateChecker;->checkAndShow(Landroid/app/Activity;)V

    goto :goto_0

    :cond_0
    if-eqz p2, :cond_1

    .line 43
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->val$status:Landroid/widget/TextView;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    const v0, 0x7f080004

    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p0, v0, p2}, Lcom/marwanalsidi/masrofi/AboutActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 45
    :cond_1
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->val$status:Landroid/widget/TextView;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2$1;->this$1:Lcom/marwanalsidi/masrofi/AboutActivity$2;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AboutActivity$2;->this$0:Lcom/marwanalsidi/masrofi/AboutActivity;

    const p2, 0x7f080009

    invoke-virtual {p0, p2}, Lcom/marwanalsidi/masrofi/AboutActivity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_0
    return-void
.end method
