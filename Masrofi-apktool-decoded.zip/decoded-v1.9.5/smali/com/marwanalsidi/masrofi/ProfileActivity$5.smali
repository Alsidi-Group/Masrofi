.class Lcom/marwanalsidi/masrofi/ProfileActivity$5;
.super Ljava/lang/Object;
.source "ProfileActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/ProfileActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

.field final synthetic val$edEmail:Landroid/widget/EditText;

.field final synthetic val$edName:Landroid/widget/EditText;

.field final synthetic val$uname:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/ProfileActivity;Landroid/widget/EditText;Landroid/widget/EditText;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 131
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$edName:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$edEmail:Landroid/widget/EditText;

    iput-object p4, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$uname:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    .line 133
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$edName:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 134
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$edEmail:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 135
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 136
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    const p1, 0x7f08005a

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 139
    :cond_0
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->val$uname:Ljava/lang/String;

    invoke-virtual {v1, v2, p1, v0}, Lcom/marwanalsidi/masrofi/DBHelper;->updateProfile(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 140
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/ProfileActivity;->access$300(Lcom/marwanalsidi/masrofi/ProfileActivity;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/marwanalsidi/masrofi/Prefs;->setCountryCode(Landroid/content/Context;Ljava/lang/String;)V

    .line 141
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Prefs;->bumpThemeGen(Landroid/content/Context;)V

    .line 142
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    const v0, 0x7f0800ab

    invoke-virtual {p1, v0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    .line 143
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/ProfileActivity$5;->this$0:Lcom/marwanalsidi/masrofi/ProfileActivity;

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/ProfileActivity;->finish()V

    return-void
.end method
