.class public final Lcom/marwanalsidi/masrofi/GoogleAuth;
.super Ljava/lang/Object;
.source "GoogleAuth.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;
    }
.end annotation


# static fields
.field public static final REQ_CONSENT:I = 0x38

.field private static busy:Z = false

.field private static pendingAccount:Ljava/lang/String;

.field private static pendingAct:Landroid/app/Activity;

.field private static pendingCb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 0

    .line 26
    invoke-static {p0, p1, p2, p3}, Lcom/marwanalsidi/masrofi/GoogleAuth;->finish(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    return-void
.end method

.method static synthetic access$100(Ljava/lang/Exception;)Landroid/content/Intent;
    .locals 0

    .line 26
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->extractConsentIntent(Ljava/lang/Exception;)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$200(Ljava/lang/Exception;)Ljava/lang/String;
    .locals 0

    .line 26
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->reason(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static attempt(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Z)V
    .locals 1

    .line 66
    new-instance p2, Ljava/lang/Thread;

    new-instance v0, Lcom/marwanalsidi/masrofi/GoogleAuth$1;

    invoke-direct {v0, p0, p1, p3}, Lcom/marwanalsidi/masrofi/GoogleAuth$1;-><init>(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-direct {p2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 166
    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static extractConsentIntent(Ljava/lang/Exception;)Landroid/content/Intent;
    .locals 5

    const/4 v0, 0x0

    .line 171
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "getIntent"

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    new-array v2, v3, [Ljava/lang/Object;

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .line 172
    instance-of v1, p0, Landroid/content/Intent;

    if-eqz v1, :cond_0

    check-cast p0, Landroid/content/Intent;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, p0

    :catch_0
    :cond_0
    return-object v0
.end method

.method private static finish(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 8

    const/4 v0, 0x0

    .line 187
    sput-boolean v0, Lcom/marwanalsidi/masrofi/GoogleAuth;->busy:Z

    .line 188
    sget-object v2, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingCb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    const/4 v0, 0x0

    .line 190
    sput-object v0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingCb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    .line 191
    sput-object v0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAct:Landroid/app/Activity;

    .line 192
    sput-object v0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAccount:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 194
    :cond_0
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v7, Lcom/marwanalsidi/masrofi/GoogleAuth$2;

    move-object v1, v7

    move-object v3, p0

    move-object v4, p1

    move v5, p2

    move-object v6, p3

    invoke-direct/range {v1 .. v6}, Lcom/marwanalsidi/masrofi/GoogleAuth$2;-><init>(Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    invoke-virtual {v0, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static declared-synchronized link(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;)V
    .locals 2

    const-class v0, Lcom/marwanalsidi/masrofi/GoogleAuth;

    monitor-enter v0

    .line 42
    :try_start_0
    sget-boolean v1, Lcom/marwanalsidi/masrofi/GoogleAuth;->busy:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_0

    monitor-exit v0

    return-void

    .line 43
    :cond_0
    :try_start_1
    sput-object p0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAct:Landroid/app/Activity;

    .line 44
    sput-object p1, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAccount:Ljava/lang/String;

    .line 45
    sput-object p2, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingCb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    const/4 v1, 0x1

    .line 46
    sput-boolean v1, Lcom/marwanalsidi/masrofi/GoogleAuth;->busy:Z

    const/4 v1, 0x0

    .line 47
    invoke-static {p0, p1, p2, v1}, Lcom/marwanalsidi/masrofi/GoogleAuth;->attempt(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 48
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static onConsentResult(II)Z
    .locals 2

    const/16 v0, 0x38

    const/4 v1, 0x0

    if-ne p0, v0, :cond_1

    const/4 p0, -0x1

    if-ne p1, p0, :cond_0

    .line 58
    sget-object p0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAct:Landroid/app/Activity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->retry(Landroid/app/Activity;)V

    goto :goto_0

    .line 59
    :cond_0
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object p0

    const p1, 0x7f080025

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p1, p1, v1, p0}, Lcom/marwanalsidi/masrofi/GoogleAuth;->finish(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    :goto_0
    const/4 p0, 0x1

    return p0

    :cond_1
    return v1
.end method

.method private static reason(Ljava/lang/Exception;)Ljava/lang/String;
    .locals 4

    if-nez p0, :cond_0

    const-string v0, ""

    goto :goto_0

    .line 179
    :cond_0
    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    const-string v1, "Network"

    .line 180
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "timeout"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "connect"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    .line 182
    :cond_1
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object v1

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    .line 183
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    :cond_2
    const/4 p0, 0x0

    aput-object v0, v2, p0

    const p0, 0x7f080024

    .line 182
    invoke-virtual {v1, p0, v2}, Lcom/marwanalsidi/masrofi/App;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 181
    :cond_3
    :goto_1
    invoke-static {}, Lcom/marwanalsidi/masrofi/App;->get()Lcom/marwanalsidi/masrofi/App;

    move-result-object p0

    const v0, 0x7f080022

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/App;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static declared-synchronized retry(Landroid/app/Activity;)V
    .locals 4

    const-class v0, Lcom/marwanalsidi/masrofi/GoogleAuth;

    monitor-enter v0

    .line 51
    :try_start_0
    sget-boolean v1, Lcom/marwanalsidi/masrofi/GoogleAuth;->busy:Z

    if-eqz v1, :cond_2

    sget-object v1, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAccount:Ljava/lang/String;

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    if-eqz p0, :cond_1

    goto :goto_0

    .line 52
    :cond_1
    sget-object p0, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingAct:Landroid/app/Activity;

    :goto_0
    sget-object v2, Lcom/marwanalsidi/masrofi/GoogleAuth;->pendingCb:Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;

    const/4 v3, 0x1

    invoke-static {p0, v1, v2, v3}, Lcom/marwanalsidi/masrofi/GoogleAuth;->attempt(Landroid/app/Activity;Ljava/lang/String;Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 53
    monitor-exit v0

    return-void

    .line 51
    :cond_2
    :goto_1
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method
