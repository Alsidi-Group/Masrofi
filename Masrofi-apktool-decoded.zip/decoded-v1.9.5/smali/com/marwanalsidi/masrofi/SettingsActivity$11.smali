.class Lcom/marwanalsidi/masrofi/SettingsActivity$11;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->fillCurList(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$r:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;[Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 330
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->val$r:[Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 332
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->val$r:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Prefs;->setCurrencyCode(Landroid/content/Context;Ljava/lang/String;)V

    .line 333
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->val$r:[Ljava/lang/String;

    const/4 v2, 0x1

    aget-object v2, v1, v2

    const/4 v3, 0x2

    aget-object v1, v1, v3

    filled-new-array {v2, v1}, [Ljava/lang/Object;

    move-result-object v1

    const v2, 0x7f080046

    invoke-virtual {v0, v2, v1}, Lcom/marwanalsidi/masrofi/SettingsActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    .line 334
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$11;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->access$300(Lcom/marwanalsidi/masrofi/SettingsActivity;)V

    return-void
.end method
