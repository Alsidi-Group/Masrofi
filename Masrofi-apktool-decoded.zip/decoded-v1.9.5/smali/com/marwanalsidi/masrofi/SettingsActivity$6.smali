.class Lcom/marwanalsidi/masrofi/SettingsActivity$6;
.super Ljava/lang/Object;
.source "SettingsActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SettingsActivity;->uiSection()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

.field final synthetic val$idx:I


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SettingsActivity;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 191
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$6;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iput p2, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$6;->val$idx:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 192
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$6;->this$0:Lcom/marwanalsidi/masrofi/SettingsActivity;

    iget p0, p0, Lcom/marwanalsidi/masrofi/SettingsActivity$6;->val$idx:I

    invoke-static {p1, p0}, Lcom/marwanalsidi/masrofi/SettingsActivity;->access$000(Lcom/marwanalsidi/masrofi/SettingsActivity;I)V

    return-void
.end method
