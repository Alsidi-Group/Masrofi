.class Lcom/marwanalsidi/masrofi/LoginActivity$4;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Lcom/marwanalsidi/masrofi/GoogleAuth$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/LoginActivity;->linkGoogle(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

.field final synthetic val$acc:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/LoginActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 138
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->val$acc:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDone(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 4

    .line 140
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_7

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/LoginActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_4

    :cond_0
    if-eqz p1, :cond_1

    goto :goto_0

    .line 141
    :cond_1
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->val$acc:Ljava/lang/String;

    :goto_0
    const/4 v0, 0x0

    if-eqz p2, :cond_2

    .line 142
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    const-string p2, "@"

    invoke-virtual {p1, p2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    aget-object p2, p2, v0

    .line 143
    :goto_1
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    .line 144
    invoke-virtual {v1, p1, p2, p3}, Lcom/marwanalsidi/masrofi/DBHelper;->upsertGoogleUser(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p2

    if-nez p2, :cond_3

    .line 145
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    const p1, 0x7f08005c

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/LoginActivity;->access$300(Lcom/marwanalsidi/masrofi/LoginActivity;Ljava/lang/String;)V

    return-void

    .line 146
    :cond_3
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-static {p2, p1}, Lcom/marwanalsidi/masrofi/Prefs;->setEmail(Landroid/content/Context;Ljava/lang/String;)V

    .line 147
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-static {p2, p1}, Lcom/marwanalsidi/masrofi/Prefs;->setLoggedIn(Landroid/content/Context;Ljava/lang/String;)V

    .line 148
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    if-eqz p3, :cond_4

    const v1, 0x7f080058

    goto :goto_2

    :cond_4
    const v1, 0x7f080065

    :goto_2
    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Object;

    if-eqz p3, :cond_5

    move-object p4, p1

    goto :goto_3

    :cond_5
    if-nez p4, :cond_6

    const-string p4, ""

    :cond_6
    :goto_3
    aput-object p4, v3, v0

    invoke-virtual {p2, v1, v3}, Lcom/marwanalsidi/masrofi/LoginActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 151
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 152
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/LoginActivity$4;->this$0:Lcom/marwanalsidi/masrofi/LoginActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/LoginActivity;->access$400(Lcom/marwanalsidi/masrofi/LoginActivity;)V

    :cond_7
    :goto_4
    return-void
.end method
