.class public final Lcom/marwanalsidi/masrofi/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final corner:I = 0x7f030000

.field public static final pad_l:I = 0x7f030001

.field public static final pad_m:I = 0x7f030002

.field public static final pad_s:I = 0x7f030003

.field public static final pad_xs:I = 0x7f030004


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 290
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
