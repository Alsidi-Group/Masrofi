.class Lcom/marwanalsidi/masrofi/UpdateChecker$1;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/UpdateChecker;->check(Landroid/content/Context;Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$c:Landroid/content/Context;

.field final synthetic val$cb:Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;

.field final synthetic val$h:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/os/Handler;Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 76
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$h:Landroid/os/Handler;

    iput-object p3, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$cb:Lcom/marwanalsidi/masrofi/UpdateChecker$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    .line 80
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v1, 0x7f080102

    .line 81
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v2, 0x7f080103

    .line 82
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v3, 0x7f080104

    .line 83
    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    move v4, v1

    move v3, v2

    move v5, v3

    :goto_0
    const/4 v6, 0x0

    const/4 v7, 0x3

    if-ge v3, v7, :cond_1

    .line 87
    aget-object v7, v0, v3

    .line 89
    :try_start_0
    filled-new-array {v1}, [I

    move-result-object v8

    .line 90
    invoke-static {v7, v8}, Lcom/marwanalsidi/masrofi/UpdateChecker;->access$000(Ljava/lang/String;[I)Lcom/marwanalsidi/masrofi/UpdateChecker$Info;

    move-result-object v7

    .line 91
    aget v4, v8, v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    if-eqz v7, :cond_0

    goto :goto_1

    :catch_0
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    move-object v7, v6

    :goto_1
    if-nez v7, :cond_4

    if-nez v5, :cond_2

    .line 100
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v1, 0x7f0800fb

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    :cond_2
    const/16 v0, 0x194

    if-ne v4, v0, :cond_3

    .line 102
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    const v1, 0x7f0800f2

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    .line 104
    :cond_3
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$c:Landroid/content/Context;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const v2, 0x7f0800f7

    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 109
    :cond_4
    :goto_2
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/UpdateChecker$1;->val$h:Landroid/os/Handler;

    new-instance v1, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;

    invoke-direct {v1, p0, v7, v6}, Lcom/marwanalsidi/masrofi/UpdateChecker$1$1;-><init>(Lcom/marwanalsidi/masrofi/UpdateChecker$1;Lcom/marwanalsidi/masrofi/UpdateChecker$Info;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
