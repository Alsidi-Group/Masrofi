.class Lcom/marwanalsidi/masrofi/SalaryActivity$2;
.super Ljava/lang/Object;
.source "SalaryActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/SalaryActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

.field final synthetic val$ed:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/SalaryActivity;Landroid/widget/EditText;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 35
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->val$ed:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 12

    const-string p1, "\n"

    const/4 v0, 0x0

    .line 38
    :try_start_0
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->val$ed:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmpg-double v5, v1, v3

    if-ltz v5, :cond_1

    .line 40
    iget-object v5, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-static {v5}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v5

    .line 41
    invoke-virtual {v5}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v6

    .line 42
    invoke-virtual {v5, v1, v2}, Lcom/marwanalsidi/masrofi/DBHelper;->setSalary(D)V

    .line 43
    invoke-virtual {v5}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v8

    .line 44
    iget-object v5, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    const/4 v10, 0x1

    new-array v11, v10, [Ljava/lang/Object;

    invoke-static {v5, v1, v2}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v11, v0

    const v1, 0x7f0800b7

    invoke-virtual {v5, v1, v11}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    cmpg-double v2, v6, v3

    if-gez v2, :cond_0

    .line 46
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    new-array v3, v10, [Ljava/lang/Object;

    invoke-static {v2, v6, v7}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v0

    const v4, 0x7f0800b5

    invoke-virtual {v2, v4, v3}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 47
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    new-array v2, v10, [Ljava/lang/Object;

    invoke-static {v1, v8, v9}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v0

    const v3, 0x7f0800b3

    invoke-virtual {v1, v3, v2}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 49
    :cond_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-static {p1, v1, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 50
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    invoke-static {p1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->access$000(Lcom/marwanalsidi/masrofi/SalaryActivity;)V

    goto :goto_0

    .line 39
    :cond_1
    new-instance p1, Ljava/lang/NumberFormatException;

    invoke-direct {p1}, Ljava/lang/NumberFormatException;-><init>()V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 52
    :catch_0
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/SalaryActivity$2;->this$0:Lcom/marwanalsidi/masrofi/SalaryActivity;

    const p1, 0x7f0800b1

    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/SalaryActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 53
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method
