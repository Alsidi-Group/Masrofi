.class public final Lcom/marwanalsidi/masrofi/Lang;
.super Ljava/lang/Object;
.source "Lang.java"


# static fields
.field public static final LANGS:[[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 16

    const-string v0, "\ud83c\uddf8\ud83c\udde6"

    const-string v1, "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"

    const-string v2, "ar"

    .line 17
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v3

    const-string v0, "\ud83c\uddec\ud83c\udde7"

    const-string v1, "English"

    const-string v2, "en"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v4

    const-string v0, "\ud83c\uddeb\ud83c\uddf7"

    const-string v1, "Fran\u00e7ais"

    const-string v2, "fr"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v5

    const-string v0, "\ud83c\uddee\ud83c\uddf9"

    const-string v1, "Italiano"

    const-string v2, "it"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v6

    const-string v0, "\ud83c\uddf7\ud83c\uddfa"

    const-string v1, "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"

    const-string v2, "ru"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v7

    const-string v0, "\ud83c\udde9\ud83c\uddea"

    const-string v1, "Deutsch"

    const-string v2, "de"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v8

    const-string v0, "\ud83c\udde8\ud83c\uddf3"

    const-string v1, "\u4e2d\u6587"

    const-string v2, "zh"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v9

    const-string v0, "\ud83c\uddf0\ud83c\uddf7"

    const-string v1, "\ud55c\uad6d\uc5b4"

    const-string v2, "ko"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v10

    const-string v0, "\ud83c\uddef\ud83c\uddf5"

    const-string v1, "\u65e5\u672c\u8a9e"

    const-string v2, "ja"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v11

    const-string v0, "\ud83c\uddee\ud83c\uddf3"

    const-string v1, "\u0939\u093f\u0928\u094d\u0926\u0940"

    const-string v2, "hi"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v12

    const-string v0, "\ud83c\uddf9\ud83c\uddf7"

    const-string v1, "T\u00fcrk\u00e7e"

    const-string v2, "tr"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v13

    const-string v0, "\ud83c\uddf5\ud83c\uddf9"

    const-string v1, "Portugu\u00eas"

    const-string v2, "pt"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v14

    const-string v0, "\ud83c\uddea\ud83c\uddf8"

    const-string v1, "Espa\u00f1ol"

    const-string v2, "es"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v15

    filled-new-array/range {v3 .. v15}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/Lang;->LANGS:[[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static cur(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 34
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move-object p0, v0

    :goto_0
    const-string v0, "masrofi_prefs"

    const/4 v1, 0x0

    .line 36
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "app_lang"

    const-string v1, "ar"

    .line 37
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static localeOf(Ljava/lang/String;)Ljava/util/Locale;
    .locals 2

    const-string v0, "zh"

    .line 48
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Ljava/util/Locale;->SIMPLIFIED_CHINESE:Ljava/util/Locale;

    return-object p0

    :cond_0
    const-string v0, "ko"

    .line 49
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object p0, Ljava/util/Locale;->KOREAN:Ljava/util/Locale;

    return-object p0

    :cond_1
    const-string v0, "ja"

    .line 50
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Ljava/util/Locale;->JAPANESE:Ljava/util/Locale;

    return-object p0

    .line 51
    :cond_2
    new-instance v0, Ljava/util/Locale;

    if-eqz p0, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4

    :cond_3
    const-string p0, "ar"

    :cond_4
    invoke-direct {v0, p0}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static set(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 41
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "masrofi_prefs"

    const/4 v2, 0x0

    .line 42
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 43
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "app_lang"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 44
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->bumpThemeGen(Landroid/content/Context;)V

    return-void
.end method

.method public static wrap(Landroid/content/Context;)Landroid/content/Context;
    .locals 3

    .line 57
    :try_start_0
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Lang;->cur(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/marwanalsidi/masrofi/Lang;->localeOf(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    .line 58
    new-instance v1, Landroid/content/res/Configuration;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 59
    new-instance v2, Landroid/os/LocaleList;

    filled-new-array {v0}, [Ljava/util/Locale;

    move-result-object v0

    invoke-direct {v2, v0}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    .line 60
    invoke-static {v2}, Landroid/os/LocaleList;->setDefault(Landroid/os/LocaleList;)V

    .line 61
    invoke-virtual {v1, v2}, Landroid/content/res/Configuration;->setLocales(Landroid/os/LocaleList;)V

    .line 62
    invoke-virtual {p0, v1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-object p0
.end method
