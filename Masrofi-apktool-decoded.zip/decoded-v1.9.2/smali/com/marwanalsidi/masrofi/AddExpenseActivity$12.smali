.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$items:[Ljava/lang/String;

.field final synthetic val$w:I


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 237
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$items:[Ljava/lang/String;

    iput p3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$w:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 239
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$items:[Ljava/lang/String;

    iget v2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->val$w:I

    aget-object v1, v1, v2

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$802(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 240
    invoke-static {v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$900(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Landroid/widget/TextView;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$800(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 241
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    const v2, 0x7f010008

    invoke-static {v1, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_0
    return-void
.end method
