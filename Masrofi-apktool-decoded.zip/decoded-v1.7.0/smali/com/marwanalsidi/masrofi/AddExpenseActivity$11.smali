.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPay()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

.field final synthetic val$g:I


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 221
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iput p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->val$g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 222
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    iget p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;->val$g:I

    invoke-static {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$700(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V

    return-void
.end method
