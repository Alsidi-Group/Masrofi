.class Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;
.super Ljava/lang/Object;
.source "AddExpenseActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;


# direct methods
.method constructor <init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 246
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 247
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;->this$0:Lcom/marwanalsidi/masrofi/AddExpenseActivity;

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->access$100(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    return-void
.end method
