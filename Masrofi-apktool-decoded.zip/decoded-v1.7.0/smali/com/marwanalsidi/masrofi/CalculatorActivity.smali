.class public Lcom/marwanalsidi/masrofi/CalculatorActivity;
.super Landroid/app/Activity;
.source "CalculatorActivity.java"


# static fields
.field private static final KEYS:[[Ljava/lang/String;


# instance fields
.field private final expr:Ljava/lang/StringBuilder;

.field private lastResult:Ljava/lang/String;

.field private pickMode:Z

.field private tGen:I

.field private tvExpr:Landroid/widget/TextView;

.field private tvResult:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 8

    const-string v0, "%"

    const-string v1, "\u00f7"

    const-string v2, "C"

    const-string v3, "\u232b"

    .line 27
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const-string v1, "9"

    const-string v2, "\u00d7"

    const-string v3, "7"

    const-string v4, "8"

    filled-new-array {v3, v4, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "6"

    const-string v3, "\u2212"

    const-string v4, "4"

    const-string v5, "5"

    filled-new-array {v4, v5, v2, v3}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "3"

    const-string v4, "+"

    const-string v5, "1"

    const-string v6, "2"

    filled-new-array {v5, v6, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "."

    const-string v5, "="

    const-string v6, "\u00b1"

    const-string v7, "0"

    filled-new-array {v6, v7, v4, v5}, [Ljava/lang/String;

    move-result-object v4

    filled-new-array {v0, v1, v2, v3, v4}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->KEYS:[[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 22
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    const-string v0, ""

    .line 24
    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    const/4 v0, 0x0

    .line 25
    iput-boolean v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->pickMode:Z

    const/4 v0, -0x1

    .line 223
    iput v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/CalculatorActivity;)V
    .locals 0

    .line 20
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->insertResult()V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/CalculatorActivity;Ljava/lang/String;)V
    .locals 0

    .line 20
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->press(Ljava/lang/String;)V

    return-void
.end method

.method private evaluate()V
    .locals 3

    .line 188
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 189
    :cond_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u2212"

    const-string v2, "-"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u00d7"

    const-string v2, "*"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u00f7"

    const-string v2, "/"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 190
    invoke-static {v0}, Lcom/marwanalsidi/masrofi/Calc;->eval(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v0

    if-nez v0, :cond_1

    .line 192
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    const v1, 0x7f080031

    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 195
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    .line 196
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    const v2, 0x7f080032

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v2, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 197
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 198
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 199
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    iget-object p0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private insertResult()V
    .locals 4

    .line 204
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-lez v0, :cond_0

    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->evaluate()V

    .line 205
    :cond_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    .line 207
    :cond_1
    :try_start_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    const-string v1, ","

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    .line 208
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    const-string v3, "result"

    .line 209
    invoke-static {v0, v1}, Lcom/marwanalsidi/masrofi/Fmt;->num(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v0, -0x1

    .line 210
    invoke-virtual {p0, v0, v2}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->setResult(ILandroid/content/Intent;)V

    .line 211
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const v0, 0x7f080031

    .line 213
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method private key(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 8

    .line 122
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 123
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 124
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x1

    if-le v1, v2, :cond_0

    const/high16 v1, 0x41880000    # 17.0f

    goto :goto_0

    :cond_0
    const/high16 v1, 0x41a80000    # 21.0f

    :goto_0
    const/4 v3, 0x2

    invoke-virtual {v0, v3, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    const/16 v1, 0x11

    .line 125
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const-string v1, "sans-serif-medium"

    const/4 v3, 0x0

    .line 126
    invoke-static {v1, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 127
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x42800000    # 64.0f

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v1, v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v4, 0x40800000    # 4.0f

    .line 128
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v1, v5, v6, v7, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 129
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "="

    .line 131
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v4, "\u00f7"

    .line 132
    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "\u00d7"

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "\u2212"

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "+"

    .line 133
    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "%"

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    move v2, v3

    .line 135
    :cond_2
    :goto_1
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/high16 v4, 0x41900000    # 18.0f

    .line 136
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 v4, 0x7f010000

    if-eqz v1, :cond_3

    .line 138
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v1, -0x1

    .line 139
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_2

    :cond_3
    if-eqz v2, :cond_4

    .line 141
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    const v2, 0x3e0f5c29    # 0.14f

    invoke-static {v1, v2}, Lcom/marwanalsidi/masrofi/Ui;->withAlpha(IF)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 142
    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_2

    :cond_4
    const v1, 0x7f010004

    .line 144
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const v1, 0x7f010008

    .line 145
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 147
    :goto_2
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 148
    new-instance v1, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;

    invoke-direct {v1, p0, p1}, Lcom/marwanalsidi/masrofi/CalculatorActivity$3;-><init>(Lcom/marwanalsidi/masrofi/CalculatorActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private press(Ljava/lang/String;)V
    .locals 5

    .line 156
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, -0x1

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u232b"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    goto :goto_0

    :sswitch_1
    const-string v0, "\u00b1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    goto :goto_0

    :sswitch_2
    const-string v0, "C"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    goto :goto_0

    :sswitch_3
    const-string v0, "="

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    move v3, v2

    goto :goto_0

    :sswitch_4
    const-string v0, "%"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    move v3, v1

    :goto_0
    const-string v0, ""

    packed-switch v3, :pswitch_data_0

    .line 177
    iget-object v3, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-nez v3, :cond_5

    goto :goto_1

    :cond_5
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    sub-int/2addr v3, v2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_1
    const-string v3, "+\u2212\u00d7\u00f7."

    .line 178
    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ne v0, v2, :cond_6

    move v0, v2

    goto :goto_2

    :cond_6
    move v0, v1

    .line 179
    :goto_2
    invoke-virtual {v3, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-ne v3, v2, :cond_7

    move v1, v2

    :cond_7
    if-eqz v0, :cond_8

    if-eqz v1, :cond_8

    .line 180
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    .line 181
    :cond_8
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_a

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 163
    :pswitch_0
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    if-lez p1, :cond_a

    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 166
    :pswitch_1
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/16 v0, 0x2d

    if-lez p1, :cond_9

    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result p1

    if-ne p1, v0, :cond_9

    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 167
    :cond_9
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1, v0}, Ljava/lang/StringBuilder;->insert(IC)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 158
    :pswitch_2
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 159
    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->lastResult:Ljava/lang/String;

    .line 160
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    .line 173
    :pswitch_3
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->evaluate()V

    return-void

    .line 170
    :pswitch_4
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    const-string v0, "/100"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    :cond_a
    :goto_3
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_b

    const-string p0, "0"

    goto :goto_4

    :cond_b
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->expr:Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_4
    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x25 -> :sswitch_4
        0x3d -> :sswitch_3
        0x43 -> :sswitch_2
        0xb1 -> :sswitch_1
        0x232b -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private spacer(I)Landroid/view/View;
    .locals 2

    .line 115
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 116
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p1, p1

    invoke-static {p0, p1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    const/4 p1, 0x1

    invoke-direct {v1, p1, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 36
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11

    .line 40
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->setTheme(I)V

    .line 41
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 42
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tGen:I

    .line 43
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "pick"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->pickMode:Z

    .line 45
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 46
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v2, 0x7f010002

    .line 47
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    const/high16 v2, 0x41900000    # 18.0f

    .line 48
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    .line 49
    invoke-virtual {p1, v3, v3, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 52
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 53
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x10

    .line 54
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 55
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v5, "\u2190"

    .line 56
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v5, 0x41b00000    # 22.0f

    const/4 v6, 0x2

    .line 57
    invoke-virtual {v4, v6, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    const v5, 0x7f010008

    .line 58
    invoke-static {p0, v5}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v7, 0x41800000    # 16.0f

    .line 59
    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v4, v1, v1, v8, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 60
    new-instance v8, Lcom/marwanalsidi/masrofi/CalculatorActivity$1;

    invoke-direct {v8, p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity$1;-><init>(Lcom/marwanalsidi/masrofi/CalculatorActivity;)V

    invoke-virtual {v4, v8}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 63
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v4, 0x7f080033

    .line 64
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/high16 v8, 0x41980000    # 19.0f

    invoke-static {p0, v4, v8, v1}, Lcom/marwanalsidi/masrofi/Ui;->title(Landroid/content/Context;Ljava/lang/String;FZ)Landroid/widget/TextView;

    move-result-object v4

    .line 65
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v8, v1, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v4, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 67
    invoke-virtual {p1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v3, 0xa

    .line 68
    invoke-direct {p0, v3}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->spacer(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {p1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 71
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 72
    invoke-virtual {v3, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v0, 0x7f040004

    .line 73
    invoke-virtual {v3, v0}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    .line 74
    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, v7}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v3, v0, v4, v2, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 75
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    const-string v2, "0"

    .line 76
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 77
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    const/high16 v2, 0x41f00000    # 30.0f

    invoke-virtual {v0, v6, v2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 78
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    invoke-static {p0, v5}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 79
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    const-string v2, "sans-serif-light"

    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 80
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    const v2, 0x800005

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 81
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    const/high16 v4, 0x41600000    # 14.0f

    .line 82
    invoke-virtual {v0, v6, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 83
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    const v4, 0x7f010009

    invoke-static {p0, v4}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 84
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 85
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-static {p0, v2}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v0, v1, v2, v1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 86
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvExpr:Landroid/widget/TextView;

    invoke-virtual {v3, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 87
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tvResult:Landroid/widget/TextView;

    invoke-virtual {v3, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 88
    invoke-virtual {p1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v0, 0xe

    .line 89
    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->spacer(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 92
    sget-object v2, Lcom/marwanalsidi/masrofi/CalculatorActivity;->KEYS:[[Ljava/lang/String;

    array-length v3, v2

    move v4, v1

    :goto_0
    if-ge v4, v3, :cond_1

    aget-object v5, v2, v4

    .line 93
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 94
    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 95
    array-length v7, v5

    move v8, v1

    :goto_1
    if-ge v8, v7, :cond_0

    aget-object v9, v5, v8

    invoke-direct {p0, v9}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->key(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v6, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 96
    :cond_0
    invoke-virtual {p1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 98
    :cond_1
    invoke-direct {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->spacer(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 101
    iget-boolean v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->pickMode:Z

    if-eqz v0, :cond_2

    const v0, 0x7f080030

    .line 102
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->btnAccent(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    .line 103
    new-instance v1, Lcom/marwanalsidi/masrofi/CalculatorActivity$2;

    invoke-direct {v1, p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity$2;-><init>(Lcom/marwanalsidi/masrofi/CalculatorActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 106
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 109
    :cond_2
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 110
    invoke-virtual {v0, p1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 111
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 219
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 220
    iget v0, p0, Lcom/marwanalsidi/masrofi/CalculatorActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/CalculatorActivity;->recreate()V

    :cond_0
    return-void
.end method
