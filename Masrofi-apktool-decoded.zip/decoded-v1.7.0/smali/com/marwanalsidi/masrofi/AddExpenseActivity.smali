.class public Lcom/marwanalsidi/masrofi/AddExpenseActivity;
.super Landroid/app/Activity;
.source "AddExpenseActivity.java"


# static fields
.field private static final CAMERA_PERM:I = 0x29

.field private static final LOC_PERM:I = 0x2a

.field private static final REQ_CALC:I = 0x32

.field private static final REQ_CAM:I = 0x28


# instance fields
.field private loc:Ljava/lang/String;

.field private pay:Ljava/lang/String;

.field private photoPath:Ljava/lang/String;

.field private shop:Ljava/lang/String;

.field private tGen:I

.field private tvCalc:Landroid/widget/TextView;

.field private tvLoc:Landroid/widget/TextView;

.field private tvPay:Landroid/widget/TextView;

.field private tvShop:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 33
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const-string v0, ""

    .line 35
    iput-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shop:Ljava/lang/String;

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->photoPath:Ljava/lang/String;

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->loc:Ljava/lang/String;

    const/4 v0, -0x1

    .line 43
    iput v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tGen:I

    return-void
.end method

.method static synthetic access$000(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickShop()V

    return-void
.end method

.method static synthetic access$100(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPay()V

    return-void
.end method

.method static synthetic access$1000(Lcom/marwanalsidi/masrofi/AddExpenseActivity;D)V
    .locals 0

    .line 33
    invoke-direct {p0, p1, p2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->doSave(D)V

    return-void
.end method

.method static synthetic access$200(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shoot()V

    return-void
.end method

.method static synthetic access$300(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->grabLoc()V

    return-void
.end method

.method static synthetic access$400(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->save()V

    return-void
.end method

.method static synthetic access$500(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Landroid/app/AlertDialog;)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->addNewStore(Landroid/app/AlertDialog;)V

    return-void
.end method

.method static synthetic access$600(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->selectShop(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$700(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pickPayGroup(I)V

    return-void
.end method

.method static synthetic access$800(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Ljava/lang/String;
    .locals 0

    .line 33
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$802(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 33
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$900(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)Landroid/widget/TextView;
    .locals 0

    .line 33
    iget-object p0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvPay:Landroid/widget/TextView;

    return-object p0
.end method

.method private addNewStore(Landroid/app/AlertDialog;)V
    .locals 7

    .line 176
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 177
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41a00000    # 20.0f

    .line 178
    invoke-static {p0, v1}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    .line 179
    div-int/lit8 v3, v1, 0x2

    const/4 v4, 0x0

    invoke-virtual {v2, v1, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v1, 0x7f08007a

    .line 180
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const v3, 0x20001

    invoke-static {p0, v1, v3}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v1

    .line 181
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 182
    new-instance v4, Landroid/view/View;

    invoke-direct {v4, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 183
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x41200000    # 10.0f

    invoke-static {p0, v6}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v5, v0, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 184
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v0, 0x7f08007b

    .line 185
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v3}, Lcom/marwanalsidi/masrofi/Ui;->input(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v0

    .line 186
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v3, 0x7f080079

    .line 188
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f080029

    .line 189
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;

    invoke-direct {v5, p0, v1, v0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$10;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/app/AlertDialog;)V

    const p1, 0x7f08002a

    .line 209
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, v3

    move-object v3, v4

    move-object v4, v5

    move-object v5, p1

    .line 188
    invoke-static/range {v0 .. v6}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private doSave(D)V
    .locals 13

    const v0, 0x7f05001a

    .line 359
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    const v1, 0x7f05001c

    .line 360
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    .line 363
    :try_start_0
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v1, 0x1

    :goto_0
    move v12, v1

    .line 365
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-object v7, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shop:Ljava/lang/String;

    iget-object v8, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    .line 366
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    iget-object v10, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->photoPath:Ljava/lang/String;

    iget-object v11, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->loc:Ljava/lang/String;

    move-wide v5, p1

    .line 365
    invoke-virtual/range {v2 .. v12}, Lcom/marwanalsidi/masrofi/DBHelper;->addExpense(JDLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 367
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/NotifyUpdater;->refresh(Landroid/content/Context;)V

    .line 368
    invoke-static {p0, p1, p2}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const p2, 0x7f0800b9

    invoke-virtual {p0, p2, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 369
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 370
    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->finish()V

    return-void
.end method

.method private grabLoc()V
    .locals 10

    const v0, 0x7f080012

    :try_start_0
    const-string v1, "location"

    .line 290
    invoke-virtual {p0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/location/LocationManager;

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    .line 293
    invoke-virtual {v1, v2}, Landroid/location/LocationManager;->getProviders(Z)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :catch_0
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 295
    :try_start_1
    invoke-virtual {v1, v5}, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;

    move-result-object v5

    if-eqz v5, :cond_0

    if-eqz v3, :cond_1

    .line 296
    invoke-virtual {v5}, Landroid/location/Location;->getAccuracy()F

    move-result v6

    invoke-virtual {v3}, Landroid/location/Location;->getAccuracy()F

    move-result v7
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    cmpg-float v6, v6, v7

    if-gez v6, :cond_0

    :cond_1
    move-object v3, v5

    goto :goto_0

    :cond_2
    if-eqz v3, :cond_3

    .line 301
    :try_start_2
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v4, "%.5f, %.5f"

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    .line 302
    invoke-virtual {v3}, Landroid/location/Location;->getLatitude()D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    const/4 v7, 0x0

    aput-object v6, v5, v7

    invoke-virtual {v3}, Landroid/location/Location;->getLongitude()D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    aput-object v3, v5, v2

    .line 301
    invoke-static {v1, v4, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->loc:Ljava/lang/String;

    .line 303
    iget-object v3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvLoc:Landroid/widget/TextView;

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v1, v2, v7

    const v1, 0x7f080013

    invoke-virtual {p0, v1, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_3
    const-string v1, ""

    .line 305
    iput-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->loc:Ljava/lang/String;

    .line 306
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvLoc:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    .line 309
    :catch_1
    iget-object v1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvLoc:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    return-void
.end method

.method private pickPay()V
    .locals 8

    .line 214
    sget-object v0, Lcom/marwanalsidi/masrofi/Data;->PAY_GROUPS:[Ljava/lang/String;

    .line 215
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 216
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v1, 0x0

    move v2, v1

    .line 217
    :goto_0
    array-length v4, v0

    if-ge v2, v4, :cond_0

    .line 219
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v0, v2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "  ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Lcom/marwanalsidi/masrofi/Data;->PAY_ITEMS:[[Ljava/lang/String;

    aget-object v5, v5, v2

    array-length v5, v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;

    invoke-direct {v5, p0, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$11;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;I)V

    invoke-static {p0, v4, v1, v5}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    .line 224
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    const v0, 0x7f08009e

    .line 226
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const v0, 0x7f08002a

    .line 227
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 226
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private pickPayGroup(I)V
    .locals 8

    .line 231
    sget-object v0, Lcom/marwanalsidi/masrofi/Data;->PAY_ITEMS:[[Ljava/lang/String;

    aget-object v0, v0, p1

    .line 232
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 233
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v1, 0x0

    .line 234
    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    .line 236
    aget-object v2, v0, v1

    iget-object v4, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    new-instance v5, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;

    invoke-direct {v5, p0, v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$12;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;I)V

    invoke-static {p0, v2, v4, v5}, Lcom/marwanalsidi/masrofi/Ui;->optionRow(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 245
    :cond_0
    sget-object v0, Lcom/marwanalsidi/masrofi/Data;->PAY_GROUPS:[Ljava/lang/String;

    aget-object v2, v0, p1

    const p1, 0x7f080028

    .line 246
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;

    invoke-direct {v5, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$13;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    const p1, 0x7f08002a

    .line 249
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v1, p0

    .line 245
    invoke-static/range {v1 .. v7}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    return-void
.end method

.method private pickShop()V
    .locals 16

    move-object/from16 v0, p0

    .line 117
    invoke-static/range {p0 .. p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v1

    invoke-virtual {v1}, Lcom/marwanalsidi/masrofi/DBHelper;->allStores()Ljava/util/List;

    move-result-object v1

    .line 118
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    .line 119
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 120
    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 121
    invoke-virtual {v4, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    new-array v7, v3, [Landroid/app/AlertDialog;

    .line 126
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const v6, 0x7f0800a0

    .line 127
    invoke-virtual {v0, v6}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41680000    # 14.5f

    const/4 v8, 0x2

    .line 128
    invoke-virtual {v5, v8, v6}, Landroid/widget/TextView;->setTextSize(IF)V

    const-string v6, "sans-serif-bold"

    const/4 v9, 0x0

    .line 129
    invoke-static {v6, v9}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v10

    invoke-virtual {v5, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/high16 v10, 0x7f010000

    .line 130
    invoke-static {v0, v10}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v5, v11}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v11, 0x11

    .line 131
    invoke-virtual {v5, v11}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v11, 0x41600000    # 14.0f

    .line 132
    invoke-static {v0, v11}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v12

    const/high16 v13, 0x41200000    # 10.0f

    invoke-static {v0, v13}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v13

    invoke-virtual {v5, v9, v12, v9, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 133
    new-instance v12, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;

    invoke-direct {v12, v0, v7}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$8;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Landroid/app/AlertDialog;)V

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 136
    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 139
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v5, 0x0

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, [Ljava/lang/String;

    .line 140
    aget-object v13, v12, v9

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    const/high16 v14, 0x41800000    # 16.0f

    if-nez v13, :cond_0

    .line 141
    aget-object v5, v12, v9

    .line 142
    new-instance v13, Landroid/widget/TextView;

    invoke-direct {v13, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 143
    invoke-virtual {v13, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v15, 0x41480000    # 12.5f

    .line 144
    invoke-virtual {v13, v8, v15}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 145
    invoke-static {v6, v9}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v15

    invoke-virtual {v13, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 146
    invoke-static {v0, v10}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v13, v15}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v15, 0x41b00000    # 22.0f

    .line 147
    invoke-static {v0, v15}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v15

    invoke-static {v0, v11}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v0, v14}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    const/high16 v9, 0x40800000    # 4.0f

    invoke-static {v0, v9}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v13, v15, v10, v11, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 148
    invoke-virtual {v2, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 150
    :cond_0
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 151
    aget-object v10, v12, v3

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x41700000    # 15.0f

    .line 152
    invoke-virtual {v9, v8, v10}, Landroid/widget/TextView;->setTextSize(IF)V

    const v10, 0x7f010008

    .line 153
    invoke-static {v0, v10}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v10, 0x41f00000    # 30.0f

    .line 154
    invoke-static {v0, v10}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    const/high16 v11, 0x41400000    # 12.0f

    invoke-static {v0, v11}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v13

    invoke-static {v0, v14}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v14

    invoke-static {v0, v11}, Lcom/marwanalsidi/masrofi/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v9, v10, v13, v14, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 155
    new-instance v10, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;

    invoke-direct {v10, v0, v12, v7}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$9;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;[Ljava/lang/String;[Landroid/app/AlertDialog;)V

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 161
    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v9, 0x0

    const/high16 v10, 0x7f010000

    const/high16 v11, 0x41600000    # 14.0f

    goto/16 :goto_0

    :cond_1
    const v1, 0x7f08009f

    .line 164
    invoke-virtual {v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v5, 0x0

    const v2, 0x7f08002a

    .line 165
    invoke-virtual {v0, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object v2, v4

    move-object v4, v5

    move-object v5, v6

    move-object v6, v8

    .line 164
    invoke-static/range {v0 .. v6}, Lcom/marwanalsidi/masrofi/Ui;->dlg(Landroid/content/Context;Ljava/lang/CharSequence;Landroid/view/View;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    move-result-object v0

    const/4 v1, 0x0

    aput-object v0, v7, v1

    return-void
.end method

.method private refreshAvail()V
    .locals 5

    .line 107
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v0

    .line 108
    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v0

    const v2, 0x7f050026

    .line 109
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 110
    invoke-static {p0, v0, v1}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const v4, 0x7f08000d

    invoke-virtual {p0, v4, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-wide/16 v3, 0x0

    cmpg-double v0, v0, v3

    if-gez v0, :cond_0

    const v0, 0x7f010005

    .line 111
    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p0

    goto :goto_0

    :cond_0
    const/high16 v0, 0x7f010000

    .line 112
    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p0

    .line 111
    :goto_0
    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method private save()V
    .locals 15

    const v0, 0x7f050017

    .line 315
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    const/4 v1, 0x0

    .line 318
    :try_start_0
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-wide/16 v4, 0x0

    cmpg-double v0, v2, v4

    if-lez v0, :cond_4

    .line 324
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shop:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, 0x7f080053

    .line 325
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    .line 328
    :cond_0
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, 0x7f080052

    .line 329
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    .line 333
    :cond_1
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/DBHelper;->get(Landroid/content/Context;)Lcom/marwanalsidi/masrofi/DBHelper;

    move-result-object v0

    .line 334
    invoke-virtual {v0}, Lcom/marwanalsidi/masrofi/DBHelper;->balance()D

    move-result-wide v0

    sub-double v6, v0, v2

    cmpg-double v4, v6, v4

    if-gez v4, :cond_3

    const v4, 0x7f08002b

    .line 338
    invoke-virtual {p0, v4}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v11

    .line 339
    new-instance v12, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;

    invoke-direct {v12, p0, v2, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$14;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;D)V

    const-string v2, "\u0646\u0627\u0628 \u0628\u0632\u0646\u0633"

    .line 343
    iget-object v3, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->pay:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const v3, 0x7f08002a

    if-eqz v2, :cond_2

    const v0, 0x7f08008f

    .line 345
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v9

    .line 346
    invoke-static {p0, v6, v7}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const v1, 0x7f08008e

    invoke-virtual {p0, v1, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    .line 347
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    move-object v8, p0

    .line 345
    invoke-static/range {v8 .. v14}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    goto :goto_0

    :cond_2
    const v2, 0x7f080090

    .line 349
    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v9

    .line 350
    invoke-static {p0, v0, v1}, Lcom/marwanalsidi/masrofi/Fmt;->money(Landroid/content/Context;D)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const v1, 0x7f08008d

    invoke-virtual {p0, v1, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    .line 351
    invoke-virtual {p0, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    move-object v8, p0

    .line 349
    invoke-static/range {v8 .. v14}, Lcom/marwanalsidi/masrofi/Ui;->msg(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog;

    :goto_0
    return-void

    .line 355
    :cond_3
    invoke-direct {p0, v2, v3}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->doSave(D)V

    return-void

    .line 319
    :cond_4
    :try_start_1
    new-instance v0, Ljava/lang/NumberFormatException;

    invoke-direct {v0}, Ljava/lang/NumberFormatException;-><init>()V

    throw v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    const v0, 0x7f080051

    .line 321
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private selectShop(Ljava/lang/String;)V
    .locals 1

    .line 169
    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shop:Ljava/lang/String;

    .line 170
    iget-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvShop:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 171
    iget-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvShop:Landroid/widget/TextView;

    const v0, 0x7f010008

    invoke-static {p0, v0}, Lcom/marwanalsidi/masrofi/Ui;->attr(Landroid/content/Context;I)I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method private shoot()V
    .locals 6

    const-string v0, "r_"

    .line 255
    :try_start_0
    new-instance v1, Ljava/io/File;

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    const-string v3, "receipts"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 256
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 257
    :cond_0
    new-instance v2, Ljava/io/File;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ".jpg"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v1, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 258
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->photoPath:Ljava/lang/String;

    .line 259
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.media.action.IMAGE_CAPTURE"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "output"

    .line 260
    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/marwanalsidi/masrofi/ReceiptProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v1, 0x3

    .line 261
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/16 v1, 0x28

    .line 263
    invoke-virtual {p0, v0, v1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const v0, 0x7f080010

    .line 265
    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 46
    invoke-static {p1}, Lcom/marwanalsidi/masrofi/Lang;->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    .line 271
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/16 v0, 0x28

    const/4 v1, -0x1

    if-ne p1, v0, :cond_0

    if-ne p2, v1, :cond_0

    const p1, 0x7f050028

    .line 273
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const p2, 0x7f08000f

    .line 274
    invoke-virtual {p0, p2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    const/16 v0, 0x32

    if-ne p1, v0, :cond_1

    if-ne p2, v1, :cond_1

    if-eqz p3, :cond_1

    const-string p1, "result"

    .line 276
    invoke-virtual {p3, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 277
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_1

    const p2, 0x7f050017

    .line 278
    invoke-virtual {p0, p2}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/EditText;

    .line 279
    invoke-virtual {p2, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 280
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    invoke-virtual {p2, p3}, Landroid/widget/EditText;->setSelection(I)V

    .line 281
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvCalc:Landroid/widget/TextView;

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 282
    iget-object p2, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvCalc:Landroid/widget/TextView;

    const p3, 0x7f080032

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, p3, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 50
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeRes(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->setTheme(I)V

    .line 51
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 52
    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result p1

    iput p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tGen:I

    const p1, 0x7f060001

    .line 53
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->setContentView(I)V

    const p1, 0x7f050007

    .line 55
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$1;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$1;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050030

    .line 58
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvShop:Landroid/widget/TextView;

    const p1, 0x7f05002e

    .line 59
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvPay:Landroid/widget/TextView;

    const p1, 0x7f05002c

    .line 60
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvLoc:Landroid/widget/TextView;

    const p1, 0x7f050027

    .line 61
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tvCalc:Landroid/widget/TextView;

    .line 63
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->refreshAvail()V

    const p1, 0x7f050008

    .line 65
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$2;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050024

    .line 71
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$3;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$3;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050023

    .line 74
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$4;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$4;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050020

    .line 77
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$5;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f050022

    .line 83
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$6;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f05000e

    .line 91
    invoke-virtual {p0, p1}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lcom/marwanalsidi/masrofi/AddExpenseActivity$7;

    invoke-direct {v0, p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity$7;-><init>(Lcom/marwanalsidi/masrofi/AddExpenseActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1

    .line 98
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0x29

    const/4 v0, 0x0

    if-ne p1, p2, :cond_0

    if-eqz p3, :cond_0

    .line 99
    array-length p2, p3

    if-lez p2, :cond_0

    aget p2, p3, v0

    if-nez p2, :cond_0

    .line 100
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->shoot()V

    goto :goto_0

    :cond_0
    const/16 p2, 0x2a

    if-ne p1, p2, :cond_1

    if-eqz p3, :cond_1

    .line 101
    array-length p1, p3

    if-lez p1, :cond_1

    aget p1, p3, v0

    if-nez p1, :cond_1

    .line 102
    invoke-direct {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->grabLoc()V

    :cond_1
    :goto_0
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 375
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 377
    iget v0, p0, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->tGen:I

    invoke-static {p0}, Lcom/marwanalsidi/masrofi/Prefs;->themeGen(Landroid/content/Context;)I

    move-result v1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/marwanalsidi/masrofi/AddExpenseActivity;->recreate()V

    :cond_0
    return-void
.end method
