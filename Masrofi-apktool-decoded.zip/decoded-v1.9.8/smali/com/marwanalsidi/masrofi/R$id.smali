.class public final Lcom/marwanalsidi/masrofi/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/marwanalsidi/masrofi/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final boxChips:I = 0x7f050000

.field public static final boxList:I = 0x7f050001

.field public static final boxLog:I = 0x7f050002

.field public static final boxRecent:I = 0x7f050003

.field public static final boxSettings:I = 0x7f050004

.field public static final boxTable:I = 0x7f050005

.field public static final btnAbout:I = 0x7f050006

.field public static final btnBack:I = 0x7f050007

.field public static final btnCalc:I = 0x7f050008

.field public static final btnCheck:I = 0x7f050009

.field public static final btnCsv:I = 0x7f05000a

.field public static final btnMain:I = 0x7f05000b

.field public static final btnNext:I = 0x7f05000c

.field public static final btnPrev:I = 0x7f05000d

.field public static final btnSave:I = 0x7f05000e

.field public static final btnSettings:I = 0x7f05000f

.field public static final btnToggle:I = 0x7f050010

.field public static final btnUpdate:I = 0x7f050011

.field public static final cardAdd:I = 0x7f050012

.field public static final cardCalc:I = 0x7f050013

.field public static final cardData:I = 0x7f050014

.field public static final cardSalary:I = 0x7f050015

.field public static final cardShops:I = 0x7f050016

.field public static final edAmount:I = 0x7f050017

.field public static final edConfirm:I = 0x7f050018

.field public static final edName:I = 0x7f050019

.field public static final edNote:I = 0x7f05001a

.field public static final edPass:I = 0x7f05001b

.field public static final edQty:I = 0x7f05001c

.field public static final edSalary:I = 0x7f05001d

.field public static final edSearch:I = 0x7f05001e

.field public static final loginTitle:I = 0x7f05001f

.field public static final rowCamera:I = 0x7f050020

.field public static final rowGmail:I = 0x7f050021

.field public static final rowLoc:I = 0x7f050022

.field public static final rowPay:I = 0x7f050023

.field public static final rowShop:I = 0x7f050024

.field public static final tvAll:I = 0x7f050025

.field public static final tvAvail:I = 0x7f050026

.field public static final tvCalc:I = 0x7f050027

.field public static final tvCam:I = 0x7f050028

.field public static final tvEmptyRecent:I = 0x7f050029

.field public static final tvError:I = 0x7f05002a

.field public static final tvGreet:I = 0x7f05002b

.field public static final tvLoc:I = 0x7f05002c

.field public static final tvMonth:I = 0x7f05002d

.field public static final tvPay:I = 0x7f05002e

.field public static final tvSalary:I = 0x7f05002f

.field public static final rowItems:I = 0x7f050034

.field public static final tvShop:I = 0x7f050030

.field public static final tvTotal:I = 0x7f050031

.field public static final tvUpdateStatus:I = 0x7f050032

.field public static final tvVersion:I = 0x7f050033


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 333
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
